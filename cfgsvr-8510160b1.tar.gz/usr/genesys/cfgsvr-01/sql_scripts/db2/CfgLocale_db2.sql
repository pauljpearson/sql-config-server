echo '-- ======================================================================= --'
echo '-- Configuration Locale Script v.8.5.000.07  (Locale Version: 8.5.000.12) DB2'
echo '-- ======================================================================= --'
DELETE FROM cfg_locale where lcid=1

DELETE FROM cfg_locale where lcid=1033

INSERT INTO cfg_locale VALUES(1033,8,0,0,0,'Unknown Object State','Enum_CfgObjectState')

INSERT INTO cfg_locale VALUES(1033,8,0,1,0,'Enabled','Enum_CfgObjectState')

INSERT INTO cfg_locale VALUES(1033,8,0,2,0,'Disabled','Enum_CfgObjectState')

INSERT INTO cfg_locale VALUES(1033,8,1,0,0,'Unknown Switch Type','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,1,0,'Nortel Meridian 1','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,2,0,'Rockwell Spectrum','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,3,0,'Rockwell Galaxy','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,4,0,'Nortel Communication Server 2000/2100','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,5,0,'Avaya Communication Manager','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,6,0,'Aspect CallCenter','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,7,0,'Siemens Hicom 300E','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,8,0,'Intecom IBX80','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,9,0,'Ericsson MD110','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,10,0,'Lucent 5ESS','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,11,0,'Madge','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,12,0,'NEC NEAX','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,13,0,'Fujitsu F9600','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,14,0,'Teltronics 20-20','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,15,0,'WorldCom 800 Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,16,0,'Siemens Hicom 150','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,17,0,'Siemens Hicom 300 ACL-H3','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,18,0,'Philips Sopho iS3000','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,19,0,'EADS Telecom M6500 Succession','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,20,0,'Siemens Hicom 150H','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,21,0,'Ericsson ACP1000','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,22,0,'Siemens GEC iSSDX','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,23,0,'Alcatel A4400','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,24,0,'Generic Switch','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,25,0,'Delco ACD','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,26,0,'Hitachi CX8000','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,27,0,'LG Starex-ACS','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,28,0,'Mitel SX-2000','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,29,0,'Nortel Communication Server 1000 with SCCS/MLS','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,30,0,'Siemens Hicom 150E','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,31,0,'Siemens RealitisDX iCCL','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,32,0,'Tadiran Coral','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,33,0,'Voice over IP SMCP Switch','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,34,0,'Virtual Switch for IVR In-Front','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,35,0,'Internet Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,36,0,'AT&T 800 ICP Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,37,0,'Sprint SiteRP Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,38,0,'Bell Canada (Stentor) ATF Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,39,0,'Alcatel SCP Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,40,0,'Bell Atlantic ISCP Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,41,0,'Concert 800 Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,42,0,'Alcatel DTAG SCP Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,43,0,'KPN Network Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,44,0,'Alcatel Telecom Italia SCP Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,45,0,'Alcatel BT SCP Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,46,0,'3511 Protocol Interface','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,47,0,'DataVoice Dharma','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,48,0,'Huawei C_C08','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,49,0,'Avaya INDeX','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,50,0,'Siemens Hicom 300H','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,51,0,'Siemens HiPath 4000','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,52,0,'Alcatel A4200','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,53,0,'Tenovis Integral 33','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,54,0,'Telera','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,55,0,'NGSN','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,56,0,'GenSpec','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,57,0,'Voice Portal','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,58,0,'K-Worker Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,59,0,'Siemens Hicom 300','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,60,0,'GenSpec XML','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,61,0,'OPSI','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,62,0,'Cisco Call Manager','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,63,0,'Multimedia Switch','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,64,0,'Verizon ISCP Gateway','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,65,0,'Alcatel 5020 OPSI','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,66,0,'Avaya IP Office','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,67,0,'Mitel MN-3300','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,68,0,'Samsung IP PCX IAP','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,69,0,'Siemens HiPath 3000','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,70,0,'eOn eQueue','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,71,0,'Tenovis I55','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,72,0,'SIP Switch','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,73,0,'Digitro AXS/20','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,74,0,'GVP DID Group','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,75,0,'SIP Network Switch','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,76,0,'NEC NEAX SV7000','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,77,0,'Radvision iContact','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,78,0,'Avaya TSAPI','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,79,0,'Huawei NGN','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,80,0,'Cisco UCCE','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,81,0,'BroadSoft BroadWorks','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,1,82,0,'Aastra MX-ONE','Enum_CfgSwitchType')

INSERT INTO cfg_locale VALUES(1033,8,2,0,0,'Unknown Link Type','CFGNoLink')

INSERT INTO cfg_locale VALUES(1033,8,2,1,0,'Meridian Link 4','CFGMeridianLink4')

INSERT INTO cfg_locale VALUES(1033,8,2,2,0,'Meridian Link 5','CFGMeridianLink5')

INSERT INTO cfg_locale VALUES(1033,8,2,3,0,'Galaxy Link','CFGGalaxyLink')

INSERT INTO cfg_locale VALUES(1033,8,2,4,0,'Spectrum Link','CFGSpectrumLink')

INSERT INTO cfg_locale VALUES(1033,8,2,5,0,'SCAI 7','CFGCompuCall05')

INSERT INTO cfg_locale VALUES(1033,8,2,6,0,'SCAI 8','CFGCompuCall06')

INSERT INTO cfg_locale VALUES(1033,8,2,7,0,'Call Visor ASAI','CFGCallVisorASAI')

INSERT INTO cfg_locale VALUES(1033,8,2,8,0,'Ethernet ASAI','CFGEthernetASAI')

INSERT INTO cfg_locale VALUES(1033,8,2,9,0,'Application Bridge 5','CFGApplicationBridge5')

INSERT INTO cfg_locale VALUES(1033,8,2,10,0,'Application Bridge 6','CFGApplicationBridge6')

INSERT INTO cfg_locale VALUES(1033,8,2,11,0,'CallBridge 2','CFGCallBridge2')

INSERT INTO cfg_locale VALUES(1033,8,2,12,0,'CallBridge 3','CFGCallBridge3')

INSERT INTO cfg_locale VALUES(1033,8,2,13,0,'OAI','CFGOAI')

INSERT INTO cfg_locale VALUES(1033,8,2,14,0,'Application Link','CFGApplicationLink')

INSERT INTO cfg_locale VALUES(1033,8,2,15,0,'Pinnacle','CFGPinnacle')

INSERT INTO cfg_locale VALUES(1033,8,2,16,0,'Madge Link','CFGMadgeLink')

INSERT INTO cfg_locale VALUES(1033,8,2,17,0,'NEC Link','CFGNECLink')

INSERT INTO cfg_locale VALUES(1033,8,2,18,0,'Fujitsu Link','CFGFujitsuLink')

INSERT INTO cfg_locale VALUES(1033,8,2,19,0,'Host Interface Link','CFGHostInterfaceLink')

INSERT INTO cfg_locale VALUES(1033,8,2,20,0,'Workstation Interface Link','CFGWorkStationInterfaceLink')

INSERT INTO cfg_locale VALUES(1033,8,2,21,0,'Gateway 01 Link','CFGGateway01Link')

INSERT INTO cfg_locale VALUES(1033,8,2,22,0,'Application Connectivity Link 1.x','CFGApplicationConnectivityLink10')

INSERT INTO cfg_locale VALUES(1033,8,2,23,0,'Application Connectivity Link 2.x','CFGApplicationConnectivityLink20')

INSERT INTO cfg_locale VALUES(1033,8,2,24,0,'CallBridge ACL ISDN SO ISO','CFGCallBridgeACLISDNS0ISO')

INSERT INTO cfg_locale VALUES(1033,8,2,25,0,'CallBridge ACL v.24 ISO','CFGCallBridgeACLV24ISO')

INSERT INTO cfg_locale VALUES(1033,8,2,26,0,'iS Link CSTA I','CFGiSLinkCSTAI')

INSERT INTO cfg_locale VALUES(1033,8,2,27,0,'Matra Link CSTA II','CFGMatraLinkCSTAII')

INSERT INTO cfg_locale VALUES(1033,8,2,28,0,'Application Link CSTA','CFGApplicationLinkCSTA')

INSERT INTO cfg_locale VALUES(1033,8,2,29,0,'iCAT 2.3 ICCL 2','CFGiCAT23ICCL2')

INSERT INTO cfg_locale VALUES(1033,8,2,30,0,'iCAT 3.x ICCL 3','CFGiCAT3xICCL3')

INSERT INTO cfg_locale VALUES(1033,8,2,31,0,'Application Link CSTA I','CFGApplicationLinkCSTAI')

INSERT INTO cfg_locale VALUES(1033,8,2,32,0,'Application Link CSTA II','CFGApplicationLinkCSTAII')

INSERT INTO cfg_locale VALUES(1033,8,2,33,0,'Generic Link','CFGGenericLink')

INSERT INTO cfg_locale VALUES(1033,8,2,34,0,'SCAI 11','CFGCompuCall09')

INSERT INTO cfg_locale VALUES(1033,8,2,35,0,'SCAI 12','CFGCompuCall10')

INSERT INTO cfg_locale VALUES(1033,8,2,36,0,'SCAI 13','CFGCompuCall11')

INSERT INTO cfg_locale VALUES(1033,8,2,37,0,'Application Bridge 7','CFGApplicationBridge7')

INSERT INTO cfg_locale VALUES(1033,8,2,38,0,'CallBridge4','CFGCallBridge4')

INSERT INTO cfg_locale VALUES(1033,8,2,39,0,'Delco ACD','CFGDelcoACD')

INSERT INTO cfg_locale VALUES(1033,8,2,40,0,'Hitachi Cx8000','CFGHitachiCx8000')

INSERT INTO cfg_locale VALUES(1033,8,2,41,0,'Starex Link','CFGStarexLink')

INSERT INTO cfg_locale VALUES(1033,8,2,42,0,'MiTai 7.3','CFGMiTai7_3')

INSERT INTO cfg_locale VALUES(1033,8,2,43,0,'Meridian Link ServicesSymposium','CFGMeridianLinkServices')

INSERT INTO cfg_locale VALUES(1033,8,2,44,0,'Application Connectivity Link CSTA','CFGApplicationConnectivityLinkCSTA')

INSERT INTO cfg_locale VALUES(1033,8,2,45,0,'CallBridge DX','CFGCallBridgeDX')

INSERT INTO cfg_locale VALUES(1033,8,2,46,0,'Coral Link','CFGCoralLink')

INSERT INTO cfg_locale VALUES(1033,8,3,0,0,'Unknown Target Type','Enum_CfgTargetType')

INSERT INTO cfg_locale VALUES(1033,8,3,1,0,'Target Agent','Enum_CfgTargetType')

INSERT INTO cfg_locale VALUES(1033,8,3,2,0,'Target Place','Enum_CfgTargetType')

INSERT INTO cfg_locale VALUES(1033,8,3,3,0,'Target Agent Group','Enum_CfgTargetType')

INSERT INTO cfg_locale VALUES(1033,8,3,4,0,'Target Place Group','Enum_CfgTargetType')

INSERT INTO cfg_locale VALUES(1033,8,3,5,0,'Target Routing Point','Enum_CfgTargetType')

INSERT INTO cfg_locale VALUES(1033,8,3,6,0,'Target Queue','Enum_CfgTargetType')

INSERT INTO cfg_locale VALUES(1033,8,3,7,0,'Target Network Destination','Enum_CfgTargetType')

INSERT INTO cfg_locale VALUES(1033,8,3,8,0,'Target Queue Group','Enum_CfgTargetType')

INSERT INTO cfg_locale VALUES(1033,8,3,9,0,'Target External Routing Point','Enum_CfgTargetType')

INSERT INTO cfg_locale VALUES(1033,8,3,10,0,'Target ISCC','Enum_CfgTargetType')

INSERT INTO cfg_locale VALUES(1033,8,4,0,0,'Unknown Route Type','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,1,0,'Default','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,2,0,'Label','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,3,0,'Overwrite DNIS','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,4,0,'DDD','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,5,0,'IDDD','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,6,0,'Direct','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,7,0,'Reject','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,8,0,'Announcement','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,9,0,'Post Feature','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,10,0,'Direct Agent','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,11,0,'Use External Protocol','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,12,0,'Get From DN','Enum_CfgRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,13,0,'Default','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,14,0,'Route','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,15,0,'Direct','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,16,0,'Re-Route','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,17,0,'Direct UUI','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,18,0,'Direct ANI','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,19,0,'Direct No Token','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,20,0,'DNIS Pooling','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,21,0,'Direct DNIS and ANI','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,22,0,'Direct Digits','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,23,0,'Forbidden','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,24,0,'ISCC defined protocol','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,25,0,'PullBack','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,4,26,0,'Direct Network Call ID','Enum_CfgXRouteType')

INSERT INTO cfg_locale VALUES(1033,8,5,0,0,'Unknown DN Type','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,1,0,'Extension','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,2,0,'ACD Position','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,3,8,'ACD Queue','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,4,8,'Routing Point','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,5,8,'Virtual Queue','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,6,8,'Virtual Routing Point','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,7,0,'Voice Treatment Port','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,8,0,'Voice Mail','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,9,0,'Mobile Station','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,10,0,'Call Processing Port','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,11,0,'Fax','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,12,0,'Modem','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,13,0,'Music Port','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,14,0,'Trunk','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,15,0,'Trunk Group','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,16,0,'Tie Line','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,17,0,'Tie Line Group','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,18,0,'Mixed','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,19,8,'External Routing Point','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,20,0,'Network Destination','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,21,8,'Service Number','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,22,8,'Routing Queue','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,23,0,'Communication DN','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,24,0,'E-mail Address','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,25,0,'Voice over IP Port','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,26,0,'Video over IP Port','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,27,0,'Chat','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,28,0,'CoBrowse','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,29,0,'Voice over IP Service','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,30,0,'Workflow','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,31,8,'Access Resource','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,5,32,0,'GVP DID','Enum_CfgDNType')

INSERT INTO cfg_locale VALUES(1033,8,6,0,0,'Unknown Application Type','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,1,4,'T-Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,2,4,'Stat Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,3,4,'Billing Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,4,0,'Billing Client','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,5,0,'Agent Pulse','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,6,4,'Voice Treatment Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,7,0,'Voice Treatment Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,8,4,'Database Access Point','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,9,4,'Call Concentrator','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,10,4,'CPD Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,11,4,'List Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,12,4,'Outbound Contact Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,13,0,'Outbound Contact Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,14,0,'Campaign Configuration Environment','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,15,4,'Universal Routing Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,16,0,'Strategy Builder','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,17,0,'Interaction Router Client','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,18,0,'Agent Desktop','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,19,0,'Configuration Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,20,0,'Call Center Pulse','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,21,4,'Configuration Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,22,0,'Third Party Application','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,23,4,'Third Party Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,24,0,'Strategy Simulator','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,25,0,'Strategy Scheduler','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,26,5,'DART Server','Obsolete')

INSERT INTO cfg_locale VALUES(1033,8,6,27,1,'DART Client','Obsolete')

INSERT INTO cfg_locale VALUES(1033,8,6,28,4,'Custom Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,29,5,'External Router','Obsolete')

INSERT INTO cfg_locale VALUES(1033,8,6,30,0,'Virtual Interactive-T','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,31,4,'Virtual Routing Point','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,32,5,'Database','Obsolete')

INSERT INTO cfg_locale VALUES(1033,8,6,33,4,'Web Option','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,34,4,'Detail Biller','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,35,4,'Summary Biller','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,36,4,'Network Overflow Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,37,4,'Backup Control Client','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,38,4,'Data Sourcer','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,39,0,'Data Modeling Assistant','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,40,4,'IVR Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,41,4,'I-Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,42,4,'Message Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,43,4,'Solution Control Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,44,0,'Solution Control Interface','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,45,4,'SNMP Agent','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,46,4,'DB Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,47,0,'WFM Client','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,48,4,'WFM Data Aggregator','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,49,0,'WFM Web Services','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,50,4,'WFM Schedule Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,51,0,'Interaction Routing Designer','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,52,0,'ETL Proxy','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,53,0,'Install-Time Configuration Utility','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,54,4,'GVP-Voice Communication Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,55,4,'GIM ETL','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,56,0,'VSS Shared','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,57,0,'VSS Console','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,58,4,'Data Mart','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,59,4,'Chat Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,60,4,'Callback Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,61,4,'Co-Browsing Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,62,4,'SMS Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,63,4,'Contact Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,64,4,'E-Mail Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,65,4,'MediaLink','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,66,4,'Web Interaction Requests Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,67,4,'Web Stat Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,68,4,'Web Interaction Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,69,4,'Web Option Route Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,70,0,'Web Client','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,71,0,'Contact Server Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,72,0,'Content Analyzer','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,73,0,'Response Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,74,4,'Voice over IP Controller','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,75,0,'Voice over IP Device','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,76,0,'Automated Workflow Engine','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,77,4,'High Availability Proxy','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,78,4,'Voice over IP Stream Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,79,4,'Voice over IP DMX Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,80,4,'Web API Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,81,4,'Load Balancer','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,82,4,'Application Cluster','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,83,4,'Load Distribution Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,84,4,'G-Proxy','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,85,4,'Genesys Interface Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,86,4,'GCN Delivery Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,87,0,'GCN Client','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,88,4,'IVR DirectTalk Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,89,4,'GCN Thin Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,90,4,'Classification Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,91,4,'Training Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,92,4,'Universal Callback Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,93,4,'CPD Server Proxy','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,94,4,'XLink Controller','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,95,4,'Knowledge Worker Portal','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,96,4,'WFM Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,97,4,'WFM Builder','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,98,4,'WFM Reports','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,99,4,'WFM Web','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,100,0,'Knowledge Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,101,4,'IVR Driver','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,102,4,'IVR Library','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,103,4,'LCS Adapter','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,104,4,'Desktop .NET Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,105,4,'Gplus Adapter for Siebel 7 Configuration Synchronization Component','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,106,4,'Gplus Adapter for Siebel 7 Campaign Synchronization Component','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,107,4,'Genesys Generic Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,108,0,'Genesys Generic Client','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,109,4,'Call Director','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,110,5,'SIP Communication Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,111,4,'Interaction Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,112,4,'Genesys Integration Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,113,4,'WFM Daemon','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,114,13,'GVP Policy Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,115,13,'GVP Cisco Queue Adapter','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,116,13,'GVP Text To Speech Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,117,13,'GVP ASR Log Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,118,13,'GVP Bandwidth Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,119,13,'GVP Events Collector','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,120,9,'GVP Cache Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,121,13,'GVP ASR Log Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,122,13,'GVP ASR Package Loader','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,123,13,'GVP IP Communication Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,124,13,'GVP 7.x Resource Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,125,13,'GVP SIP Session Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,126,9,'GVP Media Gateway','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,127,9,'GVP Soft Switch','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,128,13,'GVP Core Service','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,129,13,'GVP Voice Communication Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,130,13,'GVP Unified Login Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,131,13,'GVP Call Status Monitor','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,132,13,'GVP Reporter','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,133,13,'GVP H.323 Session Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,134,13,'GVP ASR Log Manager Agent','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,135,13,'GVP Genesys Queue Adapter','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,136,9,'GVP IServer','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,137,13,'GVP SCP Gateway','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,138,9,'GVP SRP Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,139,9,'GVP MRCP TTS Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,140,13,'GVP CCS Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,141,9,'GVP MRCP ASR Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,142,13,'GVP Network Monitor','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,143,12,'GVP OBN Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,144,13,'GVP SelfService Provisioning Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,145,4,'GVP Media Control Platform','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,146,4,'GVP Fetching Module','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,147,4,'GVP Media Control Platform Legacy Interpreter','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,148,4,'GVP Call Control Platform','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,149,4,'GVP Resource Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,150,4,'GVP Redundancy Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,151,4,'GVP Media Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,152,4,'GVP PSTN Connector','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,153,4,'GVP Reporting Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,154,4,'GVP SSG','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,155,4,'GVP CTI Connector','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,156,4,'Resource Access Point','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,157,0,'Interaction Workspace','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,158,0,'Advisors','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,159,4,'ESS Extensible Services','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,160,4,'Customer View','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,161,4,'Orchestration Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,162,1,'Reserved','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,163,4,'Capture Point','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,164,4,'Rules ESP Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,165,0,'Genesys Administrator','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,166,0,'iWD Manager','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,167,4,'iWD Runtime Node','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,168,4,'Business Rules Execution Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,169,4,'Business Rules Application Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,170,4,'VP Policy Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,171,4,'Social Messaging Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,172,4,'CSTA Connector','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,173,4,'VP MRCP Proxy','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,174,4,'UCM Connector','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,175,4,'OT ICS Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,176,4,'OT ICS OMPInfra','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,177,4,'Advisors-Contact Center Advisor','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,178,4,'Advisors-Frontline Advisor','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,179,4,'Advisors-Advisors Platform','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,180,4,'Advisors-Advisors Genesys Adapter','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,181,4,'Advisors-Advisors Cisco Adapter','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,182,4,'Federation Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,183,4,'Federation Stat Provider','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,184,4,'Genesys Administrator Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,185,4,'Web Engagement Backend Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,186,4,'Web Engagement Frontend Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,187,4,'WebRTC Gateway','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,188,4,'LRMServer','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,189,4,'RecordingCryptoServer','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,190,4,'Genesys Knowledge Center Server','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,191,4,'Genesys Knowledge Center CMS','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,192,4,'Reserved Application 8','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,193,4,'Reserved Application 9','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,194,4,'Reserved Application 10','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,195,0,'Reserved GUI Application 1','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,6,196,0,'Reserved GUI Application 2','Enum_CfgAppType')

INSERT INTO cfg_locale VALUES(1033,8,7,0,0,'Unknown Rank','CFGNORANK')

INSERT INTO cfg_locale VALUES(1033,8,7,1,0,'User','CFGUSER')

INSERT INTO cfg_locale VALUES(1033,8,7,2,0,'Designer','CFGDESIGNER')

INSERT INTO cfg_locale VALUES(1033,8,7,3,0,'Administrator','CFGTENANTADMINISTRATOR')

INSERT INTO cfg_locale VALUES(1033,8,7,4,0,'Service Administrator','CFGSERVICEADMINISTRATOR')

INSERT INTO cfg_locale VALUES(1033,8,7,5,0,'Super Administrator','CFGSUPERADMINISTRATOR')

INSERT INTO cfg_locale VALUES(1033,8,8,0,0,'Unknown Group Type','Enum_CfgDNGroupType')

INSERT INTO cfg_locale VALUES(1033,8,8,1,0,'Single Ports','Enum_CfgDNGroupType')

INSERT INTO cfg_locale VALUES(1033,8,8,2,0,'ACD Queues','Enum_CfgDNGroupType')

INSERT INTO cfg_locale VALUES(1033,8,8,3,0,'Routing Points','Enum_CfgDNGroupType')

INSERT INTO cfg_locale VALUES(1033,8,8,4,0,'Network Ports','Enum_CfgDNGroupType')

INSERT INTO cfg_locale VALUES(1033,8,8,5,0,'Service Numbers','Enum_CfgDNGroupType')

INSERT INTO cfg_locale VALUES(1033,8,9,0,0,'Unknown','Enum_CfgFlag')

INSERT INTO cfg_locale VALUES(1033,8,9,1,0,'False','Enum_CfgFlag')

INSERT INTO cfg_locale VALUES(1033,8,9,2,0,'True','Enum_CfgFlag')

INSERT INTO cfg_locale VALUES(1033,8,10,0,0,'Unknown Charge Type','Enum_CfgChargeType')

INSERT INTO cfg_locale VALUES(1033,8,10,1,0,'Free','Enum_CfgChargeType')

INSERT INTO cfg_locale VALUES(1033,8,10,2,0,'Flat Rate','Enum_CfgChargeType')

INSERT INTO cfg_locale VALUES(1033,8,10,3,0,'Instance','Enum_CfgChargeType')

INSERT INTO cfg_locale VALUES(1033,8,10,4,0,'Duration','Enum_CfgChargeType')

INSERT INTO cfg_locale VALUES(1033,8,11,0,0,'Unknown OS Type','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,1,0,'Solaris','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,2,0,'Solaris x86','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,3,0,'Tru64 Unix','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,4,0,'HP-UX','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,5,0,'IBM AIX','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,6,0,'SunOS','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,7,0,'Windows NT','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,8,0,'Windows','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,9,0,'IBM OS2','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,10,0,'Macintosh','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,11,0,'Tandem UNIX','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,12,0,'UNIX Ware','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,13,0,'Windows 2000','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,14,0,'Windows XP','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,15,0,'Windows Server 2003','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,16,0,'RedHat Enterprise Linux AS/Intel','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,17,0,'Windows Server 2008','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,18,0,'Windows Vista','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,19,0,'Windows Server 2012','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,11,20,0,'Linux','Enum_CfgOSType')

INSERT INTO cfg_locale VALUES(1033,8,12,0,0,'Unknown Host Type','Enum_CfgHostType')

INSERT INTO cfg_locale VALUES(1033,8,12,1,0,'Network Server','Enum_CfgHostType')

INSERT INTO cfg_locale VALUES(1033,8,12,2,0,'Tenant Server','Enum_CfgHostType')

INSERT INTO cfg_locale VALUES(1033,8,12,3,0,'Service Workstation','Enum_CfgHostType')

INSERT INTO cfg_locale VALUES(1033,8,12,4,0,'Tenant Workstation','Enum_CfgHostType')

INSERT INTO cfg_locale VALUES(1033,8,12,5,0,'Agent Workstation','Enum_CfgHostType')

INSERT INTO cfg_locale VALUES(1033,8,12,6,0,'Auxiliary Computer','Enum_CfgHostType')

INSERT INTO cfg_locale VALUES(1033,8,12,7,0,'GVP Workstation','Enum_CfgHostType')

INSERT INTO cfg_locale VALUES(1033,8,13,0,0,'Unknown Script Type','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,1,0,'Data Collection','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,2,0,'Service Selection','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,3,0,'Enhanced Queuing','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,4,0,'Simple Queuing','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,5,0,'Simple Routing','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,6,0,'Enhanced Routing','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,7,0,'Voice Data','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,8,0,'Outbound Campaign','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,9,0,'Outbound Format','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,10,0,'Outbound List','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,11,0,'Outbound Filter','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,12,0,'Outbound Treatment','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,13,0,'Outbound Alert','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,14,0,'Schedule','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,15,0,'Alarm Detection','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,16,0,'Alarm Reaction','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,17,0,'VSS System Schema','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,18,0,'VSS Shared Schema','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,19,0,'VSS Server Schema','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,20,0,'VSS Object','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,21,0,'E-mail Acknowledge Receipt','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,22,0,'Capacity Rule','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,23,0,'Interaction Queue','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,24,0,'Interaction Queue View','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,25,0,'Interaction Workbin','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,26,0,'Interaction Submitter','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,27,0,'Interaction Snapshot','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,28,0,'Business Process','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,29,0,'Supervisor Data','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,30,0,'Interaction Workflow Trigger','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,31,0,'GVP Report','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,32,0,'Outbound Schedule','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,33,0,'ESS Dial Plan','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,13,34,0,'Business Rule Data','Enum_CfgScriptType')

INSERT INTO cfg_locale VALUES(1033,8,14,0,0,'Unknown Action Code Type','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,1,0,'Inbound Call','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,2,0,'Outbound Call','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,3,0,'Internal Call','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,4,0,'Transfer','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,5,0,'Conference','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,6,0,'Login','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,7,0,'Logout','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,8,0,'Ready','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,9,0,'Not Ready','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,10,0,'Busy On','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,11,0,'Busy Off','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,12,0,'Forward On','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,14,13,0,'Forward Off','Enum_CfgActionCodeType')

INSERT INTO cfg_locale VALUES(1033,8,15,0,0,'Unknown Table Type','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,15,1,0,'Calling List','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,15,2,0,'Log Table','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,15,3,0,'ANI','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,15,4,0,'LATA','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,15,5,0,'NPA','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,15,6,0,'NPA-NXX','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,15,7,0,'State Code','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,15,8,0,'Info Digits','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,15,9,0,'Country Code','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,15,10,0,'Customer Defined Table','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,15,11,0,'Do Not Call List','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,15,12,0,'E-mail Contact List','Enum_CfgTableType')

INSERT INTO cfg_locale VALUES(1033,8,16,0,0,'Unknown Data Type','Enum_CfgDataType')

INSERT INTO cfg_locale VALUES(1033,8,16,1,0,'int','Enum_CfgDataType')

INSERT INTO cfg_locale VALUES(1033,8,16,2,0,'float','Enum_CfgDataType')

INSERT INTO cfg_locale VALUES(1033,8,16,3,0,'char','Enum_CfgDataType')

INSERT INTO cfg_locale VALUES(1033,8,16,4,0,'varchar','Enum_CfgDataType')

INSERT INTO cfg_locale VALUES(1033,8,16,5,0,'datetime','Enum_CfgDataType')

INSERT INTO cfg_locale VALUES(1033,8,17,0,0,'Unknown Field Type','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,1,0,'Record ID','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,2,0,'Contact Info','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,3,0,'Record Type','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,4,0,'Record Status','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,5,0,'Dialing Result','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,6,0,'Number of Attempts','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,7,0,'Scheduled Time','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,8,0,'Call Time','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,9,0,'From','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,10,0,'To','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,11,0,'Time Zone','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,12,0,'Campaign','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,13,0,'Agent','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,14,0,'Chain','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,15,0,'Number In Chain','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,16,0,'User-Defined Field','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,17,0,'ANI','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,18,0,'LATA','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,19,0,'NPA','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,20,0,'NPA-NXX','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,21,0,'State Code','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,22,0,'Info Digits','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,23,0,'Country Code','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,24,0,'Contact Info Type','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,25,0,'Group','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,26,0,'Application','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,27,0,'Treatments History','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,28,0,'Media Reference','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,29,0,'E-mail Subject','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,30,0,'E-mail Template ID','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,17,31,0,'Switch ID','Enum_CfgFieldType')

INSERT INTO cfg_locale VALUES(1033,8,18,0,0,'Ok','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,1,0,'Transferred','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,2,0,'Conferenced','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,3,0,'General Error','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,4,0,'System Error','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,5,0,'Remote Release','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,6,0,'Busy','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,7,0,'No Answer','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,8,0,'SIT Detected','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,9,0,'Answering Machine Detected','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,10,0,'All Trunks Busy','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,11,0,'SIT Invalid Number','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,12,0,'SIT VC (Vacant Code)','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,13,0,'SIT IC (Intercept)','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,14,0,'SIT Unknown Call State','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,15,0,'SIT NC (No Circuit)','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,16,0,'SIT RO (Reorder)','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,17,0,'Fax Detected','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,18,0,'Queue Full','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,19,0,'Cleared','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,20,0,'Overflowed','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,21,0,'Abandoned','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,22,0,'Redirected','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,23,0,'Forwarded','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,24,0,'Consult','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,25,0,'Pickedup','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,26,0,'Dropped','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,27,0,'Dropped on No Answer','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,28,0,'Unknown Call Result','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,29,0,'Covered','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,30,0,'Converse-On','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,31,0,'Bridged','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,32,0,'Silence','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,33,0,'Answer','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,34,0,'NU Tone','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,35,0,'No Dial Tone','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,36,0,'No Progress','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,37,0,'No RingBack Tone','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,38,0,'No Established Detected','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,39,0,'Pager Detected','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,40,0,'Wrong Party','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,41,0,'Dial Error','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,42,0,'Call Drop Error','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,43,0,'Switch Error','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,44,0,'No Port Available','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,45,0,'Transfer Error','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,46,0,'Stale','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,47,0,'Agent CallBack Error','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,48,0,'Group CallBack Error','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,49,0,'Deafend','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,50,0,'Held','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,51,0,'Do Not Call','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,52,0,'Cancel Record','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,18,53,0,'Wrong Number','Enum_GctiCallState')

INSERT INTO cfg_locale VALUES(1033,8,19,0,0,'Unknown Action','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,1,0,'No Treatment','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,2,0,'Update all records in chain','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,3,0,'Redial','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,4,0,'Retry in','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,5,0,'Retry at specified date','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,6,0,'Next in chain','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,7,0,'Next in chain after','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,8,0,'Next in chain at specified date','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,9,0,'Assign to Group','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,10,0,'Mark as Agent Error','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,11,1,'Reschedule','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,12,0,'Delegate for processing','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,19,13,0,'Execute SQL statement','Enum_CfgRecActionCode')

INSERT INTO cfg_locale VALUES(1033,8,20,0,0,'Unknown Action Code','Enum_CfgCallActionCode')

INSERT INTO cfg_locale VALUES(1033,8,20,1,0,'Connect','Enum_CfgCallActionCode')

INSERT INTO cfg_locale VALUES(1033,8,20,2,0,'Drop','Enum_CfgCallActionCode')

INSERT INTO cfg_locale VALUES(1033,8,20,3,0,'Mute Transfer','Enum_CfgCallActionCode')

INSERT INTO cfg_locale VALUES(1033,8,20,4,0,'Transfer','Enum_CfgCallActionCode')

INSERT INTO cfg_locale VALUES(1033,8,20,5,0,'Route','Enum_CfgCallActionCode')

INSERT INTO cfg_locale VALUES(1033,8,20,6,0,'Play a message','Enum_CfgCallActionCode')

INSERT INTO cfg_locale VALUES(1033,8,20,7,0,'Send a fax','Enum_CfgCallActionCode')

INSERT INTO cfg_locale VALUES(1033,8,20,8,0,'Send a page','Enum_CfgCallActionCode')

INSERT INTO cfg_locale VALUES(1033,8,20,9,0,'Send an e-mail','Enum_CfgCallActionCode')

INSERT INTO cfg_locale VALUES(1033,8,21,0,0,'Unknown Dialing Mode','Enum_CfgDialMode')

INSERT INTO cfg_locale VALUES(1033,8,21,1,0,'Predictive','Enum_CfgDialMode')

INSERT INTO cfg_locale VALUES(1033,8,21,2,0,'Progressive','Enum_CfgDialMode')

INSERT INTO cfg_locale VALUES(1033,8,21,3,0,'Preview','Enum_CfgDialMode')

INSERT INTO cfg_locale VALUES(1033,8,21,4,0,'Progressive with seizing','Enum_CfgDialMode')

INSERT INTO cfg_locale VALUES(1033,8,21,5,0,'Predictive with seizing','Enum_CfgDialMode')

INSERT INTO cfg_locale VALUES(1033,8,21,6,0,'Power','Enum_CfgDialMode')

INSERT INTO cfg_locale VALUES(1033,8,21,7,0,'Power with seizing','Enum_CfgDialMode')

INSERT INTO cfg_locale VALUES(1033,8,21,8,0,'Push Preview','Enum_CfgDialMode')

INSERT INTO cfg_locale VALUES(1033,8,21,9,0,'Progressive GVP','Enum_CfgDialMode')

INSERT INTO cfg_locale VALUES(1033,8,21,10,0,'Predictive GVP','Enum_CfgDialMode')

INSERT INTO cfg_locale VALUES(1033,8,21,11,0,'Power GVP','Enum_CfgDialMode')

INSERT INTO cfg_locale VALUES(1033,8,22,0,0,'Unknown Operation Mode','Enum_CfgOperationMode')

INSERT INTO cfg_locale VALUES(1033,8,22,1,0,'Manual','Enum_CfgOperationMode')

INSERT INTO cfg_locale VALUES(1033,8,22,2,0,'Scheduled','Enum_CfgOperationMode')

INSERT INTO cfg_locale VALUES(1033,8,23,0,0,'Unknown Optimization Criteria','Enum_CfgOptimizationMethod')

INSERT INTO cfg_locale VALUES(1033,8,23,1,0,'Agent Busy Factor','Enum_CfgOptimizationMethod')

INSERT INTO cfg_locale VALUES(1033,8,23,2,0,'Overdial Rate','Enum_CfgOptimizationMethod')

INSERT INTO cfg_locale VALUES(1033,8,23,3,0,'Average Waiting Time','Enum_CfgOptimizationMethod')

INSERT INTO cfg_locale VALUES(1033,8,23,4,0,'Average Distribution Time','Enum_CfgOptimizationMethod')

INSERT INTO cfg_locale VALUES(1033,8,23,5,0,'Maximum Gain','Enum_CfgOptimizationMethod')

INSERT INTO cfg_locale VALUES(1033,8,24,0,0,'Unknown IVR Type','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,1,0,'Conversant','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,2,0,'WVR for AIX','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,3,1,'Syntellect Vocal Point','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,4,1,'Syntellect Premier','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,5,1,'Syntellect Vista','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,6,1,'Voicetek','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,7,1,'Agility','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,8,1,'Meridian Integrated','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,9,1,'Symposium Open','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,10,0,'Edify','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,11,1,'Brite','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,12,0,'ShowNTel','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,13,0,'Intervoice Brite','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,14,0,'Periphonics VPS/is','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,15,1,'Amerex','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,16,0,'WVR for Windows','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,17,0,'Genesys Voice Platform','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,18,0,'MPS','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,19,0,'Aspect CSS','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,20,0,'Microsoft Speech Server','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,21,0,'Other IVR Type','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,24,22,0,'Envox','Enum_CfgIVRType')

INSERT INTO cfg_locale VALUES(1033,8,25,0,0,'Unknown Transaction Type','CFGTRTNoTransactionType')

INSERT INTO cfg_locale VALUES(1033,8,25,1,0,'Interaction Data','CFGTRTCallData')

INSERT INTO cfg_locale VALUES(1033,8,25,2,0,'Attribute','CFGTRTBusinessAttribute')

INSERT INTO cfg_locale VALUES(1033,8,25,3,0,'Business Rule','CFGTRTBusinessSituation')

INSERT INTO cfg_locale VALUES(1033,8,25,4,0,'Routing Rule','CFGTRTBusinessRule')

INSERT INTO cfg_locale VALUES(1033,8,25,5,0,'Business Action','CFGTRTBusinessAction')

INSERT INTO cfg_locale VALUES(1033,8,25,16,0,'Stat Filter','CFGTRTStatFilter=CFGTransaction')

INSERT INTO cfg_locale VALUES(1033,8,25,17,0,'Stat Time Range','CFGTRTStatTimeRange')

INSERT INTO cfg_locale VALUES(1033,8,25,18,0,'Stat Time Profile','CFGTRTStatTimeProfile')

INSERT INTO cfg_locale VALUES(1033,8,25,19,0,'Stat Type','CFGTRTStatType')

INSERT INTO cfg_locale VALUES(1033,8,25,20,0,'Statistic','CFGTRTStatMetric')

INSERT INTO cfg_locale VALUES(1033,8,25,21,0,'List','CFGTRTList')

INSERT INTO cfg_locale VALUES(1033,8,25,22,0,'Macro','CFGTRTMacro')

INSERT INTO cfg_locale VALUES(1033,8,26,0,0,'Unknown Solution Type','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,1,0,'Default Solution Type','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,2,0,'Integrated Screen Pop','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,3,0,'Enterprise Routing','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,4,0,'Network Routing','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,5,0,'Outbound Dialing','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,6,0,'Workforce Manager','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,7,0,'Voice Self Service','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,8,0,'Internet Contact Solution','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,9,0,'Workflow Routing','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,10,0,'Information Analysis','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,11,0,'Knowledge Worker','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,12,0,'Branch Office','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,13,0,'Framework','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,14,0,'Express Edition','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,15,0,'Multimedia','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,26,16,0,'Desktop .NET Server Solution','Enum_CfgSolutionType')

INSERT INTO cfg_locale VALUES(1033,8,27,0,0,'Unknown Alarm Category','Enum_CfgAlarmCategory')

INSERT INTO cfg_locale VALUES(1033,8,27,1,0,'Critical','Enum_CfgAlarmCategory')

INSERT INTO cfg_locale VALUES(1033,8,27,2,0,'Major','Enum_CfgAlarmCategory')

INSERT INTO cfg_locale VALUES(1033,8,27,3,0,'Minor','Enum_CfgAlarmCategory')

INSERT INTO cfg_locale VALUES(1033,8,28,0,0,'Unknown Object','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1,0,'Switch','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,2,0,'DN','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,3,0,'Person','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,4,0,'Place','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,5,0,'Agent Group','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,6,0,'Place Group','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,7,0,'Tenant','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,8,0,'Solution','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,9,0,'Application','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,10,0,'Host','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,11,0,'Switching Office','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,12,0,'Script','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,13,0,'Skill','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,14,0,'Action Code','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,15,0,'Agent Login','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,16,0,'Transaction','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,17,0,'DN Group','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,18,0,'Statistical Day','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,19,0,'Statistical Table','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,20,0,'Application Template','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,21,0,'Access Group','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,22,0,'Folder','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,23,0,'Field','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,24,0,'Format','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,25,0,'Table Access','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,26,0,'Calling List','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,27,0,'Campaign','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,28,0,'Treatment','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,29,0,'Filter','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,30,0,'Time Zone','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,31,0,'Voice Prompt','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,32,0,'IVR Port','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,33,0,'IVR','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,34,0,'Alarm Condition','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,35,0,'Business Attribute','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,36,0,'Business Attribute Value','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,37,0,'Objective Table','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,38,0,'Campaign Group','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,39,0,'GVP Reseller','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,40,0,'GVP Customer','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,41,0,'GVP IVR Profile','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,42,0,'Scheduled Task','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,43,0,'Role','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,44,0,'Agent Login Info','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,45,0,'DN Info','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,46,0,'Service Info','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,47,0,'Skill Level','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,48,0,'Switch Access Code','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,49,0,'DN Access Number','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1020,0,'Application Rank','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1025,0,'Application Service Permission','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1027,0,'Sub code','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1028,0,'Interval Count','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1022,0,'Agent Login Info','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1023,0,'DN Info','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1024,0,'Service Info','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1021,0,'Skill Level','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1017,0,'Switch Access Code','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1019,0,'DN Access Number','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1029,0,'Calling List Info','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1030,0,'Campaign Group Info','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1031,0,'Log Event','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1032,0,'Solution Component','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1033,0,'Cfg ID','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1034,0,'Cfg ACE','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1035,0,'Cfg ACL','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1036,0,'Server Host ID','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1037,0,'Server Version','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1038,0,'Connection Info','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1040,0,'Solution Component Definition','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1041,0,'Objective Table Record','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1042,0,'Update Package Record','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1043,0,'Library Link','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1044,0,'Object Resource','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1045,0,'Port Info','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,28,1046,0,'Role Member','Enum_CfgObjectType')

INSERT INTO cfg_locale VALUES(1033,8,29,0,0,'Unknown HA Type','CFGHTNoHAType')

INSERT INTO cfg_locale VALUES(1033,8,29,1,0,'Not Specified','CFGHTColdStanby')

INSERT INTO cfg_locale VALUES(1033,8,29,2,0,'Warm Standby','CFGHTWarmStanby')

INSERT INTO cfg_locale VALUES(1033,8,29,3,0,'Hot Standby','CFGHTHotStanby')

INSERT INTO cfg_locale VALUES(1033,8,30,0,0,'Unknown Trace Mode','CFGTMNoTraceMode')

INSERT INTO cfg_locale VALUES(1033,8,30,1,0,'Trace Is Turned Off','CFGTMNone')

INSERT INTO cfg_locale VALUES(1033,8,30,2,0,'Trace On Client Side','CFGTMLocal')

INSERT INTO cfg_locale VALUES(1033,8,30,3,0,'Trace On Server Side','CFGTMRemote')

INSERT INTO cfg_locale VALUES(1033,8,30,4,0,'Trace On Both Sides','CFGTMBoth')

INSERT INTO cfg_locale VALUES(1033,8,31,0,0,'Unknown Selection Mode','CFGSMNoSelectionMode')

INSERT INTO cfg_locale VALUES(1033,8,31,1,0,'Select by Application','CFGSMByAppDBID')

INSERT INTO cfg_locale VALUES(1033,8,31,2,0,'Select by Application Type','CFGSMAppType')

INSERT INTO cfg_locale VALUES(1033,8,31,3,0,'Select by Any','CFGSMByAny')

INSERT INTO cfg_locale VALUES(1033,8,32,0,0,'Error','CFGError')

INSERT INTO cfg_locale VALUES(1033,8,32,1,0,'Registered','CFGRegistered')

INSERT INTO cfg_locale VALUES(1033,8,32,2,0,'Unregistered','CFGUnregistered')

INSERT INTO cfg_locale VALUES(1033,8,32,3,0,'Object Added','CFGObjectAdded')

INSERT INTO cfg_locale VALUES(1033,8,32,4,0,'Object Deleted','CFGObjectDeleted')

INSERT INTO cfg_locale VALUES(1033,8,32,5,0,'Object Info Changed','CFGObjectInfoChanged')

INSERT INTO cfg_locale VALUES(1033,8,32,6,0,'Object Info','CFGObjectInfo')

INSERT INTO cfg_locale VALUES(1033,8,32,7,0,'Objects Count','CFGObjectCount')

INSERT INTO cfg_locale VALUES(1033,8,32,8,0,'End Of Objects List','CFGEndObjectList')

INSERT INTO cfg_locale VALUES(1033,8,32,9,0,'DB Disconnected','CFGDBDisconnected')

INSERT INTO cfg_locale VALUES(1033,8,32,10,0,'DB Connected','CFGDBConnected')

INSERT INTO cfg_locale VALUES(1033,8,32,11,0,'Server Disconnected','CFGServerDisconnected')

INSERT INTO cfg_locale VALUES(1033,8,32,12,0,'Client Registered','CFGClientRegistered')

INSERT INTO cfg_locale VALUES(1033,8,32,13,0,'Unknown Event','CFGUnknownEvent')

INSERT INTO cfg_locale VALUES(1033,8,32,14,0,'Access Info','CFGAccessInfo')

INSERT INTO cfg_locale VALUES(1033,8,32,15,0,'Access Changed','CFGAccessChanged')

INSERT INTO cfg_locale VALUES(1033,8,32,16,0,'Brief Info','CFGBriefInfo')

INSERT INTO cfg_locale VALUES(1033,8,32,17,0,'Account Info','CFGAccountInfo')

INSERT INTO cfg_locale VALUES(1033,8,32,18,0,'Account Changed','CFGAccountChanged')

INSERT INTO cfg_locale VALUES(1033,8,32,19,0,'ACL Brief Info','CFGACLBriefInfo')

INSERT INTO cfg_locale VALUES(1033,8,32,20,0,'End HistoryLog','CFGEndHistoryLog')

INSERT INTO cfg_locale VALUES(1033,8,32,21,0,'Operational Mode Set','CFGOperationalModeSet')

INSERT INTO cfg_locale VALUES(1033,8,32,22,0,'Operational Mode','CFGOperationalMode')

INSERT INTO cfg_locale VALUES(1033,8,32,23,0,'Object Added To Folder','CFGObjectAddedToFolder')

INSERT INTO cfg_locale VALUES(1033,8,32,24,0,'Object Permissions','CFGObjectPermissions')

INSERT INTO cfg_locale VALUES(1033,8,32,25,0,'Ext Object Info','CFGExtObjectInfo')

INSERT INTO cfg_locale VALUES(1033,8,32,26,0,'Read Config Registered','CFGReadConfigRegistered')

INSERT INTO cfg_locale VALUES(1033,8,32,27,0,'Read Config Unregistered','CFGReadConfigUnregistered')

INSERT INTO cfg_locale VALUES(1033,8,32,28,0,'Read Config','CFGReadConfig')

INSERT INTO cfg_locale VALUES(1033,8,32,29,0,'Schema Info','CFGSchemaInfo')

INSERT INTO cfg_locale VALUES(1033,8,32,30,0,'Filter Result','CFGFilterResult')

INSERT INTO cfg_locale VALUES(1033,8,32,31,0,'Locale Info','CFGLocaleInfo')

INSERT INTO cfg_locale VALUES(1033,8,33,0,0,'Unknown Startup Type','CFGSUTNoStartupType')

INSERT INTO cfg_locale VALUES(1033,8,33,1,0,'Automatic','CFGSUTAutomatic')

INSERT INTO cfg_locale VALUES(1033,8,33,2,0,'Manual','CFGSUTManual')

INSERT INTO cfg_locale VALUES(1033,8,33,3,0,'Disabled','CFGSUTDisabled')

INSERT INTO cfg_locale VALUES(1033,8,34,1310720000,0,'(null)','PID_CfgObject_NoID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310720001,0,'DBID','PID_CfgObject_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310720002,0,'Name','PID_CfgObject_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1310720003,0,'Type','PID_CfgObject_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1310720004,0,'Tenant','PID_CfgObject_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310720005,0,'State','PID_CfgObject_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1310720006,0,'Annex','PID_CfgObject_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1310720007,0,'CSID','PID_CfgObject_CSID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310720008,0,'Linked ID','PID_CfgObject_LinkedObject')

INSERT INTO cfg_locale VALUES(1033,8,34,1310720009,0,'(null)','PID_CfgObject_WizardProgID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310785536,1,'Switch','PID_CfgSwitch')

INSERT INTO cfg_locale VALUES(1033,8,34,1310785537,1,'DBID','PID_CfgSwitch_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310785538,7,'Tenant','PID_CfgSwitch_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310785539,11,'Switching Office','PID_CfgSwitch_physSwitchDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310785540,25,'Switch Type','PID_CfgSwitch_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1310785541,0,'Name','PID_CfgSwitch_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1310785542,9,'T-Server','PID_CfgSwitch_TServerDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310785543,34,'Link Type','PID_CfgSwitch_linkType')

INSERT INTO cfg_locale VALUES(1033,8,34,1310785544,48,'Switch Access Codes','PID_CfgSwitch_switchAccessCodes')

INSERT INTO cfg_locale VALUES(1033,8,34,1310785545,0,'DN Range','PID_CfgSwitch_DNRange')

INSERT INTO cfg_locale VALUES(1033,8,34,1310785546,4,'State','PID_CfgSwitch_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1310785547,0,'Annex','PID_CfgSwitch_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851072,2,'DN','PID_CfgDN')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851073,2,'DBID','PID_CfgDN_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851074,1,'Switch','PID_CfgDN_switchDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851075,7,'Tenant','PID_CfgDN_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851076,29,'Type','PID_CfgDN_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851077,0,'Number','PID_CfgDN_number')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851078,0,'Association','PID_CfgDN_association')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851079,2,'Default DNs','PID_CfgDN_destDNDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851080,3,'Login Flag','PID_CfgDN_loginFlag')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851081,0,'DN Login ID','PID_CfgDN_DNLoginID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851082,3,'Register','PID_CfgDN_registerAll')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851083,6,'Group','PID_CfgDN_groupDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851084,0,'Trunks','PID_CfgDN_trunks')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851085,13,'Route Type','PID_CfgDN_routeType')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851086,0,'Override','PID_CfgDN_override')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851087,4,'State','PID_CfgDN_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851088,0,'Annex','PID_CfgDN_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851089,0,'Alias','PID_CfgDN_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851090,3,'Use Override','PID_CfgDN_useOverride')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851091,0,'Switch-specific Type','PID_CfgDN_switchSpecificType')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851092,49,'Access Numbers','PID_CfgDN_accessNumbers')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916608,3,'Person','PID_CfgPerson')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916609,3,'DBID','PID_CfgPerson_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916610,7,'Tenant','PID_CfgPerson_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916611,0,'Last Name','PID_CfgPerson_lastName')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916612,0,'First Name','PID_CfgPerson_firstName')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916613,0,'Address Line 1','PID_CfgPerson_address_addressLine1')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916614,0,'Address Line 2','PID_CfgPerson_address_addressLine2')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916615,0,'Address Line 3','PID_CfgPerson_address_addressLine3')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916616,0,'Address Line 4','PID_CfgPerson_address_addressLine4')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916617,0,'Address Line 5','PID_CfgPerson_address_addressLine5')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916618,0,'Office','PID_CfgPerson_phones_office')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916619,0,'Home','PID_CfgPerson_phones_home')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916620,0,'Mobile','PID_CfgPerson_phones_mobile')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916621,0,'Pager','PID_CfgPerson_phones_pager')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916622,0,'Fax','PID_CfgPerson_phones_fax')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916623,0,'Modem','PID_CfgPerson_phones_modem')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916624,0,'Phones Comment','PID_CfgPerson_phones_phonesComment')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916625,0,'Birth Date','PID_CfgPerson_birthdate')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916626,0,'Comment','PID_CfgPerson_comment')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916627,0,'Employee ID','PID_CfgPerson_employeeID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916628,0,'User Name','PID_CfgPerson_userName')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916629,0,'Password','PID_CfgPerson_password')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916630,39,'Application Ranks','PID_CfgPerson_appRanks')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916631,3,'Agent','PID_CfgPerson_isAgent')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916632,4,'Default Place','PID_CfgPerson_agentInfo_placeDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916633,47,'Skill Levels','PID_CfgPerson_agentInfo_skillLevels')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916634,44,'Agent Logins','PID_CfgPerson_agentInfo_agentLogins')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916635,3,'Administrator','PID_CfgPerson_isAdmin')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916636,7,'Assigned Tenants','PID_CfgPerson_assignedTenantDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916637,4,'State','PID_CfgPerson_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916638,0,'Annex','PID_CfgPerson_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1310982144,4,'Place','PID_CfgPlace')

INSERT INTO cfg_locale VALUES(1033,8,34,1310982145,4,'DBID','PID_CfgPlace_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310982146,7,'Tenant','PID_CfgPlace_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310982147,0,'Name','PID_CfgPlace_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1310982148,2,'DNs','PID_CfgPlace_DNDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1310982149,4,'State','PID_CfgPlace_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1310982150,0,'Annex','PID_CfgPlace_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047680,5,'Agent Group','PID_CfgAgentGroup')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047681,5,'DBID','PID_CfgAgentGroup_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047682,7,'Tenant','PID_CfgAgentGroup_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047683,0,'Name','PID_CfgAgentGroup_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047684,3,'Supervisor','PID_CfgAgentGroup_managerDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047685,2,'Origination DNs','PID_CfgAgentGroup_routeDNDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047686,19,'Capacity Table','PID_CfgAgentGroup_groupInfo_capacityTableDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047687,19,'Quota Table','PID_CfgAgentGroup_groupInfo_quotaTableDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047688,4,'State','PID_CfgAgentGroup_groupInfo_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047689,0,'Annex','PID_CfgAgentGroup_groupInfo_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047690,3,'Agents','PID_CfgAgentGroup_agentDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113216,6,'Place Group','PID_CfgPlaceGroup')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113217,6,'DBID','PID_CfgPlaceGroup_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113218,7,'Tenant','PID_CfgPlaceGroup_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113219,0,'Name','PID_CfgPlaceGroup_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113220,3,'Supervisor','PID_CfgPlaceGroup_managerDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113221,2,'Origination DNs','PID_CfgPlaceGroup_routeDNDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113222,19,'Capacity Table','PID_CfgPlaceGroup_groupInfo_capacityTableDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113223,19,'Quota Table','PID_CfgPlaceGroup_groupInfo_quotaTableDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113224,4,'State','PID_CfgPlaceGroup_groupInfo_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113225,0,'Annex','PID_CfgPlaceGroup_groupInfo_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113226,4,'Places','PID_CfgPlaceGroup_placeDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178752,7,'Tenant','PID_CfgTenant')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178753,7,'DBID','PID_CfgTenant_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178754,0,'Name','PID_CfgTenant_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178755,3,'Service Provider','PID_CfgTenant_isServiceProvider')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178756,0,'Password','PID_CfgTenant_password')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178757,0,'Address Line 1','PID_CfgTenant_address_addressLine1')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178758,0,'Address Line 2','PID_CfgTenant_address_addressLine2')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178759,0,'Address Line 3','PID_CfgTenant_address_addressLine3')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178760,0,'Address Line 4','PID_CfgTenant_address_addressLine4')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178761,0,'Address Line 5','PID_CfgTenant_address_addressLine5')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178762,0,'Chargeable Number','PID_CfgTenant_chargeableNumber')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178763,3,'Tenant Person','PID_CfgTenant_tenantPersonDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178764,3,'Provider Person','PID_CfgTenant_providerPersonDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178765,46,'Service Info','PID_CfgTenant_serviceInfo')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178766,3,'Super Tenant','PID_CfgTenant_isSuperTenant')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178767,7,'Tenants','PID_CfgTenant_tenantDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178768,4,'State','PID_CfgTenant_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178769,0,'Annex','PID_CfgTenant_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244288,8,'Service','PID_CfgService')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244289,8,'DBID','PID_CfgService_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244290,0,'Name','PID_CfgService_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244291,0,'Abbreviation','PID_CfgService_abbr')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244292,5,'Type','PID_CfgService_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244293,40,'Application Service Permissions','PID_CfgService_appServicePermissions')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244294,4,'State','PID_CfgService_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244295,0,'Annex','PID_CfgService_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244296,14,'Solution Type','PID_CfgService_solutionType')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244297,51,'Solution Components','PID_CfgService_components')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244298,9,'Solution Control Server','PID_CfgService_SCSDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244299,7,'Assigned Tenant','PID_CfgService_assignedTenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244300,0,'Version','PID_CfgService_version')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244301,53,'Component Definitions','PID_CfgService_componentDefinitions')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309824,9,'Application','PID_CfgApplication')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309825,9,'DBID','PID_CfgApplication_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309826,0,'Name','PID_CfgApplication_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309827,0,'Password','PID_CfgApplication_password')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309828,53,'Type','PID_CfgApplication_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309829,0,'Version','PID_CfgApplication_version')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309830,9,'Connections','PID_CfgApplication_appServerDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309831,7,'Tenants','PID_CfgApplication_tenantDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309832,3,'Server','PID_CfgApplication_isServer')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309833,10,'Host','PID_CfgApplication_serverInfo_hostDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309834,0,'Communication Port','PID_CfgApplication_serverInfo_port')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309835,9,'Backup Server','PID_CfgApplication_serverInfo_backupServerDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309836,0,'Timeout','PID_CfgApplication_serverInfo_timeout')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309837,0,'Attempts','PID_CfgApplication_serverInfo_attempts')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309838,0,'Options','PID_CfgApplication_options')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309839,4,'State','PID_CfgApplication_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309840,0,'Annex','PID_CfgApplication_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309841,20,'Application Template','PID_CfgApplication_appPrototypeDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309842,0,'Flexible Properties','PID_CfgApplication_flexibleProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309843,0,'Working Directory','PID_CfgApplication_workDirectory')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309844,0,'Command Line','PID_CfgApplication_commandLine')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309845,3,'Auto Restart','PID_CfgApplication_autoRestart')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309846,0,'Startup Timeout','PID_CfgApplication_startupTimeout')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309847,0,'Shutdown Timeout','PID_CfgApplication_shutdownTimeout')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309848,4,'Redundancy Type','PID_CfgApplication_redundancyType')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309849,3,'Primary','PID_CfgApplication_isPrimary')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309854,0,'componentType','PID_componentType')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375360,10,'Host','PID_CfgHost')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375361,10,'DBID','PID_CfgHost_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375362,0,'Name','PID_CfgHost_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375363,0,'HWID','PID_CfgHost_HWID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375364,0,'IP Address','PID_CfgHost_IPaddress')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375365,12,'OS Type','PID_CfgHost_OSinfo_OStype')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375366,0,'OS Version','PID_CfgHost_OSinfo_OSversion')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375367,7,'Type','PID_CfgHost_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375368,0,'Address Line 1','PID_CfgHost_address_addressLine1')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375369,0,'Address Line 2','PID_CfgHost_address_addressLine2')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375370,0,'Address Line 3','PID_CfgHost_address_addressLine3')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375371,0,'Address Line 4','PID_CfgHost_address_addressLine4')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375372,0,'Address Line 5','PID_CfgHost_address_addressLine5')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375373,3,'Contact Person','PID_CfgHost_contactPersonDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375374,0,'Comment','PID_CfgHost_comment')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375375,4,'State','PID_CfgHost_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375376,0,'Annex','PID_CfgHost_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375377,0,'LCA Port','PID_CfgHost_LCAPort')

INSERT INTO cfg_locale VALUES(1033,8,34,1311440896,11,'Switching Office','PID_CfgPhysicalSwitch')

INSERT INTO cfg_locale VALUES(1033,8,34,1311440897,11,'DBID','PID_CfgPhysicalSwitch_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311440898,0,'Name','PID_CfgPhysicalSwitch_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311440899,25,'Switch Type','PID_CfgPhysicalSwitch_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1311440900,0,'Address Line 1','PID_CfgPhysicalSwitch_address_addressLine1')

INSERT INTO cfg_locale VALUES(1033,8,34,1311440901,0,'Address Line 2','PID_CfgPhysicalSwitch_address_addressLine2')

INSERT INTO cfg_locale VALUES(1033,8,34,1311440902,0,'Address Line 3','PID_CfgPhysicalSwitch_address_addressLine3')

INSERT INTO cfg_locale VALUES(1033,8,34,1311440903,0,'Address Line 4','PID_CfgPhysicalSwitch_address_addressLine4')

INSERT INTO cfg_locale VALUES(1033,8,34,1311440904,0,'Address Line 5','PID_CfgPhysicalSwitch_address_addressLine5')

INSERT INTO cfg_locale VALUES(1033,8,34,1311440905,3,'Contact Person','PID_CfgPhysicalSwitch_contactPersonDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311440906,4,'State','PID_CfgPhysicalSwitch_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311440907,0,'Annex','PID_CfgPhysicalSwitch_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311506432,12,'Script','PID_CfgScript')

INSERT INTO cfg_locale VALUES(1033,8,34,1311506433,12,'DBID','PID_CfgScript_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311506434,0,'Name','PID_CfgScript_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311506435,7,'Tenant','PID_CfgScript_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311506436,0,'Index','PID_CfgScript_index')

INSERT INTO cfg_locale VALUES(1033,8,34,1311506437,17,'Script Type','PID_CfgScript_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1311506438,3,'Contact Person','PID_CfgScript_contactPersonDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311506439,4,'State','PID_CfgScript_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311506440,0,'Annex','PID_CfgScript_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311571968,13,'Skill','PID_CfgSkill')

INSERT INTO cfg_locale VALUES(1033,8,34,1311571969,13,'DBID','PID_CfgSkill_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311571970,0,'Name','PID_CfgSkill_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311571971,7,'Tenant','PID_CfgSkill_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311571972,4,'State','PID_CfgSkill_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311571973,0,'Annex','PID_CfgSkill_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311637504,14,'Action Code','PID_CfgActionCode')

INSERT INTO cfg_locale VALUES(1033,8,34,1311637505,14,'DBID','PID_CfgActionCode_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311637506,7,'Tenant','PID_CfgActionCode_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311637507,0,'Name','PID_CfgActionCode_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311637508,14,'Type','PID_CfgActionCode_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1311637509,0,'Code','PID_CfgActionCode_code')

INSERT INTO cfg_locale VALUES(1033,8,34,1311637510,41,'Subcodes','PID_CfgActionCode_subcodes')

INSERT INTO cfg_locale VALUES(1033,8,34,1311637511,4,'State','PID_CfgActionCode_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311637512,0,'Annex','PID_CfgActionCode_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311703040,15,'Agent Login','PID_CfgAgentLogin')

INSERT INTO cfg_locale VALUES(1033,8,34,1311703041,15,'DBID','PID_CfgAgentLogin_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311703042,1,'Switch','PID_CfgAgentLogin_switchDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311703043,7,'Tenant','PID_CfgAgentLogin_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311703044,0,'Code','PID_CfgAgentLogin_loginCode')

INSERT INTO cfg_locale VALUES(1033,8,34,1311703045,4,'State','PID_CfgAgentLogin_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311703046,0,'Annex','PID_CfgAgentLogin_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311703047,0,'Override','PID_CfgAgentLogin_override')

INSERT INTO cfg_locale VALUES(1033,8,34,1311703048,3,'Use Override','PID_CfgAgentLogin_useOverride')

INSERT INTO cfg_locale VALUES(1033,8,34,1311703049,0,'Switch-specific Type','PID_CfgAgentLogin_switchSpecificType')

INSERT INTO cfg_locale VALUES(1033,8,34,1311768576,16,'Transaction','PID_CfgTransaction')

INSERT INTO cfg_locale VALUES(1033,8,34,1311768577,16,'DBID','PID_CfgTransaction_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311768578,7,'Tenant','PID_CfgTransaction_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311768579,0,'Name','PID_CfgTransaction_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311768580,35,'Type','PID_CfgTransaction_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1311768581,0,'Recording Period','PID_CfgTransaction_recordPeriod')

INSERT INTO cfg_locale VALUES(1033,8,34,1311768582,0,'Alias','PID_CfgTransaction_alias')

INSERT INTO cfg_locale VALUES(1033,8,34,1311768583,0,'Description','PID_CfgTransaction_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1311768584,4,'State','PID_CfgTransaction_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311768585,0,'Annex','PID_CfgTransaction_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834112,17,'DN Group','PID_CfgDNGroup')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834113,17,'DBID','PID_CfgDNGroup_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834114,7,'Tenant','PID_CfgDNGroup_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834115,0,'Name','PID_CfgDNGroup_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834116,3,'Supervisor','PID_CfgDNGroup_managerDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834117,2,'Origination DNs','PID_CfgDNGroup_routeDNDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834118,19,'Capacity Table','PID_CfgDNGroup_groupInfo_capacityTableDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834119,19,'Quota Table','PID_CfgDNGroup_groupInfo_quotaTableDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834120,4,'State','PID_CfgDNGroup_groupInfo_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834121,0,'Annex','PID_CfgDNGroup_groupInfo_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834122,6,'Group Type','PID_CfgDNGroup_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834123,2,'DNs','PID_CfgDNGroup_DNs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899648,18,'Stat Day','PID_CfgStatDay')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899649,18,'DBID','PID_CfgStatDay_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899650,7,'Tenant','PID_CfgStatDay_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899651,0,'Name','PID_CfgStatDay_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899652,3,'Day Of Week','PID_CfgStatDay_isDayOfWeek')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899653,0,'Day','PID_CfgStatDay_day')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899654,0,'Start Time','PID_CfgStatDay_startTime')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899655,0,'End Time','PID_CfgStatDay_endTime')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899656,0,'Min Value','PID_CfgStatDay_minValue')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899657,0,'Max Value','PID_CfgStatDay_maxValue')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899658,0,'Target Value','PID_CfgStatDay_targetValue')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899659,0,'Interval Length','PID_CfgStatDay_intervalLength')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899660,42,'Stat Intervals','PID_CfgStatDay_statIntervals')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899661,4,'State','PID_CfgStatDay_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899662,0,'Annex','PID_CfgStatDay_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899663,0,'Date','PID_CfgStatDay_date')

INSERT INTO cfg_locale VALUES(1033,8,34,1311965184,19,'Stat Table','PID_CfgStatTable')

INSERT INTO cfg_locale VALUES(1033,8,34,1311965185,19,'DBID','PID_CfgStatTable_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311965186,7,'Tenant','PID_CfgStatTable_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311965187,0,'Name','PID_CfgStatTable_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1311965188,4,'Type','PID_CfgStatTable_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1311965189,18,'Stat Days','PID_CfgStatTable_statDayDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1311965190,4,'State','PID_CfgStatTable_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1311965191,0,'Annex','PID_CfgStatTable_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312030720,20,'Application Template','PID_CfgAppPrototype')

INSERT INTO cfg_locale VALUES(1033,8,34,1312030721,20,'DBID','PID_CfgAppPrototype_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312030722,0,'Name','PID_CfgAppPrototype_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312030723,53,'Type','PID_CfgAppPrototype_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1312030724,0,'Version','PID_CfgAppPrototype_version')

INSERT INTO cfg_locale VALUES(1033,8,34,1312030725,0,'Options','PID_CfgAppPrototype_options')

INSERT INTO cfg_locale VALUES(1033,8,34,1312030726,4,'State','PID_CfgAppPrototype_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312030727,0,'Annex','PID_CfgAppPrototype_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096256,21,'Access Group','PID_CfgAccessGroup')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096257,21,'DBID','PID_CfgAccessGroup_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096258,7,'Tenant','PID_CfgAccessGroup_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096259,0,'Name','PID_CfgAccessGroup_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096260,3,'Supervisor','PID_CfgAccessGroup_managerDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096261,2,'Origination DNs','PID_CfgAccessGroup_routeAccessDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096262,19,'Capacity Table','PID_CfgAccessGroup_groupInfo_capacityTableDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096263,19,'Quota Table','PID_CfgAccessGroup_groupInfo_quotaTableDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096264,4,'State','PID_CfgAccessGroup_groupInfo_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096265,0,'Annex','PID_CfgAccessGroup_groupInfo_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096266,0,'Member IDs','PID_CfgAccessGroup_memberIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161792,22,'Folder','PID_CfgFolder')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161793,22,'DBID','PID_CfgFolder_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161794,0,'Name','PID_CfgFolder_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161795,35,'Type','PID_CfgFolder_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161796,0,'Owner ID','PID_CfgFolder_ownerID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161797,4,'State','PID_CfgFolder_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161798,0,'Annex','PID_CfgFolder_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227328,23,'Field','PID_CfgField')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227329,23,'DBID','PID_CfgField_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227330,7,'Tenant','PID_CfgField_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227331,0,'Name','PID_CfgField_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227332,6,'Data Type','PID_CfgField_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227333,0,'Description','PID_CfgField_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227334,0,'Length','PID_CfgField_length')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227335,25,'Field Type','PID_CfgField_fieldType')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227336,0,'Default Value','PID_CfgField_defaultValue')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227337,3,'Primary Key','PID_CfgField_isPrimaryKey')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227338,3,'Unique','PID_CfgField_isUnique')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227339,3,'Nullable','PID_CfgField_isNullable')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227340,4,'State','PID_CfgField_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312227341,0,'Annex','PID_CfgField_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312292864,24,'Format','PID_CfgFormat')

INSERT INTO cfg_locale VALUES(1033,8,34,1312292865,24,'DBID','PID_CfgFormat_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312292866,7,'Tenant','PID_CfgFormat_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312292867,0,'Name','PID_CfgFormat_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312292868,0,'Description','PID_CfgFormat_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312292869,23,'Fields','PID_CfgFormat_fieldDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1312292870,4,'State','PID_CfgFormat_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312292871,0,'Annex','PID_CfgFormat_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358400,25,'Table Access','PID_CfgTableAccess')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358401,25,'DBID','PID_CfgTableAccess_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358402,7,'Tenant','PID_CfgTableAccess_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358403,0,'Name','PID_CfgTableAccess_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358404,11,'Table Type','PID_CfgTableAccess_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358405,0,'Description','PID_CfgTableAccess_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358406,9,'DB Access Point','PID_CfgTableAccess_dbAccessDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358407,24,'Format','PID_CfgTableAccess_formatDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358408,0,'Database Table','PID_CfgTableAccess_dbTableName')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358409,3,'Cachable','PID_CfgTableAccess_isCachable')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358410,0,'Update Timeout','PID_CfgTableAccess_updateTimeout')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358411,4,'State','PID_CfgTableAccess_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312358412,0,'Annex','PID_CfgTableAccess_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423936,26,'Calling List','PID_CfgCallingList')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423937,26,'DBID','PID_CfgCallingList_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423938,7,'Tenant','PID_CfgCallingList_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423939,0,'Name','PID_CfgCallingList_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423940,0,'Description','PID_CfgCallingList_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423941,19,'Table Access','PID_CfgCallingList_tableAccessDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423942,29,'Filter','PID_CfgCallingList_filterDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423943,28,'Treatments','PID_CfgCallingList_treatmentDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423944,19,'Log Table Access','PID_CfgCallingList_logTableAccessDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423945,0,'Time From','PID_CfgCallingList_timeFrom')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423946,0,'Time Until','PID_CfgCallingList_timeUntil')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423947,0,'Max Attempts','PID_CfgCallingList_maxAttempts')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423948,12,'Script','PID_CfgCallingList_scriptDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423949,4,'State','PID_CfgCallingList_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312423950,0,'Annex','PID_CfgCallingList_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312489472,27,'Campaign','PID_CfgCampaign')

INSERT INTO cfg_locale VALUES(1033,8,34,1312489473,27,'DBID','PID_CfgCampaign_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312489474,7,'Tenant','PID_CfgCampaign_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312489475,0,'Name','PID_CfgCampaign_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312489476,0,'Description','PID_CfgCampaign_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312489477,54,'Calling Lists','PID_CfgCampaign_callingLists')

INSERT INTO cfg_locale VALUES(1033,8,34,1312489478,6,'Campaign Groups','PID_CfgCampaign_campaignGroups')

INSERT INTO cfg_locale VALUES(1033,8,34,1312489479,12,'Script','PID_CfgCampaign_scriptDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312489480,4,'State','PID_CfgCampaign_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312489481,0,'Annex','PID_CfgCampaign_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555008,28,'Treatment','PID_CfgTreatment')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555009,28,'DBID','PID_CfgTreatment_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555010,7,'Tenant','PID_CfgTreatment_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555011,0,'Name','PID_CfgTreatment_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555012,0,'Description','PID_CfgTreatment_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555013,51,'Call Result','PID_CfgTreatment_callResult')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555014,12,'Apply to Record','PID_CfgTreatment_recActionCode')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555015,0,'Number in Sequence','PID_CfgTreatment_attempts')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555016,0,'Date Time','PID_CfgTreatment_dateTime')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555017,0,'Cycle Attempt','PID_CfgTreatment_cycleAttempt')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555018,0,'Interval','PID_CfgTreatment_interval')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555019,0,'Increment','PID_CfgTreatment_increment')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555020,10,'Apply to Call','PID_CfgTreatment_callActionCode')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555021,2,'Dest DN','PID_CfgTreatment_destDNDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555022,4,'State','PID_CfgTreatment_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555023,0,'Annex','PID_CfgTreatment_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312620544,29,'Filter','PID_CfgFilter')

INSERT INTO cfg_locale VALUES(1033,8,34,1312620545,29,'DBID','PID_CfgFilter_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312620546,7,'Tenant','PID_CfgFilter_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312620547,0,'Name','PID_CfgFilter_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312620548,0,'Description','PID_CfgFilter_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312620549,24,'Format','PID_CfgFilter_formatDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312620550,4,'State','PID_CfgFilter_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312620551,0,'Annex','PID_CfgFilter_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686080,30,'Time Zone','PID_CfgTimeZone')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686081,30,'DBID','PID_CfgTimeZone_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686082,7,'Tenant','PID_CfgTimeZone_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686083,0,'Name','PID_CfgTimeZone_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686084,0,'Description','PID_CfgTimeZone_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686085,0,'Offset','PID_CfgTimeZone_offset')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686086,3,'DST Observed','PID_CfgTimeZone_isDSTObserved')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686087,0,'DST Start Date','PID_CfgTimeZone_DSTStartDate')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686088,0,'DST End Date','PID_CfgTimeZone_DSTStopDate')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686089,0,'Name Netscape','PID_CfgTimeZone_nameNetscape')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686090,0,'Name MSExplorer','PID_CfgTimeZone_nameMSExplorer')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686091,4,'State','PID_CfgTimeZone_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686092,0,'Annex','PID_CfgTimeZone_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312751616,31,'Voice Prompt','PID_CfgVoicePrompt')

INSERT INTO cfg_locale VALUES(1033,8,34,1312751617,31,'DBID','PID_CfgVoicePrompt_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312751618,1,'Switch','PID_CfgVoicePrompt_switchDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312751619,7,'Tenant','PID_CfgVoicePrompt_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312751620,0,'Name','PID_CfgVoicePrompt_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312751621,0,'Description','PID_CfgVoicePrompt_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312751622,12,'Script','PID_CfgVoicePrompt_scriptDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312751623,4,'State','PID_CfgVoicePrompt_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312751624,0,'Annex','PID_CfgVoicePrompt_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312817152,32,'IVR Port','PID_CfgIVRPort')

INSERT INTO cfg_locale VALUES(1033,8,34,1312817153,32,'DBID','PID_CfgIVRPort_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312817154,7,'Tenant','PID_CfgIVRPort_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312817155,0,'Port Number','PID_CfgIVRPort_portNumber')

INSERT INTO cfg_locale VALUES(1033,8,34,1312817156,16,'Description','PID_CfgIVRPort_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312817157,16,'IVR','PID_CfgIVRPort_IVRDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312817158,2,'Associated DN','PID_CfgIVRPort_DNDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312817159,4,'State','PID_CfgIVRPort_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312817160,0,'Annex','PID_CfgIVRPort_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312882688,33,'IVR','PID_CfgIVR')

INSERT INTO cfg_locale VALUES(1033,8,34,1312882689,33,'DBID','PID_CfgIVR_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312882690,7,'Tenant','PID_CfgIVR_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312882691,0,'Name','PID_CfgIVR_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312882692,0,'Description','PID_CfgIVR_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312882693,16,'Type','PID_CfgIVR_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1312882694,0,'Version','PID_CfgIVR_version')

INSERT INTO cfg_locale VALUES(1033,8,34,1312882695,9,'IVR Server','PID_CfgIVR_IVRServerDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312882696,4,'State','PID_CfgIVR_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312882697,0,'Annex','PID_CfgIVR_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948224,34,'Alarm Condition','PID_CfgAlarmCondition')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948225,34,'DBID','PID_CfgAlarmCondition_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948226,0,'Name','PID_CfgAlarmCondition_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948227,0,'Description','PID_CfgAlarmCondition_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948228,4,'Category','PID_CfgAlarmCondition_category')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948229,0,'Detect Log Event ID','PID_CfgAlarmCondition_alarmDetectEvent_logEventID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948230,0,'Detect Selection Mode','PID_CfgAlarmCondition_alarmDetectEvent_selectionMode')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948231,53,'Detect Application Type','PID_CfgAlarmCondition_alarmDetectEvent_appType')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948232,9,'Detect Application','PID_CfgAlarmCondition_alarmDetectEvent_appDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948233,0,'Cancel Log Event ID','PID_CfgAlarmCondition_alarmRemovalEvent_logEventID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948234,4,'Cancel Selection Mode','PID_CfgAlarmCondition_alarmRemovalEvent_selectionMode')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948235,53,'Cancel Application Type','PID_CfgAlarmCondition_alarmRemovalEvent_appType')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948236,9,'Cancel Application','PID_CfgAlarmCondition_alarmRemovalEvent_appDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948237,12,'Detect Script','PID_CfgAlarmCondition_alarmDetectScriptDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948238,0,'Clearance Timeout','PID_CfgAlarmCondition_clearanceTimeout')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948239,12,'Reaction Scripts','PID_CfgAlarmCondition_reactionScriptDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948240,3,'Masked','PID_CfgAlarmCondition_isMasked')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948241,4,'State','PID_CfgAlarmCondition_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948242,0,'Annex','PID_CfgAlarmCondition_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1377566720,39,'Application Rank','PID_CfgAppRank')

INSERT INTO cfg_locale VALUES(1033,8,34,1377566721,53,'Application Type','PID_CfgAppRank_appType')

INSERT INTO cfg_locale VALUES(1033,8,34,1377566722,0,'Application Rank','PID_CfgAppRank_appRank')

INSERT INTO cfg_locale VALUES(1033,8,34,1377894400,40,'Application Service Permission','PID_CfgAppServicePermission')

INSERT INTO cfg_locale VALUES(1033,8,34,1377894401,53,'Application Type','PID_CfgAppServicePermission_appType')

INSERT INTO cfg_locale VALUES(1033,8,34,1377894402,0,'Permission Mask','PID_CfgAppServicePermission_permissionMask')

INSERT INTO cfg_locale VALUES(1033,8,34,1378025472,41,'Subcode','PID_CfgSubcode')

INSERT INTO cfg_locale VALUES(1033,8,34,1378025473,0,'Name','PID_CfgSubcode_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1378025474,0,'Code','PID_CfgSubcode_code')

INSERT INTO cfg_locale VALUES(1033,8,34,1378091008,42,'Stat Interval','PID_CfgStatInterval')

INSERT INTO cfg_locale VALUES(1033,8,34,1378091009,0,'Interval Count','PID_CfgStatInterval_intervalCount')

INSERT INTO cfg_locale VALUES(1033,8,34,1378091010,0,'Stat Value 1','PID_CfgStatInterval_statValue1')

INSERT INTO cfg_locale VALUES(1033,8,34,1378091011,0,'Stat Value 2','PID_CfgStatInterval_statValue2')

INSERT INTO cfg_locale VALUES(1033,8,34,1378091012,0,'Stat Value 3','PID_CfgStatInterval_statValue3')

INSERT INTO cfg_locale VALUES(1033,8,34,1378091013,0,'Stat Value 4','PID_CfgStatInterval_statValue4')

INSERT INTO cfg_locale VALUES(1033,8,34,1379008512,43,'Shortcut','PID_ShortCut')

INSERT INTO cfg_locale VALUES(1033,8,34,1377697792,44,'Agent Login Info','PID_CfgAgentLoginInfo')

INSERT INTO cfg_locale VALUES(1033,8,34,1377697793,15,'Agent Login','PID_CfgAgentLoginInfo_agentLoginDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1377697794,0,'Wrap-up Time','PID_CfgAgentLoginInfo_wrapupTime')

INSERT INTO cfg_locale VALUES(1033,8,34,1377763328,45,'DN Info','PID_CfgDNInfo')

INSERT INTO cfg_locale VALUES(1033,8,34,1377763329,2,'DN','PID_CfgDNInfo_DNDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1377763330,0,'Trunks','PID_CfgDNInfo_trunks')

INSERT INTO cfg_locale VALUES(1033,8,34,1377828864,46,'Service Info','PID_CfgServiceInfo')

INSERT INTO cfg_locale VALUES(1033,8,34,1377828865,8,'Service','PID_CfgServiceInfo_serviceDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1377828866,3,'Chargeable','PID_CfgServiceInfo_isChargeable')

INSERT INTO cfg_locale VALUES(1033,8,34,1377632256,47,'Skill Level','PID_CfgSkillLevel')

INSERT INTO cfg_locale VALUES(1033,8,34,1377632257,13,'Skill','PID_CfgSkillLevel_skillDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1377632258,0,'Level','PID_CfgSkillLevel_level')

INSERT INTO cfg_locale VALUES(1033,8,34,1377370112,48,'Switch Access Code','PID_CfgSwitchAccessCode')

INSERT INTO cfg_locale VALUES(1033,8,34,1377370113,1,'Switch','PID_CfgSwitchAccessCode_switchDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1377370114,0,'Access Code','PID_CfgSwitchAccessCode_accessCode')

INSERT INTO cfg_locale VALUES(1033,8,34,1377370115,10,'Target Type','PID_CfgSwitchAccessCode_targetType')

INSERT INTO cfg_locale VALUES(1033,8,34,1377370116,13,'Route Type','PID_CfgSwitchAccessCode_routeType')

INSERT INTO cfg_locale VALUES(1033,8,34,1377370117,0,'DN Source','PID_CfgSwitchAccessCode_dnSource')

INSERT INTO cfg_locale VALUES(1033,8,34,1377370118,0,'Destination Source','PID_CfgSwitchAccessCode_destinationSource')

INSERT INTO cfg_locale VALUES(1033,8,34,1377370119,0,'Location Source','PID_CfgSwitchAccessCode_locationSource')

INSERT INTO cfg_locale VALUES(1033,8,34,1377370120,0,'DNIS Source','PID_CfgSwitchAccessCode_dnisSource')

INSERT INTO cfg_locale VALUES(1033,8,34,1377370121,0,'Reason Source','PID_CfgSwitchAccessCode_reasonSource')

INSERT INTO cfg_locale VALUES(1033,8,34,1377370122,0,'Extension Source','PID_CfgSwitchAccessCode_extensionSource')

INSERT INTO cfg_locale VALUES(1033,8,34,1377501184,49,'DN Access Number','PID_CfgDNAccessNumber')

INSERT INTO cfg_locale VALUES(1033,8,34,1377501185,1,'Switch','PID_CfgDNAccessNumber_switchDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1377501186,0,'Number','PID_CfgDNAccessNumber_number')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222080,50,'Campaign Group Info','PID_CfgCampaignGroupInfo')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222081,6,'Group','PID_CfgCampaignGroupInfo_groupDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222082,35,'Group Type','PID_CfgCampaignGroupInfo_groupType')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222083,0,'Description','PID_CfgCampaignGroupInfo_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222084,9,'CPD Server','PID_CfgCampaignGroupInfo_dialerDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222085,9,'Stat Server','PID_CfgCampaignGroupInfo_statServerDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222086,3,'Active','PID_CfgCampaignGroupInfo_isActive')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222087,6,'Dial Mode','PID_CfgCampaignGroupInfo_dialMode')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222088,2,'Voice Transfer Destination','PID_CfgCampaignGroupInfo_origDNDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222089,0,'Number Of Channels','PID_CfgCampaignGroupInfo_numOfChannels')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222090,3,'Operation Mode','PID_CfgCampaignGroupInfo_operationMode')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222091,0,'Minimum Record Buffer Size','PID_CfgCampaignGroupInfo_minRecBuffSize')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222092,0,'Optimal Record Buffer Size','PID_CfgCampaignGroupInfo_optRecBuffSize')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222093,4,'Optimization Method','PID_CfgCampaignGroupInfo_optMethod')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222094,0,'Optimization Method Value','PID_CfgCampaignGroupInfo_optMethodValue')

INSERT INTO cfg_locale VALUES(1033,8,34,1378222095,12,'Script','PID_CfgCampaignGroupInfo_scriptDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378353152,51,'Solution Component','PID_SolutionComponent')

INSERT INTO cfg_locale VALUES(1033,8,34,1378353153,0,'Startup Priority','PID_SolutionComponent_startupPriority')

INSERT INTO cfg_locale VALUES(1033,8,34,1378353154,3,'Optional','PID_SolutionComponent_isOptional')

INSERT INTO cfg_locale VALUES(1033,8,34,1378353155,9,'Application','PID_SolutionComponent_appDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746368,52,'Connection','PID_CfgConnInfo')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746369,9,'Server','PID_CfgConnInfo_appServerDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746370,0,'Connection Protocol','PID_CfgConnInfo_connProtocol')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746371,0,'Local Timeout','PID_CfgConnInfo_timoutLocal')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746372,0,'Remote Timeout','PID_CfgConnInfo_timoutRemote')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746373,5,'Trace Mode','PID_CfgConnInfo_mode')

INSERT INTO cfg_locale VALUES(1033,8,34,1378877440,53,'Component Definition','PID_SolutionComponentDefinition')

INSERT INTO cfg_locale VALUES(1033,8,34,1378877441,0,'Startup Priority','PID_SolutionComponentDefinition_startupPriority')

INSERT INTO cfg_locale VALUES(1033,8,34,1378877442,3,'Optional','PID_SolutionComponentDefinition_isOptional')

INSERT INTO cfg_locale VALUES(1033,8,34,1378877443,53,'Application Type','PID_SolutionComponentDefinition_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1378877444,0,'Application Version','PID_SolutionComponentDefinition_version')

INSERT INTO cfg_locale VALUES(1033,8,34,1378156544,54,'Calling List Info','PID_CfgCallingListInfo')

INSERT INTO cfg_locale VALUES(1033,8,34,1378156545,26,'Calling List','PID_CfgCallingListInfo_callingListDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378156546,0,'Share','PID_CfgCallingListInfo_share')

INSERT INTO cfg_locale VALUES(1033,8,34,1378156547,3,'Active','PID_CfgCallingListInfo_isActive')

INSERT INTO cfg_locale VALUES(1033,8,34,1311244302,0,'Startup type','PID_CfgService_startupType')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309850,0,'Startup type','PID_CfgApplication_startupType')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309851,0,'Command Line Arguments','PID_CfgApplication_commandLineArguments')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161799,0,'Object IDs','PID_CfgFolder_objectIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161800,0,'Parent ID','PID_CfgFolder_parentID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378418688,0,'Cfg ID','PID_CfgID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378418689,0,'CSID','PID_CfgID_CSID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378418690,0,'DBID','PID_CfgID_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378418691,0,'type','PID_CfgID_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375378,9,'Solution Control Server','PID_CfgHost_SCSDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313013768,0,'Display Name','PID_CfgEnumerator_displayName')

INSERT INTO cfg_locale VALUES(1033,8,34,1313079305,0,'Display Name','PID_CfgEnumeratorValue_displayName')

INSERT INTO cfg_locale VALUES(1033,8,34,1312555024,0,'Range','PID_CfgTreatment_range')

INSERT INTO cfg_locale VALUES(1033,8,34,1313013767,0,'Business Attribute Type','PID_CfgEnumerator_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916639,12,'Capacity Rule','PID_CfgPerson_agentInfo_capacityRuleDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310982151,12,'Capacity Rule','PID_CfgPlace_capacityRuleDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047691,12,'Capacity Rule','PID_CfgAgentGroup_groupInfo_capacityRuleDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113227,12,'Capacity Rule','PID_CfgPlaceGroup_groupInfo_capacityRuleDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178770,12,'Default Capacity Rule','PID_CfgTenant_defaultCapacityRuleDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311703050,0,'Password','PID_CfgAgentLogin_password')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834124,12,'Capacity Rule','PID_CfgDNGroup_groupInfo_capacityRuleDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096268,12,'Capacity Rule','PID_CfgAccessGroup_groupInfo_capacityRuleDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096267,0,'Type','PID_CfgAccessGroup_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1312948243,0,'Clearance Scripts','PID_CfgAlarmCondition_clearanceScriptDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1313013760,35,'Business Attribute','PID_CfgEnumerator')

INSERT INTO cfg_locale VALUES(1033,8,34,1313013761,35,'DBID','PID_CfgEnumerator_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313013762,7,'Tenant','PID_CfgEnumerator_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313013763,0,'Name','PID_CfgEnumerator_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1313013764,0,'Description','PID_CfgEnumerator_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1313013765,4,'State','PID_CfgEnumerator_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1313013766,0,'Annex','PID_CfgEnumerator_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1313079296,36,'Business Attribute Value','PID_CfgEnumeratorValue')

INSERT INTO cfg_locale VALUES(1033,8,34,1313079297,36,'DBID','PID_CfgEnumeratorValue_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313079298,35,'Business Attribute','PID_CfgEnumeratorValue_enumeratorDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313079299,7,'Tenant','PID_CfgEnumeratorValue_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313079300,0,'Name','PID_CfgEnumeratorValue_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1313079301,0,'Description','PID_CfgEnumeratorValue_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1313079302,3,'Default','PID_CfgEnumeratorValue_isDefault')

INSERT INTO cfg_locale VALUES(1033,8,34,1313079303,4,'State','PID_CfgEnumeratorValue_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1313079304,0,'Annex','PID_CfgEnumeratorValue_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144832,37,'ObjectiveTable','PID_CfgObjectiveTable')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144833,37,'DBID','PID_CfgObjectiveTable_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144834,7,'Tenant','PID_CfgObjectiveTable_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144835,0,'Name','PID_CfgObjectiveTable_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144836,0,'Description','PID_CfgObjectiveTable_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144837,4,'Objective Records','PID_CfgObjectiveTable_objectiveRecords')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144838,4,'State','PID_CfgObjectiveTable_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144839,0,'Annex','PID_CfgObjectiveTable_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1378942976,0,'Objective Table Record','PID_CfgObjectiveTableRecord')

INSERT INTO cfg_locale VALUES(1033,8,34,1378942977,0,'Media Type','PID_CfgObjectiveTableRecord_mediaTypeDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378942978,0,'Service Type','PID_CfgObjectiveTableRecord_serviceTypeDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378942979,0,'Customer Segment','PID_CfgObjectiveTableRecord_customerSegmentDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1378942980,0,'Objective Threshold','PID_CfgObjectiveTableRecord_objectiveThreshold')

INSERT INTO cfg_locale VALUES(1033,8,34,1378942981,0,'Objective Delta','PID_CfgObjectiveTableRecord_objectiveDelta')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916640,0,'E-mail Address','PID_CfgPerson_emailAddress')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916641,0,'External ID','PID_CfgPerson_externalID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916644,0,'Change Password On Next Login','PID_CfgPerson_changePasswordOnNextLogin')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851093,22,'Site','PID_CfgDN_siteDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310851094,37,'Contract','PID_CfgDN_contractDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916642,22,'Site','PID_CfgPerson_agentInfo_siteDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310916643,37,'Contract','PID_CfgPerson_agentInfo_contractDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310982152,22,'Site','PID_CfgPlace_siteDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1310982153,37,'Contract','PID_CfgPlace_contractDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047692,22,'Site','PID_CfgAgentGroup_groupInfo_siteDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311047693,37,'Contract','PID_CfgAgentGroup_groupInfo_contractDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113228,22,'Site','PID_CfgPlaceGroup_groupInfo_siteDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311113229,37,'Contract','PID_CfgPlaceGroup_groupInfo_contractDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178771,37,'Default Contract','PID_CfgTenant_defaultContractDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311178772,0,'Parent Tenant','PID_CfgTenant_parentTenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309852,0,'Listening Ports','PID_CfgApplication_portInfos')

INSERT INTO cfg_locale VALUES(1033,8,34,1311309853,0,'Resources','PID_CfgApplication_resources')

INSERT INTO cfg_locale VALUES(1033,8,34,1311375379,0,'Resources','PID_CfgHost_resources')

INSERT INTO cfg_locale VALUES(1033,8,34,1311506441,0,'Resources','PID_CfgScript_resources')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834125,22,'Site','PID_CfgDNGroup_groupInfo_siteDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311834126,37,'Contract','PID_CfgDNGroup_groupInfo_contractDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096269,22,'Site','PID_CfgAccessGroup_groupInfo_siteDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1312096270,37,'Contract','PID_CfgAccessGroup_groupInfo_contractDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899664,0,'Type','PID_CfgStatDay_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899665,0,'Use Flat Rate','PID_CfgStatDay_useFlatRate')

INSERT INTO cfg_locale VALUES(1033,8,34,1311899666,0,'Flat Rate','PID_CfgStatDay_flatRate')

INSERT INTO cfg_locale VALUES(1033,8,34,1311965192,0,'Wait Threshold','PID_CfgStatTable_waitThreshold')

INSERT INTO cfg_locale VALUES(1033,8,34,1311965193,0,'Flat Rate','PID_CfgStatTable_flatRate')

INSERT INTO cfg_locale VALUES(1033,8,34,1311965194,0,'Agent Hourly Rate','PID_CfgStatTable_agentHourlyRate')

INSERT INTO cfg_locale VALUES(1033,8,34,1311965195,0,'Use Flat Rate','PID_CfgStatTable_useFlatRate')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161801,0,'Description','PID_CfgFolder_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161802,0,'Folder Class','PID_CfgFolder_folderClass')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161803,0,'Custom Type','PID_CfgFolder_customType')

INSERT INTO cfg_locale VALUES(1033,8,34,1312161804,0,'Resources','PID_CfgFolder_resources')

INSERT INTO cfg_locale VALUES(1033,8,34,1312686093,0,'DST Offset','PID_CfgTimeZone_DSTOffset')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144840,0,'Total Prepaid Cost','PID_CfgObjectiveTable_prepaidCost')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144841,0,'Time Zone','PID_CfgObjectiveTable_timeZoneDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144842,0,'Contract Start Time','PID_CfgObjectiveTable_timeStart')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144843,0,'Contract End Time','PID_CfgObjectiveTable_timeEnd')

INSERT INTO cfg_locale VALUES(1033,8,34,1313144844,0,'Type','PID_CfgObjectiveTable_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210368,0,'Campaign Group','PID_CfgCampaignGroup')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210369,0,'DBID','PID_CfgCampaignGroup_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210370,0,'Campaign','PID_CfgCampaignGroup_campaignDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210371,0,'Tenant','PID_CfgCampaignGroup_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210372,0,'Name','PID_CfgCampaignGroup_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210373,6,'Group','PID_CfgCampaignGroup_groupDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210374,35,'Group Type','PID_CfgCampaignGroup_groupType')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210375,0,'Description','PID_CfgCampaignGroup_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210376,0,'Servers','PID_CfgCampaignGroup_serverDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210377,0,'IVR Profile','PID_CfgCampaignGroup_IVRProfileDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210378,6,'Dial Mode','PID_CfgCampaignGroup_dialMode')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210379,2,'Voice Transfer Destination','PID_CfgCampaignGroup_origDNDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210380,0,'Number Of Channels','PID_CfgCampaignGroup_numOfChannels')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210381,3,'Operation Mode','PID_CfgCampaignGroup_operationMode')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210382,0,'Minimum Record Buffer Size','PID_CfgCampaignGroup_minRecBuffSize')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210383,0,'Optimal Record Buffer Size','PID_CfgCampaignGroup_optRecBuffSize')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210384,0,'Maximum Queue Size','PID_CfgCampaignGroup_maxQueueSize')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210385,4,'Optimization Method','PID_CfgCampaignGroup_optMethod')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210386,0,'Optimization Method Value','PID_CfgCampaignGroup_optMethodValue')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210387,12,'Interaction Queue','PID_CfgCampaignGroup_interactionQueueDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210388,12,'Script','PID_CfgCampaignGroup_scriptDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210389,4,'State','PID_CfgCampaignGroup_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1313210390,0,'Annex','PID_CfgCampaignGroup_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1313275904,0,'GVP Reseller','PID_CfgGVPReseller')

INSERT INTO cfg_locale VALUES(1033,8,34,1313275905,0,'DBID','PID_CfgGVPReseller_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313275906,0,'Tenant','PID_CfgGVPReseller_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313275907,0,'Name','PID_CfgGVPReseller_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1313275908,0,'Display Name','PID_CfgGVPReseller_displayName')

INSERT INTO cfg_locale VALUES(1033,8,34,1313275909,0,'Start Date','PID_CfgGVPReseller_startDate')

INSERT INTO cfg_locale VALUES(1033,8,34,1313275910,0,'Parent NSP','PID_CfgGVPReseller_isParentNSP')

INSERT INTO cfg_locale VALUES(1033,8,34,1313275911,0,'Time Zone','PID_CfgGVPReseller_timeZoneDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313275912,0,'Notes','PID_CfgGVPReseller_notes')

INSERT INTO cfg_locale VALUES(1033,8,34,1313275913,4,'State','PID_CfgGVPReseller_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1313275914,0,'Annex','PID_CfgGVPReseller_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341440,0,'GVP Customer','PID_CfgGVPCustomer')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341441,0,'DBID','PID_CfgGVPCustomer_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341442,0,'Reseller','PID_CfgGVPCustomer_resellerDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341443,0,'Tenant','PID_CfgGVPCustomer_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341444,0,'Name','PID_CfgGVPCustomer_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341445,0,'Display Name','PID_CfgGVPCustomer_displayName')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341446,0,'Channel','PID_CfgGVPCustomer_channel')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341447,0,'Notes','PID_CfgGVPCustomer_notes')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341448,0,'Provisioned','PID_CfgGVPCustomer_isProvisioned')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341449,0,'Admin Customer','PID_CfgGVPCustomer_isAdminCustomer')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341450,0,'Time Zone','PID_CfgGVPCustomer_timeZoneDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341451,4,'State','PID_CfgGVPCustomer_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1313341452,0,'Annex','PID_CfgGVPCustomer_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406976,0,'Voice Application Profile','PID_CfgGVPIVRProfile')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406977,0,'DBID','PID_CfgGVPIVRProfile_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406978,0,'Customer','PID_CfgGVPIVRProfile_customerDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406979,0,'Reseller','PID_CfgGVPIVRProfile_resellerDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406980,0,'Tenant','PID_CfgGVPIVRProfile_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406981,0,'Name','PID_CfgGVPIVRProfile_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406982,0,'Display Name','PID_CfgGVPIVRProfile_displayName')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406983,0,'Type','PID_CfgGVPIVRProfile_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406984,0,'Notes','PID_CfgGVPIVRProfile_notes')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406985,0,'Description','PID_CfgGVPIVRProfile_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406986,0,'Start Service Date','PID_CfgGVPIVRProfile_startServiceDate')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406987,0,'End Service Date','PID_CfgGVPIVRProfile_endServiceDate')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406988,0,'Provisioned','PID_CfgGVPIVRProfile_isProvisioned')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406989,0,'TFN','PID_CfgGVPIVRProfile_tfn')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406990,0,'Status','PID_CfgGVPIVRProfile_status')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406991,0,'DIDs','PID_CfgGVPIVRProfile_DIDDBIDs')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406992,4,'State','PID_CfgGVPIVRProfile_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1313406993,0,'Annex','PID_CfgGVPIVRProfile_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1313472512,0,'Scheduled Task','PID_CfgScheduledTask')

INSERT INTO cfg_locale VALUES(1033,8,34,1313472513,0,'DBID','PID_CfgScheduledTask_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313472514,0,'Name','PID_CfgScheduledTask_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1313472515,0,'Type','PID_CfgScheduledTask_type')

INSERT INTO cfg_locale VALUES(1033,8,34,1313472516,0,'Description','PID_CfgScheduledTask_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1313472517,0,'Start Time','PID_CfgScheduledTask_startTime')

INSERT INTO cfg_locale VALUES(1033,8,34,1313472518,0,'Resources','PID_CfgScheduledTask_resources')

INSERT INTO cfg_locale VALUES(1033,8,34,1313472519,4,'State','PID_CfgScheduledTask_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1313472520,0,'Annex','PID_CfgScheduledTask_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1313538048,0,'Role','PID_CfgRole')

INSERT INTO cfg_locale VALUES(1033,8,34,1313538049,0,'DBID','PID_CfgRole_DBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313538050,0,'Tenant','PID_CfgRole_tenantDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1313538051,0,'Name','PID_CfgRole_name')

INSERT INTO cfg_locale VALUES(1033,8,34,1313538052,0,'Description','PID_CfgRole_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1313538053,4,'State','PID_CfgRole_state')

INSERT INTO cfg_locale VALUES(1033,8,34,1313538054,0,'Annex','PID_CfgRole_userProperties')

INSERT INTO cfg_locale VALUES(1033,8,34,1313538055,0,'Members','PID_CfgRole_members')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746374,0,'ID','PID_CfgConnInfo_id')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746375,0,'Transport Parameters','PID_CfgConnInfo_transportParams')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746376,0,'Application Parameters','PID_CfgConnInfo_appParams')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746377,0,'Proxy Server Parameters','PID_CfgConnInfo_proxyParams')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746378,0,'Description','PID_CfgConnInfo_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746379,0,'Reserved text field #1','PID_CfgConnInfo_charField1')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746380,0,'Reserved text field #2','PID_CfgConnInfo_charField2')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746381,0,'Reserved text field #3','PID_CfgConnInfo_charField3')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746382,0,'Reserved text field #4','PID_CfgConnInfo_charField4')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746383,0,'Reserved numeric field #1','PID_CfgConnInfo_longField1')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746384,0,'Reserved numeric field #2','PID_CfgConnInfo_longField2')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746385,0,'Reserved numeric field #3','PID_CfgConnInfo_longField3')

INSERT INTO cfg_locale VALUES(1033,8,34,1378746386,0,'Reserved numeric field #4','PID_CfgConnInfo_longField4')

INSERT INTO cfg_locale VALUES(1033,8,34,1378942982,0,'Contract','PID_CfgObjectiveTableRecord_contractDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139584,0,'Object Resource','PID_CfgObjectResource')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139585,0,'Resource type','PID_CfgObjectResource_resourceType')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139586,0,'Object','PID_CfgObjectResource_objectDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139587,0,'Object Type','PID_CfgObjectResource_objectType')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139588,0,'Description','PID_CfgObjectResource_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139589,0,'Reserved text field #1','PID_CfgObjectResource_charField1')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139590,0,'Reserved text field #2','PID_CfgObjectResource_charField2')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139591,0,'Reserved text field #3','PID_CfgObjectResource_charField3')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139592,0,'Reserved text field #4','PID_CfgObjectResource_charField4')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139593,0,'Reserved numeric field #1','PID_CfgObjectResource_longField1')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139594,0,'Reserved numeric field #2','PID_CfgObjectResource_longField2')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139595,0,'Reserved numeric field #3','PID_CfgObjectResource_longField3')

INSERT INTO cfg_locale VALUES(1033,8,34,1379139596,0,'Reserved numeric field #4','PID_CfgObjectResource_longField4')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205120,0,'Listening port','PID_CfgPortInfo')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205121,0,'ID','PID_CfgPortInfo_id')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205122,0,'Port','PID_CfgPortInfo_port')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205123,0,'Transport Parameters','PID_CfgPortInfo_transportParams')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205124,0,'Connection Protocol','PID_CfgPortInfo_connProtocol')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205125,0,'Application Parameters','PID_CfgPortInfo_appParams')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205126,0,'Description','PID_CfgPortInfo_description')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205127,0,'Reserved text field #1','PID_CfgPortInfo_charField1')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205128,0,'Reserved text field #2','PID_CfgPortInfo_charField2')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205129,0,'Reserved text field #3','PID_CfgPortInfo_charField3')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205130,0,'Reserved text field #4','PID_CfgPortInfo_charField4')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205131,0,'Reserved numeric field #1','PID_CfgPortInfo_longField1')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205132,0,'Reserved numeric field #2','PID_CfgPortInfo_longField2')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205133,0,'Reserved numeric field #3','PID_CfgPortInfo_longField3')

INSERT INTO cfg_locale VALUES(1033,8,34,1379205134,0,'Reserved numeric field #4','PID_CfgPortInfo_longField4')

INSERT INTO cfg_locale VALUES(1033,8,34,1379270656,0,'Role Member','PID_CfgRoleMember')

INSERT INTO cfg_locale VALUES(1033,8,34,1379270657,0,'Object','PID_CfgRoleMember_objectDBID')

INSERT INTO cfg_locale VALUES(1033,8,34,1379270658,0,'Object Type','PID_CfgRoleMember_objectType')

INSERT INTO cfg_locale VALUES(1033,8,35,0,0,'Unknown Stat Table Type','CFGNoStatTable')

INSERT INTO cfg_locale VALUES(1033,8,35,1,0,'Capacity Table','CFGCapacityTable')

INSERT INTO cfg_locale VALUES(1033,8,35,2,0,'Quota Table','CFGQuotaTable')

INSERT INTO cfg_locale VALUES(1033,8,35,3,0,'Special Day Table','CFGSpecialDayTable')

INSERT INTO cfg_locale VALUES(1033,8,35,4,0,'Volume Contract Table','CFGVolumeContractTable')

INSERT INTO cfg_locale VALUES(1033,8,35,5,0,'Variable Rate Contract Table','CFGVariableRateContractTable')

INSERT INTO cfg_locale VALUES(1033,8,36,0,0,'Success','CFGNoError')

INSERT INTO cfg_locale VALUES(1033,8,36,1,0,'SCEE018 - The specified Configuration Server cannot be found. Check the Host Name and Port and try again.','CFGServerNotFound')

INSERT INTO cfg_locale VALUES(1033,8,36,2,0,'SCEE001 - Your application cannot connect to Configuration Server because it is using a wrong communication protocol. Check the Release Notes for version compatibility information.','CFGWrongProtocol')

INSERT INTO cfg_locale VALUES(1033,8,36,3,0,'SCEE002 - The application message cannot be identified as a valid message by the Configuration Server. Check the Release Notes for version compatibility information.','CFGUnknownMessage')

INSERT INTO cfg_locale VALUES(1033,8,36,4,0,'SCEE003 - Invalid login information specified. Check your User Name and Password and try again.','CFGLoginIncorrect')

INSERT INTO cfg_locale VALUES(1033,8,36,5,0,'SCEE005 - The link to the Configuration Database is not available. Contact your network administrator.','CFGNoDBAccess')

INSERT INTO cfg_locale VALUES(1033,8,36,6,0,'SCEE006 - A database error has occurred. Try the same action again. If the problem persists, contact your network administrator.','CFGDBError')

INSERT INTO cfg_locale VALUES(1033,8,36,7,0,'SCEE004 - Your application is not recognized by Configuration Server. Check the Application name and try again.','CFGAppSecurityViolation')

INSERT INTO cfg_locale VALUES(1033,8,36,8,0,'SCEE007 - Access denied. Please contact Genesys Technical Support.','CFGAccessDenied')

INSERT INTO cfg_locale VALUES(1033,8,36,9,0,'SCEE008 - Permission error. Your access privileges are insufficient for performing the requested action.','CFGNoPermission')

INSERT INTO cfg_locale VALUES(1033,8,36,10,0,'SCEE009 - Object does not exist. Another client may have modified or deleted the specified object.','CFbjectNotFound')

INSERT INTO cfg_locale VALUES(1033,8,36,11,0,'SCEE010 - Object association does not exist. Another client may have modified or deleted the specified object association.','CFGListItemNotFound')

INSERT INTO cfg_locale VALUES(1033,8,36,12,0,'SCEE011 - Duplicate information has been entered.','CFGUniquenessViolation')

INSERT INTO cfg_locale VALUES(1033,8,36,13,0,'SCEE012 - An additional action is required to complete the requested task.','CFGDependentObjects')

INSERT INTO cfg_locale VALUES(1033,8,36,14,0,'SCEE013 - The data is incomplete, or the specified data is not within an allowable range.','CFGIncompleteObjectData')

INSERT INTO cfg_locale VALUES(1033,8,36,15,0,'SCEE014 - Your action has caused a conflict with existing data. Check the validation rules for the object parameter specified in this error message.','CFGIncorrectReferences')

INSERT INTO cfg_locale VALUES(1033,8,36,16,0,'SCEE015 - Invalid update attempt. The specified data item may not be changed or deleted.','CFGUnchangeableInfo')

INSERT INTO cfg_locale VALUES(1033,8,36,17,0,'SCEE016 - Invalid or missing value. The specified information is not within the allowable range.','CFGValueOutOfRange')

INSERT INTO cfg_locale VALUES(1033,8,36,18,0,'SCEE017 - Unspecified modification. Another user may have just performed the identical action.','CFGUnspecifiedModification')

INSERT INTO cfg_locale VALUES(1033,8,36,19,0,'SCEE019 - The database query timeout expired. Try the action again. If the problem persists, contact your network administrator.','CFGDBResponseTimedOut')

INSERT INTO cfg_locale VALUES(1033,8,36,20,0,'SCEE020 - Compatibility error. Please contact Genesys Technical Support.','CFGWrongAPIParameters')

INSERT INTO cfg_locale VALUES(1033,8,36,21,0,'SCEE021 - A communication error has occurred during an attempt to send a response or notification from Configuration Server. Check the network connection and restart the application. If the problem persists, contact the network administrator.','CFGConnWriteError')

INSERT INTO cfg_locale VALUES(1033,8,36,22,0,'SCEE022 - A communication error has occurred during the receipt of a response or notification from Configuration Server. Check the network connection and restart the application. If the problem persists, contact your network administrator.','CFGConnReadError')

INSERT INTO cfg_locale VALUES(1033,8,36,23,0,'SCEE023 - Compatibility error. Please contact Genesys Technical Support.','CFGConfigFileNotRead')

INSERT INTO cfg_locale VALUES(1033,8,36,24,0,'SCEE024 - Compatibility error. Please contact Genesys Technical Support.','CFGConfigFileIncorrect')

INSERT INTO cfg_locale VALUES(1033,8,36,25,0,'SCEE025 - The object cannot be packed for transmission because of object size limitations. Check the Release Notes for version compatibility information.','CFGObjectPackingError')

INSERT INTO cfg_locale VALUES(1033,8,36,26,0,'SCEE026 - Compatibility error. Please contact Genesys Technical Support.','CFGUndefinedError')

INSERT INTO cfg_locale VALUES(1033,8,36,27,0,'SCEE027 - Compatibility error. Please contact Genesys Technical Support.','CFGHistoryLogExpired')

INSERT INTO cfg_locale VALUES(1033,8,36,28,0,'SCEE028 - The network management system has terminated your communication session. Contact your network administrator.','CFGForcedDisconnect')

INSERT INTO cfg_locale VALUES(1033,8,36,29,0,'SCEE029 - Action rejected. Configuration Server is currently working in Read-only mode.','CFGReadOnlyOperationalModeActivated')

INSERT INTO cfg_locale VALUES(1033,8,36,30,0,'SCEE030 - Operation failed. The client that activated the Read-only mode is still connected to Configuration Server.','CFGSetOperationalModeFailed')

INSERT INTO cfg_locale VALUES(1033,8,36,31,0,'SCEE031 - Unsupported object property requested. Please contact Genesys Technical Support.','CFGUnsupportedProperty')

INSERT INTO cfg_locale VALUES(1033,8,36,32,0,'SCEE032 - Unsupported object requested. Please contact Genesys Technical Support.','CFGUnsupportedObject')

INSERT INTO cfg_locale VALUES(1033,8,36,33,0,'SCEE033 - Authentication request is denied.','CFGExternalAuthenticationError')

INSERT INTO cfg_locale VALUES(1033,8,36,34,0,'SCEE034 - Locale element cannot be changed. Please contact Genesys Technical Support.','CFGLocaleItemNotChanged')

INSERT INTO cfg_locale VALUES(1033,8,36,35,0,'SCEE035 - Locale element cannot be located. Please contact Genesys Technical Support.','CFGLocaleItemNotFound')

INSERT INTO cfg_locale VALUES(1033,8,36,36,0,'SCEE036 - Updated data has invalid format. Please contact Genesys Technical Support.','CFGXMLParseError')

INSERT INTO cfg_locale VALUES(1033,8,36,37,0,'SCEE037 - Password cannot be changed. External authentication is enforced.','CFGChangePasswordDenied')

INSERT INTO cfg_locale VALUES(1033,8,36,38,0,'SCEE038 - Configuration Server does not accept unsecured connections.','CFGUnsecureConnectionDenied')

INSERT INTO cfg_locale VALUES(1033,8,36,39,0,'SCEE039 - Password cannot be empty.','CFGEmptyPasswordDenied')

INSERT INTO cfg_locale VALUES(1033,8,36,40,0,'SCEE040 - User must change password at logon.','CFGUserMustChangePassword')

INSERT INTO cfg_locale VALUES(1033,8,39,0,0,'Operational NoMode','CFGOperationalNoMode')

INSERT INTO cfg_locale VALUES(1033,8,39,1,0,'Full Mode','CFGOperationalFullMode')

INSERT INTO cfg_locale VALUES(1033,8,39,2,0,'Read-Only','CFGOperationalReadOnlyMode')

INSERT INTO cfg_locale VALUES(1033,8,39,3,0,'Emergency Mode','CFGOperationalEmergencyMode')

INSERT INTO cfg_locale VALUES(1033,8,40,0,0,'Unknown Group Type','CFGNoGroup')

INSERT INTO cfg_locale VALUES(1033,8,40,1,0,'Agent Group','CFGAgentGroupType')

INSERT INTO cfg_locale VALUES(1033,8,40,2,0,'Place Group','CFGPlaceGroupType')

INSERT INTO cfg_locale VALUES(1033,8,40,3,0,'DN Group','CFGDNGroupType')

INSERT INTO cfg_locale VALUES(1033,8,40,4,0,'Access Group','CFGAccessGroupType')

INSERT INTO cfg_locale VALUES(1033,8,42,0,0,'Unknown Person Type','CFGPTNoPersonType')

INSERT INTO cfg_locale VALUES(1033,8,42,1,0,'Person','CFGPTPerson')

INSERT INTO cfg_locale VALUES(1033,8,42,2,0,'Agent','CFGPTAgent')

INSERT INTO cfg_locale VALUES(1033,8,43,0,0,'No Record Type','Enum_GctiRecordType')

INSERT INTO cfg_locale VALUES(1033,8,43,1,0,'Unknown Record Type','Enum_GctiRecordType')

INSERT INTO cfg_locale VALUES(1033,8,43,2,0,'General','Enum_GctiRecordType')

INSERT INTO cfg_locale VALUES(1033,8,43,3,0,'Campaign Rescheduled','Enum_GctiRecordType')

INSERT INTO cfg_locale VALUES(1033,8,43,4,0,'Personal Rescheduled','Enum_GctiRecordType')

INSERT INTO cfg_locale VALUES(1033,8,43,5,0,'Personal CallBack','Enum_GctiRecordType')

INSERT INTO cfg_locale VALUES(1033,8,43,6,0,'Campaign CallBack','Enum_GctiRecordType')

INSERT INTO cfg_locale VALUES(1033,8,43,7,0,'No Call','Enum_GctiRecordType')

INSERT INTO cfg_locale VALUES(1033,8,44,0,0,'No Record Status','Enum_GctiRecordStatus')

INSERT INTO cfg_locale VALUES(1033,8,44,1,0,'Ready','Enum_GctiRecordStatus')

INSERT INTO cfg_locale VALUES(1033,8,44,2,0,'Retrieved','Enum_GctiRecordStatus')

INSERT INTO cfg_locale VALUES(1033,8,44,3,0,'Updated','Enum_GctiRecordStatus')

INSERT INTO cfg_locale VALUES(1033,8,44,4,0,'Stale','Enum_GctiRecordStatus')

INSERT INTO cfg_locale VALUES(1033,8,44,5,0,'Cancelled','Enum_GctiRecordStatus')

INSERT INTO cfg_locale VALUES(1033,8,44,6,0,'Agent Error','Enum_GctiRecordStatus')

INSERT INTO cfg_locale VALUES(1033,8,44,7,0,'Chain Updated','Enum_GctiRecordStatus')

INSERT INTO cfg_locale VALUES(1033,8,44,8,0,'Missed CallBack','Enum_GctiRecordStatus')

INSERT INTO cfg_locale VALUES(1033,8,44,9,0,'Chain Ready','Enum_GctiRecordStatus')

INSERT INTO cfg_locale VALUES(1033,8,44,10,0,'Delegated','Enum_GctiRecordStatus')

INSERT INTO cfg_locale VALUES(1033,8,45,0,0,'No Contact Type','Enum_GctiContactType')

INSERT INTO cfg_locale VALUES(1033,8,45,1,0,'Home Phone','Enum_GctiContactType')

INSERT INTO cfg_locale VALUES(1033,8,45,2,0,'Direct Business Phone','Enum_GctiContactType')

INSERT INTO cfg_locale VALUES(1033,8,45,3,0,'Business With Extension','Enum_GctiContactType')

INSERT INTO cfg_locale VALUES(1033,8,45,4,0,'Mobile','Enum_GctiContactType')

INSERT INTO cfg_locale VALUES(1033,8,45,5,0,'Vacation Phone','Enum_GctiContactType')

INSERT INTO cfg_locale VALUES(1033,8,45,6,0,'Pager','Enum_GctiContactType')

INSERT INTO cfg_locale VALUES(1033,8,45,7,0,'Modem','Enum_GctiContactType')

INSERT INTO cfg_locale VALUES(1033,8,45,8,0,'Voice Mail','Enum_GctiContactType')

INSERT INTO cfg_locale VALUES(1033,8,45,9,0,'Pin Pager','Enum_GctiContactType')

INSERT INTO cfg_locale VALUES(1033,8,45,10,0,'E-Mail Address','Enum_GctiContactType')

INSERT INTO cfg_locale VALUES(1033,8,45,11,0,'Instant Messaging','Enum_GctiContactType')

INSERT INTO cfg_locale VALUES(1033,8,46,0,0,'Deactivated','Enum_CM_GrpCampState')

INSERT INTO cfg_locale VALUES(1033,8,46,1,0,'Deactivating','Enum_CM_GrpCampState')

INSERT INTO cfg_locale VALUES(1033,8,46,2,0,'Deactivating','Enum_CM_GrpCampState')

INSERT INTO cfg_locale VALUES(1033,8,46,3,0,'','Enum_CM_GrpCampState')

INSERT INTO cfg_locale VALUES(1033,8,46,4,0,'Activated','Enum_CM_GrpCampState')

INSERT INTO cfg_locale VALUES(1033,8,46,5,0,'Running','Enum_CM_GrpCampState')

INSERT INTO cfg_locale VALUES(1033,8,47,0,0,'Unknown Language','Enum_CfgLanguage')

INSERT INTO cfg_locale VALUES(1033,8,47,1,0,'English','Enum_CfgLanguage')

INSERT INTO cfg_locale VALUES(1033,8,47,2,0,'French','Enum_CfgLanguage')

INSERT INTO cfg_locale VALUES(1033,8,47,3,0,'German','Enum_CfgLanguage')

INSERT INTO cfg_locale VALUES(1033,8,47,4,0,'Italian','Enum_CfgLanguage')

INSERT INTO cfg_locale VALUES(1033,8,47,5,0,'Spanish','Enum_CfgLanguage')

INSERT INTO cfg_locale VALUES(1033,8,47,6,0,'Brasilian Portuguese','Enum_CfgLanguage')

INSERT INTO cfg_locale VALUES(1033,8,47,7,0,'Japanese','Enum_CfgLanguage')

INSERT INTO cfg_locale VALUES(1033,8,47,8,0,'Korean','Enum_CfgLanguage')

INSERT INTO cfg_locale VALUES(1033,8,47,9,0,'Traditional Chinese','Enum_CfgLanguage')

INSERT INTO cfg_locale VALUES(1033,8,47,10,0,'Simplified Chinese','Enum_CfgLanguage')

INSERT INTO cfg_locale VALUES(1033,8,48,0,0,'No Filter','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,1,0,'Account','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,2,0,'Account Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,3,0,'Code Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,4,0,'Application Template','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,5,0,'Application','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,6,0,'Application Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,7,0,'Association','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,8,0,'Backup Server','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,9,0,'Brief','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,10,0,'Call Action Code','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,11,0,'Calling List','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,12,0,'CallResult Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,13,0,'Database Access Point','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,14,0,'DBID','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,15,0,'Database Table Name','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,16,0,'Default Folder','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,17,0,'Destination DN','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,18,0,'DN','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,19,0,'DN Group Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,20,0,'DN Number','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,21,0,'DN Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,22,0,'EmployeeID','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,23,0,'Field','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,24,0,'Field Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,25,0,'Filter','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,26,0,'Folder','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,27,0,'Format','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,28,0,'Group','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,29,0,'Host','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,30,0,'Host Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,31,0,'Is Agent','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,32,0,'Is Server','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,33,0,'IVR','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,34,0,'IVR Server','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,35,0,'Login','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,36,0,'Log Table Access','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,37,0,'Name','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,38,0,'MSExplorer Name','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,39,0,'Netscape Name','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,40,0,'No DBID','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,41,0,'No Login','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,42,0,'No Person','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,43,0,'No Place','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,44,0,'Object Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,45,0,'Offset','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,46,0,'OS Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,47,0,'Owner','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,48,0,'Owner Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,49,0,'Person','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,50,0,'Place','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,51,0,'Port','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,52,0,'IVR Port','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,53,0,'Primary Server','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,54,0,'RecActionCode','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,55,0,'Same Host And Port','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,56,0,'Solution Control Server','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,57,0,'Script','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,58,0,'Script Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,59,0,'Server','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,60,0,'Skill','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,61,0,'State','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,62,0,'Switch','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,63,0,'Table Access','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,64,0,'Table','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,65,0,'Table Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,66,0,'Tenant','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,67,0,'Treatment','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,68,0,'T-Server','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,69,0,'Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,70,0,'User Name','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,71,0,'TableAccess Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,72,0,'Login Code','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,73,0,'DN Alias','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,74,0,'Data','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,75,0,'All Tenants','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,76,0,'Application Version','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,77,0,'No Switch','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,78,0,'Object','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,79,0,'Is Primary','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,80,0,'MaxValue','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,81,0,'IVR Port Number','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,82,0,'Allowed DNs','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,83,0,'No client','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,84,0,'First name','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,85,0,'Last name','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,86,0,'Tenant for Capacity Rule','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,87,0,'Agent for Capacity Rule','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,88,0,'Place for Capacity Rule','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,89,0,'Agent Group for Capacity Rule','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,90,0,'Place Group for Capacity Rule','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,91,0,'Delegate account','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,92,0,'Delegate account type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,93,0,'Business Attribute type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,94,0,'Business Attribute','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,95,0,'Default value','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,96,0,'Exclude bytecode?','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,97,0,'Register all flag','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,98,0,'Object path needed','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,99,0,'Display name','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,100,0,'Statistical Day','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,101,0,'Compare Insensitive flag','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,102,0,'Read folder flag','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,103,0,'Campaign','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,104,0,'Reseller','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,105,0,'Customer','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,106,0,'Folder Class','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,107,0,'Objective Table Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,108,0,'Stat Day Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,48,109,0,'Task Type','Enum_CfgFilterType')

INSERT INTO cfg_locale VALUES(1033,8,49,0,0,'Unknown Object','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,1,1,'Switches','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,2,0,'DNs','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,3,1,'Persons','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,4,1,'Places','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,5,1,'Agent Groups','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,6,1,'Place Groups','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,7,0,'Tenants','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,8,1,'Solutions','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,9,1,'Applications','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,10,1,'Hosts','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,11,1,'Switching Offices','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,12,1,'Scripts','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,13,1,'Skills','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,14,1,'Action Codes','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,15,1,'Agent Logins','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,16,1,'Transactions','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,17,1,'DN Groups','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,18,1,'Statistical Days','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,19,1,'Statistical Tables','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,20,1,'Application Templates','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,21,1,'Access Groups','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,22,0,'Configuration Units','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,23,1,'Fields','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,24,1,'Formats','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,25,1,'Table Access','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,26,1,'Calling Lists','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,27,1,'Campaigns','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,28,1,'Treatments','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,29,1,'Filters','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,30,1,'Time Zones','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,31,1,'Voice Prompts','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,32,0,'IVR Ports','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,33,1,'IVRs','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,34,1,'Alarm Conditions','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,35,1,'Business Attributes','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,36,0,'Attribute Values','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,37,1,'Objective Tables','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,38,0,'Campaign Groups','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,39,0,'GVP Resellers','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,40,0,'GVP Customers','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,41,1,'Voice Platform Profiles','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,42,1,'Scheduled Tasks','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,49,43,1,'Roles','Enum_CfgDefaultFolderType')

INSERT INTO cfg_locale VALUES(1033,8,50,0,0,'Unknown Type','Enum_CfgAccessGroupType')

INSERT INTO cfg_locale VALUES(1033,8,50,1,0,'Default Group Type','Enum_CfgAccessGroupType')

INSERT INTO cfg_locale VALUES(1033,8,50,2,0,'Users','Enum_CfgAccessGroupType')

INSERT INTO cfg_locale VALUES(1033,8,50,3,0,'Administrators','Enum_CfgAccessGroupType')

INSERT INTO cfg_locale VALUES(1033,8,50,4,0,'SuperAdministrators','Enum_CfgAccessGroupType')

INSERT INTO cfg_locale VALUES(1033,8,50,5,0,'SYSTEM','Enum_CfgAccessGroupType')

INSERT INTO cfg_locale VALUES(1033,8,50,6,0,'EVERYONE','Enum_CfgAccessGroupType')

INSERT INTO cfg_locale VALUES(1033,8,51,0,0,'Unknown Type','Enum_CfgEnumeratorObjectType')

INSERT INTO cfg_locale VALUES(1033,8,51,1,0,'Media Type','Enum_CfgEnumeratorObjectType')

INSERT INTO cfg_locale VALUES(1033,8,51,2,0,'Service Type','Enum_CfgEnumeratorObjectType')

INSERT INTO cfg_locale VALUES(1033,8,51,3,0,'Customer Segment','Enum_CfgEnumeratorObjectType')

INSERT INTO cfg_locale VALUES(1033,8,51,4,0,'IVR Text To Speech Used','Enum_CfgEnumeratorObjectType')

INSERT INTO cfg_locale VALUES(1033,8,51,5,0,'IVR Speech Recognition Used','Enum_CfgEnumeratorObjectType')

INSERT INTO cfg_locale VALUES(1033,8,51,6,0,'IVR Application Name','Enum_CfgEnumeratorObjectType')

INSERT INTO cfg_locale VALUES(1033,8,51,7,0,'IVR Technical Result','Enum_CfgEnumeratorObjectType')

INSERT INTO cfg_locale VALUES(1033,8,51,8,0,'IVR Technical Result Reason','Enum_CfgEnumeratorObjectType')

INSERT INTO cfg_locale VALUES(1033,8,51,9,0,'Case ID','Enum_CfgEnumeratorObjectType')

INSERT INTO cfg_locale VALUES(1033,8,51,10,0,'Business Result','Enum_CfgEnumeratorObjectType')

INSERT INTO cfg_locale VALUES(1033,8,51,11,0,'Root Interaction ID','Enum_CfgEnumeratorObjectType')

INSERT INTO cfg_locale VALUES(1033,8,52,100,0,'Media Voice','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,101,0,'MediaVoIP','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,102,0,'Media Voice','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,103,0,'Media EMail','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,104,0,'Media VMail','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,105,0,'Media SMail','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,106,0,'Media Chat','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,107,0,'Media Cobrowsing','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,108,0,'Media Whiteboard','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,109,0,'Media AppSharing','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,110,0,'Media WebForm','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,111,0,'Media Work Item','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,112,0,'Media Callback','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,113,0,'Media Fax','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,114,0,'Media IMChat','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,115,0,'Media Business Event','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,116,0,'Media Alert','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,117,0,'Media SMS','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,118,0,'Media Any','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,119,0,'Media SMS Session','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,120,0,'Media MMS','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,121,0,'Media MMS Session','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,52,1000,0,'Media Custom0','Enum_CfgMediaType')

INSERT INTO cfg_locale VALUES(1033,8,55,0,0,'Unknown Flag','Enum_CfgDNRegisterFlag')

INSERT INTO cfg_locale VALUES(1033,8,55,1,0,'False','Enum_CfgDNRegisterFlag')

INSERT INTO cfg_locale VALUES(1033,8,55,2,0,'True','Enum_CfgDNRegisterFlag')

INSERT INTO cfg_locale VALUES(1033,8,55,3,0,'On Demand','Enum_CfgDNRegisterFlag')

INSERT INTO cfg_locale VALUES(1033,8,56,0,0,'Unknown','Enum_CfgEnumeratorType')

INSERT INTO cfg_locale VALUES(1033,8,56,1,0,'Interaction Operational Attribute','Enum_CfgEnumeratorType')

INSERT INTO cfg_locale VALUES(1033,8,56,2,0,'Role','Enum_CfgEnumeratorType')

INSERT INTO cfg_locale VALUES(1033,8,56,3,0,'Contact Attribute','Enum_CfgEnumeratorType')

INSERT INTO cfg_locale VALUES(1033,8,56,4,0,'Custom','Enum_CfgEnumeratorType')

INSERT INTO cfg_locale VALUES(1033,8,56,5,0,'GVP Master List','Enum_CfgEnumeratorType')

INSERT INTO cfg_locale VALUES(1033,8,56,6,0,'GVP Custom List','Enum_CfgEnumeratorType')

INSERT INTO cfg_locale VALUES(1033,8,56,7,0,'GVP Master Default','Enum_CfgEnumeratorType')

INSERT INTO cfg_locale VALUES(1033,8,56,8,0,'GVP Custom Default','Enum_CfgEnumeratorType')

INSERT INTO cfg_locale VALUES(1033,8,56,9,0,'GVP Alias','Enum_CfgEnumeratorType')

INSERT INTO cfg_locale VALUES(1033,8,58,0,0,'Unknown','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,1,0,'Time Zone Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,2,0,'Contract Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,3,0,'Site Transfer Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,4,0,'GVP Customer Group Customer Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,5,0,'GVP IVRProfile Group IVRProfile Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,6,0,'GVP Server Type Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,7,0,'GVP Server Disabled Type Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,8,0,'GVP Server Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,9,0,'GVP Process Node Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,10,0,'GVP Data Node Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,11,0,'GVP Template Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,12,0,'Host Group Host Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,13,0,'Task GVP IVRProfile Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,14,0,'Task GVP Customer Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,15,0,'Task Switch Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,16,0,'Task Host Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,17,0,'Enumerator Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,18,0,'Enumerator Value Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,19,0,'Script Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,58,20,0,'Application Resource','Enum_CfgResourceType')

INSERT INTO cfg_locale VALUES(1033,8,59,0,0,'Unknown','Enum_CfgFolderClass')

INSERT INTO cfg_locale VALUES(1033,8,59,1,0,'Default','Enum_CfgFolderClass')

INSERT INTO cfg_locale VALUES(1033,8,59,2,0,'Site','Enum_CfgFolderClass')

INSERT INTO cfg_locale VALUES(1033,8,59,3,0,'GVP Customer Group','Enum_CfgFolderClass')

INSERT INTO cfg_locale VALUES(1033,8,59,4,0,'GVP IVRProfile Group','Enum_CfgFolderClass')

INSERT INTO cfg_locale VALUES(1033,8,59,5,0,'GVP Root','Enum_CfgFolderClass')

INSERT INTO cfg_locale VALUES(1033,8,59,6,0,'Host Group','Enum_CfgFolderClass')

INSERT INTO cfg_locale VALUES(1033,8,59,7,0,'GVP Customer Groups','Enum_CfgFolderClass')

INSERT INTO cfg_locale VALUES(1033,8,59,8,0,'GVP IVR Profile Groups','Enum_CfgFolderClass')

INSERT INTO cfg_locale VALUES(1033,8,59,9,0,'Host Groups','Enum_CfgFolderClass')

INSERT INTO cfg_locale VALUES(1033,8,59,10,0,'DID Groups','Enum_CfgFolderClass')

INSERT INTO cfg_locale VALUES(1033,8,59,11,0,'DIDs','Enum_CfgFolderClass')

INSERT INTO cfg_locale VALUES(1033,8,60,0,0,'Unknown','Enum_CfgStatDayType')

INSERT INTO cfg_locale VALUES(1033,8,60,1,0,'Default','Enum_CfgStatDayType')

INSERT INTO cfg_locale VALUES(1033,8,60,2,0,'Day Contract','Enum_CfgStatDayType')

INSERT INTO cfg_locale VALUES(1033,8,61,0,0,'Unknown','Enum_CfgIVRProfileType')

INSERT INTO cfg_locale VALUES(1033,8,61,1,0,'Inbound','Enum_CfgIVRProfileType')

INSERT INTO cfg_locale VALUES(1033,8,61,2,0,'Outbound','Enum_CfgIVRProfileType')

INSERT INTO cfg_locale VALUES(1033,8,62,0,0,'Unknown','Enum_CfgTaskType')

INSERT INTO cfg_locale VALUES(1033,8,62,1,0,'Update Application IVR','Enum_CfgTaskType')

INSERT INTO cfg_locale VALUES(1033,8,62,2,0,'Regenerate IVRProfiles','Enum_CfgTaskType')

INSERT INTO cfg_locale VALUES(1033,8,62,3,0,'Regenerate DID Groups','Enum_CfgTaskType')

INSERT INTO cfg_locale VALUES(1033,8,62,4,0,'Swap IVR URLs','Enum_CfgTaskType')

INSERT INTO cfg_locale VALUES(1033,8,63,0,0,'Unknown','Enum_CfgObjectiveTableType')

INSERT INTO cfg_locale VALUES(1033,8,63,1,0,'Default','Enum_CfgObjectiveTableType')

INSERT INTO cfg_locale VALUES(1033,8,63,2,0,'Cost Contract','Enum_CfgObjectiveTableType')

INSERT INTO cfg_locale VALUES(1033,8,64,0,0,'Unknown','Enum_CfgDIDGroupType')

INSERT INTO cfg_locale VALUES(1033,8,64,1,0,'Dialable','Enum_CfgDIDGroupType')

INSERT INTO cfg_locale VALUES(1033,8,64,2,0,'ReRoute','Enum_CfgDIDGroupType')

INSERT INTO cfg_locale VALUES(1033,8,65,0,0,'Unknown','Enum_CfgAppComponentUnknown')

INSERT INTO cfg_locale VALUES(1033,8,65,1,0,'ComponentSubProcess','Enum_CfgAppComponentSubProcess')

INSERT INTO cfg_locale VALUES(1033,8,65,2,0,'ComponentService','Enum_CfgAppComponentService')

INSERT INTO cfg_locale VALUES(1033,8,65,3,0,'Component','Enum_CfgAppComponent')

INSERT INTO cfg_locale VALUES(1033,8,65,4,0,'ComponentAccessPoint','Enum_CfgAppComponentAccessPoint')

INSERT INTO cfg_locale VALUES(1033,8,66,0,0,'Undefined','Enum_CfgCTILinkType')

INSERT INTO cfg_locale VALUES(1033,8,66,1,0,'TCP','Enum_CfgCTILinkType')

INSERT INTO cfg_locale VALUES(1033,8,66,2,0,'X25','Enum_CfgCTILinkType')

INSERT INTO cfg_locale VALUES(1033,8,66,3,0,'VendorLibrary','Enum_CfgCTILinkType')

INSERT INTO cfg_locale VALUES(1033,8,67,1000,0,'CFGLibSyntax','Enum_CFGLibSyntax')

INSERT INTO cfg_locale VALUES(1033,8,67,1001,0,'Lib Attribute','Enum_CFGLibAttribute')

INSERT INTO cfg_locale VALUES(1033,8,67,1002,0,'Lib Property','Enum_CFGLibProperty')

INSERT INTO cfg_locale VALUES(1033,8,67,1003,0,'Lib Class','Enum_CFGLibClass')

INSERT INTO cfg_locale VALUES(1033,8,67,1004,0,'Lib Message Attribute','Enum_CFGLibMessageAttribute')

INSERT INTO cfg_locale VALUES(1033,8,67,1005,0,'Lib Message Param','Enum_CFGLibMessageParam')

INSERT INTO cfg_locale VALUES(1033,8,67,1006,0,'Lib Message','Enum_CFGLibMessage')

INSERT INTO cfg_locale VALUES(1033,8,67,1007,0,'Lib Enum Pair','Enum_CFGLibEnumPair')

INSERT INTO cfg_locale VALUES(1033,8,67,1008,0,'Lib Enumerator','Enum_CFGLibEnumerator')

INSERT INTO cfg_locale VALUES(1033,8,67,1009,0,'Lib Error','Enum_CFGLibError')

INSERT INTO cfg_locale VALUES(1033,8,67,1010,0,'Lib Schema','Enum_CFGLibSchema')

INSERT INTO cfg_locale VALUES(1033,8,67,1011,0,'Group','Enum_CFGGroup')

INSERT INTO cfg_locale VALUES(1033,8,67,1012,0,'AgentInfo','Enum_CFGSAgentInfo')

INSERT INTO cfg_locale VALUES(1033,8,67,1013,0,'Address','Enum_CFGSAddress')

INSERT INTO cfg_locale VALUES(1033,8,67,1014,0,'Phones','Enum_CFGSPhones')

INSERT INTO cfg_locale VALUES(1033,8,67,1015,0,'OS Info','Enum_CFGSOSInfo')

INSERT INTO cfg_locale VALUES(1033,8,67,1016,0,'Owner ID','Enum_CFGSOwnerID')

INSERT INTO cfg_locale VALUES(1033,8,67,1017,0,'Switch Access','Enum_CFGSwitchAccess')

INSERT INTO cfg_locale VALUES(1033,8,67,1018,0,'Del Switch Access','Enum_CFGDelSwitchAccess')

INSERT INTO cfg_locale VALUES(1033,8,67,1019,0,'DN Access Number','Enum_CFGDNAccessNumber')

INSERT INTO cfg_locale VALUES(1033,8,67,1020,0,'APP Rank','Enum_CFGAPPRank')

INSERT INTO cfg_locale VALUES(1033,8,67,1021,0,'Skill Level','Enum_CFGSkillLevel')

INSERT INTO cfg_locale VALUES(1033,8,67,1022,0,'Agent Login Info','Enum_CFGAgentLoginInfo')

INSERT INTO cfg_locale VALUES(1033,8,67,1023,0,'DN Info','Enum_CFGDNInfo')

INSERT INTO cfg_locale VALUES(1033,8,67,1024,0,'TService Info','Enum_CFGTServiceInfo')

INSERT INTO cfg_locale VALUES(1033,8,67,1025,0,'App Service Permission','Enum_CFGAppServicePermission')

INSERT INTO cfg_locale VALUES(1033,8,67,1026,0,'Server','Enum_CFGServer')

INSERT INTO cfg_locale VALUES(1033,8,67,1027,0,'Subcode','Enum_CFGSubcode')

INSERT INTO cfg_locale VALUES(1033,8,67,1028,0,'Stat Interval','Enum_CFGStatInterval')

INSERT INTO cfg_locale VALUES(1033,8,67,1029,0,'Calling ListInfo','Enum_CFGCallingListInfo')

INSERT INTO cfg_locale VALUES(1033,8,67,1030,0,'Campaign Group Info','Enum_CFGCampaignGroupInfo')

INSERT INTO cfg_locale VALUES(1033,8,67,1031,0,'Alarm Event','Enum_CFGAlarmEvent')

INSERT INTO cfg_locale VALUES(1033,8,67,1032,0,'Solution Component','Enum_CFGSolutionComponent')

INSERT INTO cfg_locale VALUES(1033,8,67,1033,0,'ID','Enum_CFGID')

INSERT INTO cfg_locale VALUES(1033,8,67,1034,0,'ACE','Enum_CFGACE')

INSERT INTO cfg_locale VALUES(1033,8,67,1035,0,'ACL','Enum_CFGACL')

INSERT INTO cfg_locale VALUES(1033,8,67,1036,0,'Server Host ID','Enum_CFGServerHostID')

INSERT INTO cfg_locale VALUES(1033,8,67,1037,0,'Server Version','Enum_CFGServerVersion')

INSERT INTO cfg_locale VALUES(1033,8,67,1038,0,'Conn Info','Enum_CFGConnInfo')

INSERT INTO cfg_locale VALUES(1033,8,67,1039,0,'Lib Filter','Enum_CFGLibFilter')

INSERT INTO cfg_locale VALUES(1033,8,67,1040,0,'Solution Component Def','Enum_CFGSolutionComponentDef')

INSERT INTO cfg_locale VALUES(1033,8,67,1041,0,'Objective Table Record','Enum_CFGObjectiveTableRecord')

INSERT INTO cfg_locale VALUES(1033,8,67,1042,0,'Update Package Record','Enum_CFGUpdatePackageRecord')

INSERT INTO cfg_locale VALUES(1033,8,67,1043,0,'Lib Link','Enum_CFGLibLink')

INSERT INTO cfg_locale VALUES(1033,8,67,1044,0,'Object Resource','Enum_CFGObjectResource')

INSERT INTO cfg_locale VALUES(1033,8,67,1045,0,'Port Info','Enum_CFGPortInfo')

INSERT INTO cfg_locale VALUES(1033,8,67,1046,0,'Role Member','Enum_CFGRoleMember')

INSERT INTO cfg_locale VALUES(1033,8,67,1047,0,'Password History','Enum_CFGPasswordHistory')

INSERT INTO cfg_locale VALUES(1033,8,68,1311309924,0,'default','PID_CFGLocaleName_9_100')

INSERT INTO cfg_locale VALUES(1033,8,68,1311309925,0,'ITCUtility','PID_CFGLocaleName_9_101')

INSERT INTO cfg_locale VALUES(1033,8,68,1311309926,0,'Genesys Administrator','PID_CFGLocaleName_9_102')

INSERT INTO cfg_locale VALUES(1033,8,68,1311309927,0,'Genesys Administrator Server','PID_CFGLocaleName_9_103')

INSERT INTO cfg_locale VALUES(1033,8,68,1311309923,0,'confserv','PID_CFGLocaleName_9_99')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161893,0,'Application Templates','PID_CFGLocaleName_22_101')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161894,0,'Applications','PID_CFGLocaleName_22_102')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161895,0,'Hosts','PID_CFGLocaleName_22_103')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161896,0,'Switching Offices','PID_CFGLocaleName_22_104')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161897,0,'Persons','PID_CFGLocaleName_22_105')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161898,0,'Place Groups','PID_CFGLocaleName_22_106')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161899,0,'Solutions','PID_CFGLocaleName_22_107')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161900,0,'Switches','PID_CFGLocaleName_22_108')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161901,0,'Access Groups','PID_CFGLocaleName_22_109')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161902,0,'Places','PID_CFGLocaleName_22_110')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161903,0,'Agent Groups','PID_CFGLocaleName_22_111')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161904,0,'DN Groups','PID_CFGLocaleName_22_112')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161905,0,'Skills','PID_CFGLocaleName_22_113')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161906,0,'Scripts','PID_CFGLocaleName_22_114')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161907,0,'Action Codes','PID_CFGLocaleName_22_115')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161908,0,'Transactions','PID_CFGLocaleName_22_116')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161909,0,'Statistical Days','PID_CFGLocaleName_22_117')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161910,0,'Statistical Tables','PID_CFGLocaleName_22_118')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161911,0,'Configuration','PID_CFGLocaleName_22_119')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161912,0,'Fields','PID_CFGLocaleName_22_120')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161913,0,'Formats','PID_CFGLocaleName_22_121')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161914,0,'Table Access','PID_CFGLocaleName_22_122')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161915,0,'Calling Lists','PID_CFGLocaleName_22_123')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161916,0,'Campaigns','PID_CFGLocaleName_22_124')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161917,0,'Treatments','PID_CFGLocaleName_22_125')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161918,0,'Filters','PID_CFGLocaleName_22_126')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161919,0,'Time Zones','PID_CFGLocaleName_22_127')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161920,0,'Voice Prompts','PID_CFGLocaleName_22_128')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161921,0,'IVRs','PID_CFGLocaleName_22_129')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161922,0,'Alarm Conditions','PID_CFGLocaleName_22_130')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161923,0,'Business Attributes','PID_CFGLocaleName_22_131')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161924,0,'Objective Tables','PID_CFGLocaleName_22_132')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161925,0,'Attribute Values','PID_CFGLocaleName_22_133')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161926,0,'Attribute Values','PID_CFGLocaleName_22_134')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161927,0,'Attribute Values','PID_CFGLocaleName_22_135')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161928,0,'Attribute Values','PID_CFGLocaleName_22_136')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161929,0,'Attribute Values','PID_CFGLocaleName_22_137')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161930,0,'Attribute Values','PID_CFGLocaleName_22_138')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161931,0,'Attribute Values','PID_CFGLocaleName_22_139')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161932,0,'Attribute Values','PID_CFGLocaleName_22_140')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161933,0,'Attribute Values','PID_CFGLocaleName_22_141')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161934,0,'Attribute Values','PID_CFGLocaleName_22_142')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161935,0,'Attribute Values','PID_CFGLocaleName_22_143')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161948,0,'Voice Platform Profiles','PID_CFGLocaleName_22_156')

INSERT INTO cfg_locale VALUES(1033,8,68,1312161949,0,'Roles','PID_CFGLocaleName_22_157')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227429,0,'record_id','PID_CFGLocaleName_23_101')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227430,0,'phone','PID_CFGLocaleName_23_102')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227431,0,'phone_type','PID_CFGLocaleName_23_103')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227432,0,'record_type','PID_CFGLocaleName_23_104')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227433,0,'record_status','PID_CFGLocaleName_23_105')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227434,0,'call_result','PID_CFGLocaleName_23_106')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227435,0,'attempt','PID_CFGLocaleName_23_107')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227436,0,'dial_sched_time','PID_CFGLocaleName_23_108')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227437,0,'call_time','PID_CFGLocaleName_23_109')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227438,0,'daily_from','PID_CFGLocaleName_23_110')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227439,0,'daily_till','PID_CFGLocaleName_23_111')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227440,0,'tz_dbid','PID_CFGLocaleName_23_112')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227441,0,'campaign_id','PID_CFGLocaleName_23_113')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227442,0,'agent_id','PID_CFGLocaleName_23_114')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227443,0,'chain_id','PID_CFGLocaleName_23_115')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227444,0,'chain_n','PID_CFGLocaleName_23_116')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227445,0,'group_id','PID_CFGLocaleName_23_117')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227446,0,'app_id','PID_CFGLocaleName_23_118')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227447,0,'treatments','PID_CFGLocaleName_23_119')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227448,0,'media_ref','PID_CFGLocaleName_23_120')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227449,0,'contact_info','PID_CFGLocaleName_23_121')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227450,0,'contact_info_type','PID_CFGLocaleName_23_122')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227451,0,'email_subject','PID_CFGLocaleName_23_123')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227452,0,'email_template_id','PID_CFGLocaleName_23_124')

INSERT INTO cfg_locale VALUES(1033,8,68,1312227453,0,'switch_id','PID_CFGLocaleName_23_125')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686181,0,'GMT','PID_CFGLocaleName_30_101')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686182,0,'ECT','PID_CFGLocaleName_30_102')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686183,0,'EET','PID_CFGLocaleName_30_103')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686184,0,'ART','PID_CFGLocaleName_30_104')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686185,0,'EAT','PID_CFGLocaleName_30_105')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686186,0,'MET','PID_CFGLocaleName_30_106')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686187,0,'NET','PID_CFGLocaleName_30_107')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686188,0,'PLT','PID_CFGLocaleName_30_108')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686189,0,'IST','PID_CFGLocaleName_30_109')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686190,0,'BST','PID_CFGLocaleName_30_110')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686191,0,'VST','PID_CFGLocaleName_30_111')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686192,0,'CTT','PID_CFGLocaleName_30_112')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686193,0,'JST','PID_CFGLocaleName_30_113')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686194,0,'KST','PID_CFGLocaleName_30_114')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686195,0,'ACT','PID_CFGLocaleName_30_115')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686196,0,'AET','PID_CFGLocaleName_30_116')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686197,0,'SST','PID_CFGLocaleName_30_117')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686198,0,'NST','PID_CFGLocaleName_30_118')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686199,0,'MIT','PID_CFGLocaleName_30_119')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686200,0,'HST','PID_CFGLocaleName_30_120')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686201,0,'AST','PID_CFGLocaleName_30_121')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686202,0,'PST','PID_CFGLocaleName_30_122')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686203,0,'PNT','PID_CFGLocaleName_30_123')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686204,0,'MST','PID_CFGLocaleName_30_124')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686205,0,'CST','PID_CFGLocaleName_30_125')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686206,0,'EST','PID_CFGLocaleName_30_126')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686207,0,'IET','PID_CFGLocaleName_30_127')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686208,0,'PRT','PID_CFGLocaleName_30_128')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686209,0,'CNT','PID_CFGLocaleName_30_129')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686210,0,'AGT','PID_CFGLocaleName_30_130')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686211,0,'BET','PID_CFGLocaleName_30_131')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686212,0,'CAT','PID_CFGLocaleName_30_132')

INSERT INTO cfg_locale VALUES(1033,8,68,1312686213,0,'AtlST','PID_CFGLocaleName_30_133')

INSERT INTO cfg_locale VALUES(1033,8,68,1312948325,0,'Connection Failure','PID_CFGLocaleName_34_101')

INSERT INTO cfg_locale VALUES(1033,8,68,1312948326,0,'Application Failure','PID_CFGLocaleName_34_102')

INSERT INTO cfg_locale VALUES(1033,8,68,1312948327,0,'CTI Link Failure','PID_CFGLocaleName_34_103')

INSERT INTO cfg_locale VALUES(1033,8,68,1312948328,0,'Licensing Error','PID_CFGLocaleName_34_104')

INSERT INTO cfg_locale VALUES(1033,8,68,1312948329,0,'Host Inaccessible','PID_CFGLocaleName_34_105')

INSERT INTO cfg_locale VALUES(1033,8,68,1312948330,0,'Service Unavailable','PID_CFGLocaleName_34_106')

INSERT INTO cfg_locale VALUES(1033,8,68,1312948331,0,'Host Unavailable','PID_CFGLocaleName_34_107')

INSERT INTO cfg_locale VALUES(1033,8,68,1312948332,0,'Host Unreachable','PID_CFGLocaleName_34_108')

INSERT INTO cfg_locale VALUES(1033,8,68,1312948333,0,'Unplanned Solution Status Change','PID_CFGLocaleName_34_109')

INSERT INTO cfg_locale VALUES(1033,8,68,1312948334,0,'Message Server Loss of Database Connection','PID_CFGLocaleName_34_110')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013861,0,'MediaType','PID_CFGLocaleName_35_101')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013862,0,'ServiceType','PID_CFGLocaleName_35_102')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013863,0,'CustomerSegment','PID_CFGLocaleName_35_103')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013864,0,'IVR Text To Speech Used','PID_CFGLocaleName_35_104')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013865,0,'IVR Speech Recognition Used','PID_CFGLocaleName_35_105')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013866,0,'IVR Application Name','PID_CFGLocaleName_35_106')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013867,0,'IVR Technical Result','PID_CFGLocaleName_35_107')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013868,0,'IVR Technical Result Reason','PID_CFGLocaleName_35_108')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013869,0,'Case ID','PID_CFGLocaleName_35_109')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013870,0,'Business Result','PID_CFGLocaleName_35_110')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013871,0,'Root Interaction ID','PID_CFGLocaleName_35_111')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013872,0,'InteractionType','PID_CFGLocaleName_35_112')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013873,0,'InteractionSubtype','PID_CFGLocaleName_35_113')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013874,0,'CategoryStructure','PID_CFGLocaleName_35_114')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013875,0,'ScreeningRules','PID_CFGLocaleName_35_115')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013876,0,'EmailAccounts','PID_CFGLocaleName_35_116')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013877,0,'StopProcessingReason','PID_CFGLocaleName_35_117')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013878,0,'Language','PID_CFGLocaleName_35_118')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013879,0,'DispositionCode','PID_CFGLocaleName_35_119')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013880,0,'ReasonCode','PID_CFGLocaleName_35_120')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013881,0,'InteractionAttributes','PID_CFGLocaleName_35_121')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013882,0,'ContactAttributes','PID_CFGLocaleName_35_122')

INSERT INTO cfg_locale VALUES(1033,8,68,1313013883,0,'PlaceInQueueReason','PID_CFGLocaleName_35_123')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079396,0,'voice','PID_CFGLocaleName_36_100')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079397,0,'voip','PID_CFGLocaleName_36_101')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079398,0,'email','PID_CFGLocaleName_36_102')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079399,0,'vmail','PID_CFGLocaleName_36_103')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079400,0,'smail','PID_CFGLocaleName_36_104')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079401,0,'chat','PID_CFGLocaleName_36_105')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079402,0,'video','PID_CFGLocaleName_36_106')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079403,0,'cobrowsing','PID_CFGLocaleName_36_107')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079404,0,'whiteboard','PID_CFGLocaleName_36_108')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079405,0,'appsharing','PID_CFGLocaleName_36_109')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079406,0,'webform','PID_CFGLocaleName_36_110')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079407,0,'workitem','PID_CFGLocaleName_36_111')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079408,0,'callback','PID_CFGLocaleName_36_112')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079409,0,'fax','PID_CFGLocaleName_36_113')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079410,0,'imchat','PID_CFGLocaleName_36_114')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079411,0,'busevent','PID_CFGLocaleName_36_115')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079412,0,'alert','PID_CFGLocaleName_36_116')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079413,0,'sms','PID_CFGLocaleName_36_117')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079414,0,'any','PID_CFGLocaleName_36_118')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079415,0,'auxwork','PID_CFGLocaleName_36_119')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079416,0,'outboundpreview','PID_CFGLocaleName_36_120')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079417,0,'trainingitem','PID_CFGLocaleName_36_121')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079418,0,'smssession','PID_CFGLocaleName_36_122')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079419,0,'mms','PID_CFGLocaleName_36_123')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079420,0,'mmssession','PID_CFGLocaleName_36_124')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079496,0,'default','PID_CFGLocaleName_36_200')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079596,0,'default','PID_CFGLocaleName_36_300')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079646,0,'unknown','PID_CFGLocaleName_36_350')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079649,0,'unknown','PID_CFGLocaleName_36_353')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079696,0,'Inbound','PID_CFGLocaleName_36_400')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079697,0,'Outbound','PID_CFGLocaleName_36_401')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079698,0,'Internal','PID_CFGLocaleName_36_402')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079699,0,'InboundNew','PID_CFGLocaleName_36_403')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079700,0,'InboundCustomerReply','PID_CFGLocaleName_36_404')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079701,0,'InboundCollaborationReply','PID_CFGLocaleName_36_405')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079702,0,'InboundNDR','PID_CFGLocaleName_36_406')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079703,0,'OutboundNew','PID_CFGLocaleName_36_407')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079704,0,'OutboundReply','PID_CFGLocaleName_36_408')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079705,0,'OutboundAcknowledgement','PID_CFGLocaleName_36_409')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079706,0,'OutboundAutoResponse','PID_CFGLocaleName_36_410')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079707,0,'OutboundRedirect','PID_CFGLocaleName_36_411')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079708,0,'OutboundCollaborationInvite','PID_CFGLocaleName_36_412')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079709,0,'InternalCollaborationInvite','PID_CFGLocaleName_36_413')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079710,0,'InternalCollaborationReply','PID_CFGLocaleName_36_414')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079711,0,'Normal','PID_CFGLocaleName_36_415')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079712,0,'AutoResponded','PID_CFGLocaleName_36_416')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079713,0,'Terminated','PID_CFGLocaleName_36_417')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079714,0,'Sent','PID_CFGLocaleName_36_418')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079715,0,'Forwarded','PID_CFGLocaleName_36_419')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079716,0,'Re-directed','PID_CFGLocaleName_36_420')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079717,0,'English','PID_CFGLocaleName_36_421')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079718,0,'Priority','PID_CFGLocaleName_36_422')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079719,0,'Category','PID_CFGLocaleName_36_423')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079720,0,'ServiceType','PID_CFGLocaleName_36_424')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079721,0,'MediaType','PID_CFGLocaleName_36_425')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079722,0,'InteractionType','PID_CFGLocaleName_36_426')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079723,0,'InteractionSubtype','PID_CFGLocaleName_36_427')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079724,0,'Language','PID_CFGLocaleName_36_428')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079725,0,'StopProcessingReason','PID_CFGLocaleName_36_429')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079726,0,'DispositionCode','PID_CFGLocaleName_36_430')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079727,0,'ReasonCode','PID_CFGLocaleName_36_431')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079728,0,'FirstName','PID_CFGLocaleName_36_432')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079729,0,'LastName','PID_CFGLocaleName_36_433')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079730,0,'Title','PID_CFGLocaleName_36_434')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079731,0,'EmailAddress','PID_CFGLocaleName_36_435')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079732,0,'PhoneNumber','PID_CFGLocaleName_36_436')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079733,0,'AccountNumber','PID_CFGLocaleName_36_437')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079734,0,'ContactId','PID_CFGLocaleName_36_438')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079735,0,'CustomerSegment','PID_CFGLocaleName_36_439')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079736,0,'PIN','PID_CFGLocaleName_36_440')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079737,0,'OutboundNotification','PID_CFGLocaleName_36_441')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079738,0,'InboundReport','PID_CFGLocaleName_36_442')

INSERT INTO cfg_locale VALUES(1033,8,68,1313079739,0,'InboundDisposition','PID_CFGLocaleName_36_443')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227429,0,'Unique record identifier','PID_CFGLocaleDesc_23_101')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227430,0,'Phone number to dial','PID_CFGLocaleDesc_23_102')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227431,0,'Phone type','PID_CFGLocaleDesc_23_103')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227432,0,'Record type','PID_CFGLocaleDesc_23_104')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227433,0,'Record status','PID_CFGLocaleDesc_23_105')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227434,0,'Dial result','PID_CFGLocaleDesc_23_106')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227435,0,'Number of attempts has been made excluding re-dials in case of errors','PID_CFGLocaleDesc_23_107')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227436,0,'Time when scheduled call must be done seconds since midnight of 01/01/1970','PID_CFGLocaleDesc_23_108')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227437,0,'Time when last call or dial attempt has been done seconds since midnight of 01/01/1970','PID_CFGLocaleDesc_23_109')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227438,0,'Earliest time to perform the call.Seconds from midnight','PID_CFGLocaleDesc_23_110')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227439,0,'Latest time to perform the call.Seconds from midnight','PID_CFGLocaleDesc_23_111')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227440,0,'Time zone DBID from Configuration Database','PID_CFGLocaleDesc_23_112')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227441,0,'DBID of the campaign with respect to the last dial attempt has been made','PID_CFGLocaleDesc_23_113')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227442,0,'Agent login identifier','PID_CFGLocaleDesc_23_114')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227443,0,'Unique identifier of chain','PID_CFGLocaleDesc_23_115')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227444,0,'Unique identifier of record within chain','PID_CFGLocaleDesc_23_116')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227445,0,'AgentGroup or PlaceGroup unique identifier','PID_CFGLocaleDesc_23_117')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227446,0,'Application unique identifier','PID_CFGLocaleDesc_23_118')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227447,0,'Treatments History','PID_CFGLocaleDesc_23_119')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227448,0,'Reference to media body to be sent in case of treatment','PID_CFGLocaleDesc_23_120')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227449,0,'Contact Info','PID_CFGLocaleDesc_23_121')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227450,0,'Contact Info Type','PID_CFGLocaleDesc_23_122')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227451,0,'Email Subject','PID_CFGLocaleDesc_23_123')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227452,0,'Email Template ID','PID_CFGLocaleDesc_23_124')

INSERT INTO cfg_locale VALUES(1033,8,69,1312227453,0,'Switch ID','PID_CFGLocaleDesc_23_125')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686181,0,'Greenwich Mean Time','PID_CFGLocaleDesc_30_101')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686182,0,'European Central Time','PID_CFGLocaleDesc_30_102')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686183,0,'Eastern European Time','PID_CFGLocaleDesc_30_103')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686184,0,'(Arabic) Egypt Standard Time','PID_CFGLocaleDesc_30_104')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686185,0,'Eastern African Time','PID_CFGLocaleDesc_30_105')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686186,0,'Middle East Time','PID_CFGLocaleDesc_30_106')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686187,0,'Near East Time','PID_CFGLocaleDesc_30_107')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686188,0,'Pakistan Lahore Time','PID_CFGLocaleDesc_30_108')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686189,0,'India Standard Time','PID_CFGLocaleDesc_30_109')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686190,0,'Bangladesh Standard Time','PID_CFGLocaleDesc_30_110')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686191,0,'Vietnam Standard Time','PID_CFGLocaleDesc_30_111')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686192,0,'China Taiwan Time','PID_CFGLocaleDesc_30_112')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686193,0,'Japan Standard Time','PID_CFGLocaleDesc_30_113')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686194,0,'Korea Standard Time','PID_CFGLocaleDesc_30_114')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686195,0,'Australia Central Time','PID_CFGLocaleDesc_30_115')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686196,0,'Australia Eastern Time','PID_CFGLocaleDesc_30_116')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686197,0,'Solomon Standard Time','PID_CFGLocaleDesc_30_117')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686198,0,'New Zealand Standard Time','PID_CFGLocaleDesc_30_118')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686199,0,'Midway Islands Time','PID_CFGLocaleDesc_30_119')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686200,0,'Hawaii Standard Time','PID_CFGLocaleDesc_30_120')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686201,0,'Alaska Standard Time','PID_CFGLocaleDesc_30_121')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686202,0,'Pacific Standard Time','PID_CFGLocaleDesc_30_122')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686203,0,'Phoenix Standard Time','PID_CFGLocaleDesc_30_123')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686204,0,'Mountain Standard Time','PID_CFGLocaleDesc_30_124')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686205,0,'Central Standard Time','PID_CFGLocaleDesc_30_125')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686206,0,'Eastern Standard Time','PID_CFGLocaleDesc_30_126')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686207,0,'Indiana Eastern Standard','PID_CFGLocaleDesc_30_127')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686208,0,'Puerto Rico and US Virgin Islands Time','PID_CFGLocaleDesc_30_128')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686209,0,'Canada Newfoundland Time','PID_CFGLocaleDesc_30_129')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686210,0,'Argentina Standard Time','PID_CFGLocaleDesc_30_130')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686211,0,'Brazil Eastern Time','PID_CFGLocaleDesc_30_131')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686212,0,'Central African Time','PID_CFGLocaleDesc_30_132')

INSERT INTO cfg_locale VALUES(1033,8,69,1312686213,0,'Atlantic Standard Time','PID_CFGLocaleDesc_30_133')

INSERT INTO cfg_locale VALUES(1033,8,69,1312948325,0,'The connection between any two Genesys components has been lost.','PID_CFGLocaleDesc_34_101')

INSERT INTO cfg_locale VALUES(1033,8,69,1312948326,0,'Failure of any daemon Genesys component monitored by the Management Layer.','PID_CFGLocaleDesc_34_102')

INSERT INTO cfg_locale VALUES(1033,8,69,1312948327,0,'Failure of connection between any T-Server and switch.','PID_CFGLocaleDesc_34_103')

INSERT INTO cfg_locale VALUES(1033,8,69,1312948328,0,'Any licensing error identified by any Genesys component.','PID_CFGLocaleDesc_34_104')

INSERT INTO cfg_locale VALUES(1033,8,69,1312948329,0,'The Management Layer cannot contact the Local Control Agent on the host where Genesys daemon applications are running. Local Control Agent is not started','PID_CFGLocaleDesc_34_105')

INSERT INTO cfg_locale VALUES(1033,8,69,1312948330,0,'Daemon Genesys component is unable to provide service for some internal reasons.','PID_CFGLocaleDesc_34_106')

INSERT INTO cfg_locale VALUES(1033,8,69,1312948331,0,'A host where Genesys daemon applications are running is unavailable','PID_CFGLocaleDesc_34_107')

INSERT INTO cfg_locale VALUES(1033,8,69,1312948332,0,'The Management Layer cannot reach the host where Genesys daemon applications are running','PID_CFGLocaleDesc_34_108')

INSERT INTO cfg_locale VALUES(1033,8,69,1312948333,0,'Solution status has changed from Started to Pending without any requests to stop the Solution. This may indicate a failure of one of the Solution components.','PID_CFGLocaleDesc_34_109')

INSERT INTO cfg_locale VALUES(1033,8,69,1312948334,0,'Message Server has lost connection to the Centralized Log Database.','PID_CFGLocaleDesc_34_110')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013861,0,'Media type identifier','PID_CFGLocaleDesc_35_101')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013862,0,'Customer defined','PID_CFGLocaleDesc_35_102')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013863,0,'Customer defined','PID_CFGLocaleDesc_35_103')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013864,0,'Defines IVR Text To Speech Used','PID_CFGLocaleDesc_35_104')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013865,0,'Defines IVR Speech Recognition Used','PID_CFGLocaleDesc_35_105')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013866,0,'Defines IVR Application Name','PID_CFGLocaleDesc_35_106')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013867,0,'Defines IVR Technical Result','PID_CFGLocaleDesc_35_107')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013868,0,'Defines IVR Technical Result Reason','PID_CFGLocaleDesc_35_108')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013869,0,'Defines Case ID','PID_CFGLocaleDesc_35_109')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013870,0,'Defines Business Result','PID_CFGLocaleDesc_35_110')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013871,0,'Defines Root Interaction ID','PID_CFGLocaleDesc_35_111')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013872,0,'Predefined list of interaction types supported by contact center','PID_CFGLocaleDesc_35_112')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013873,0,'Predefined list of interaction subtypes supported by contact center','PID_CFGLocaleDesc_35_113')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013874,0,'Customer defined','PID_CFGLocaleDesc_35_114')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013875,0,'Customer defined','PID_CFGLocaleDesc_35_115')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013876,0,'Customer defined','PID_CFGLocaleDesc_35_116')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013877,0,'Predefined extended by customer','PID_CFGLocaleDesc_35_117')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013878,0,'Extended by customer','PID_CFGLocaleDesc_35_118')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013879,0,'Customer defined','PID_CFGLocaleDesc_35_119')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013880,0,'Customer defined','PID_CFGLocaleDesc_35_120')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013881,0,'List of predefined interaction attributes','PID_CFGLocaleDesc_35_121')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013882,0,'List of predefined contact attributes','PID_CFGLocaleDesc_35_122')

INSERT INTO cfg_locale VALUES(1033,8,69,1313013883,0,'Customer defined','PID_CFGLocaleDesc_35_123')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079396,0,'Media Voice','PID_CFGLocaleDesc_36_100')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079397,0,'Media Voice over IP','PID_CFGLocaleDesc_36_101')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079398,0,'Media EMail','PID_CFGLocaleDesc_36_102')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079399,0,'Media Voice Mail','PID_CFGLocaleDesc_36_103')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079400,0,'Media Scanned Mail','PID_CFGLocaleDesc_36_104')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079401,0,'Media Chat','PID_CFGLocaleDesc_36_105')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079402,0,'Media Video','PID_CFGLocaleDesc_36_106')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079403,0,'Media Cobrowsing','PID_CFGLocaleDesc_36_107')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079404,0,'Media Whiteboard','PID_CFGLocaleDesc_36_108')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079405,0,'Media Application Sharing','PID_CFGLocaleDesc_36_109')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079406,0,'Media Web Form','PID_CFGLocaleDesc_36_110')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079407,0,'Media Workitem','PID_CFGLocaleDesc_36_111')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079408,0,'Media Callback','PID_CFGLocaleDesc_36_112')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079409,0,'Media Fax','PID_CFGLocaleDesc_36_113')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079410,0,'Media IMChat','PID_CFGLocaleDesc_36_114')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079411,0,'Media Business Event','PID_CFGLocaleDesc_36_115')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079412,0,'Media Alert','PID_CFGLocaleDesc_36_116')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079413,0,'Media SMS','PID_CFGLocaleDesc_36_117')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079414,0,'Media Any','PID_CFGLocaleDesc_36_118')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079415,0,'Media AuxWork','PID_CFGLocaleDesc_36_119')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079416,0,'Media Outbound Preview','PID_CFGLocaleDesc_36_120')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079417,0,'Training Item','PID_CFGLocaleDesc_36_121')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079418,0,'Media SMS Session','PID_CFGLocaleDesc_36_122')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079419,0,'Media MMS','PID_CFGLocaleDesc_36_123')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079420,0,'Media MMS Session','PID_CFGLocaleDesc_36_124')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079496,0,'Service Type Default','PID_CFGLocaleDesc_36_200')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079596,0,'Customer Segment Default','PID_CFGLocaleDesc_36_300')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079646,0,'IVR Text To Speech Used Default','PID_CFGLocaleDesc_36_350')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079649,0,'IVR Speech Recognition Used Default','PID_CFGLocaleDesc_36_353')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079696,0,'Interactions received by contact center from outside clients','PID_CFGLocaleDesc_36_400')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079697,0,'Interactions sent from contact center to external clients','PID_CFGLocaleDesc_36_401')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079698,0,'Internal interactions between contact center correspondents','PID_CFGLocaleDesc_36_402')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079699,0,'New incoming email. Starts a new thread.','PID_CFGLocaleDesc_36_403')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079700,0,'Reply from a customer.','PID_CFGLocaleDesc_36_404')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079701,0,'Reply from an external resource.','PID_CFGLocaleDesc_36_405')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079702,0,'Error message sent back to the system by SMTP server chain.','PID_CFGLocaleDesc_36_406')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079703,0,'New message from Contact Center to a customer.','PID_CFGLocaleDesc_36_407')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079704,0,'Reply from Contact Center to a customer.','PID_CFGLocaleDesc_36_408')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079705,0,'Ack message sent to customer by Contact Center.','PID_CFGLocaleDesc_36_409')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079706,0,'Automated reply from Contact Center to a customer.','PID_CFGLocaleDesc_36_410')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079707,0,'Message redirect to an external resource. No reply expected.','PID_CFGLocaleDesc_36_411')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079708,0,'New message to an external resource.','PID_CFGLocaleDesc_36_412')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079709,0,'New message to an internal resource.','PID_CFGLocaleDesc_36_413')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079710,0,'Reply from an internal resource.','PID_CFGLocaleDesc_36_414')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079711,0,'StopProcessing Reason Normal','PID_CFGLocaleDesc_36_415')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079712,0,'StopProcessing Reason Auto Responded','PID_CFGLocaleDesc_36_416')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079713,0,'StopProcessing Reason Terminated','PID_CFGLocaleDesc_36_417')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079714,0,'StopProcessing Reason Sent','PID_CFGLocaleDesc_36_418')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079715,0,'StopProcessing Reason Forwarded','PID_CFGLocaleDesc_36_419')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079716,0,'StopProcessing Reason Re-directed','PID_CFGLocaleDesc_36_420')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079717,0,'Language English','PID_CFGLocaleDesc_36_421')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079718,0,'Interaction Attributes Priority','PID_CFGLocaleDesc_36_422')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079719,0,'Interaction Attributes Category','PID_CFGLocaleDesc_36_423')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079720,0,'Interaction Attributes Service Type','PID_CFGLocaleDesc_36_424')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079721,0,'Interaction Attributes Media Type','PID_CFGLocaleDesc_36_425')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079722,0,'Interaction Attributes Interaction Type','PID_CFGLocaleDesc_36_426')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079723,0,'Interaction Attributes Interaction Subtype','PID_CFGLocaleDesc_36_427')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079724,0,'Interaction Attributes Language','PID_CFGLocaleDesc_36_428')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079725,0,'Interaction Attributes StopProcessing Reason','PID_CFGLocaleDesc_36_429')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079726,0,'Interaction Attributes Disposition Code','PID_CFGLocaleDesc_36_430')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079727,0,'Interaction Attributes Reason Code','PID_CFGLocaleDesc_36_431')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079728,0,'Contact Attributes First Name','PID_CFGLocaleDesc_36_432')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079729,0,'Contact Attributes Last Name','PID_CFGLocaleDesc_36_433')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079730,0,'Contact Attributes Title','PID_CFGLocaleDesc_36_434')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079731,0,'Contact Attributes E-mail Address','PID_CFGLocaleDesc_36_435')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079732,0,'Contact Attributes Phone Number','PID_CFGLocaleDesc_36_436')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079733,0,'Contact Attributes Account Number','PID_CFGLocaleDesc_36_437')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079734,0,'Contact Attributes Contact ID','PID_CFGLocaleDesc_36_438')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079735,0,'Contact Attributes Customer Segment','PID_CFGLocaleDesc_36_439')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079736,0,'Contact Attributes PIN','PID_CFGLocaleDesc_36_440')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079737,0,'Notification from Contact center to the customer about reply stored in contact history','PID_CFGLocaleDesc_36_441')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079738,0,'Interaction delivery progress notification','PID_CFGLocaleDesc_36_442')

INSERT INTO cfg_locale VALUES(1033,8,69,1313079739,0,'Interaction Subtype Disposition','PID_CFGLocaleDesc_36_443')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686181,0,'GMT','PID_CFGLocaleDisp_30_101')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686182,0,'European Central Time','PID_CFGLocaleDisp_30_102')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686183,0,'Eastern European Time','PID_CFGLocaleDisp_30_103')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686184,0,'(Arabic) Egypt Standard Time','PID_CFGLocaleDisp_30_104')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686185,0,'Eastern African Time','PID_CFGLocaleDisp_30_105')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686186,0,'Middle East Time','PID_CFGLocaleDisp_30_106')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686187,0,'Near East Time','PID_CFGLocaleDisp_30_107')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686188,0,'Pakistan Lahore Time','PID_CFGLocaleDisp_30_108')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686189,0,'India Standard Time','PID_CFGLocaleDisp_30_109')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686190,0,'Bangladesh Standard Time','PID_CFGLocaleDisp_30_110')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686191,0,'Vietnam Standard Time','PID_CFGLocaleDisp_30_111')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686192,0,'China Taiwan Time','PID_CFGLocaleDisp_30_112')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686193,0,'Japan Standard Time','PID_CFGLocaleDisp_30_113')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686194,0,'Korea Standard Time','PID_CFGLocaleDisp_30_114')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686195,0,'Australia Central Time','PID_CFGLocaleDisp_30_115')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686196,0,'Australia Eastern Time','PID_CFGLocaleDisp_30_116')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686197,0,'Solomon Standard Time','PID_CFGLocaleDisp_30_117')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686198,0,'New Zealand Standard Time','PID_CFGLocaleDisp_30_118')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686199,0,'Midway Islands Time','PID_CFGLocaleDisp_30_119')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686200,0,'Hawaiian Standard Time','PID_CFGLocaleDisp_30_120')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686201,0,'Alaskan Standard Time','PID_CFGLocaleDisp_30_121')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686202,0,'Pacific Standard Time','PID_CFGLocaleDisp_30_122')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686203,0,'Mountain Standard Time','PID_CFGLocaleDisp_30_123')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686204,0,'US Mountain Standard Time','PID_CFGLocaleDisp_30_124')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686205,0,'Central Standard Time','PID_CFGLocaleDisp_30_125')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686206,0,'Eastern Standard Time','PID_CFGLocaleDisp_30_126')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686207,0,'Indiana Eastern Standard','PID_CFGLocaleDisp_30_127')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686208,0,'Puerto Rico and US Virgin Islands Time','PID_CFGLocaleDisp_30_128')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686209,0,'Canada Newfoundland Time','PID_CFGLocaleDisp_30_129')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686210,0,'Argentina Standard Time','PID_CFGLocaleDisp_30_130')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686211,0,'Brazil Eastern Time','PID_CFGLocaleDisp_30_131')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686212,0,'Central African Time','PID_CFGLocaleDisp_30_132')

INSERT INTO cfg_locale VALUES(1033,8,70,1312686213,0,'Atlantic Standard Time','PID_CFGLocaleDisp_30_133')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013861,0,'Media Type','PID_CFGLocaleDisp_35_101')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013862,0,'Service Type','PID_CFGLocaleDisp_35_102')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013863,0,'Customer Segment','PID_CFGLocaleDisp_35_103')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013864,0,'IVR Text To Speech Used','PID_CFGLocaleDisp_35_104')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013865,0,'IVR Speech Recognition Used','PID_CFGLocaleDisp_35_105')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013866,0,'IVR Application Name','PID_CFGLocaleDisp_35_106')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013867,0,'IVR Technical Result','PID_CFGLocaleDisp_35_107')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013868,0,'IVR Technical Result Reason','PID_CFGLocaleDisp_35_108')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013869,0,'Case ID','PID_CFGLocaleDisp_35_109')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013870,0,'Business Result','PID_CFGLocaleDisp_35_110')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013871,0,'Root Interaction ID','PID_CFGLocaleDisp_35_111')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013872,0,'Interaction Type','PID_CFGLocaleDisp_35_112')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013873,0,'Interaction Subtype','PID_CFGLocaleDisp_35_113')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013874,0,'Category Structure','PID_CFGLocaleDisp_35_114')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013875,0,'Screening Rules','PID_CFGLocaleDisp_35_115')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013876,0,'E-mail Accounts','PID_CFGLocaleDisp_35_116')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013877,0,'StopProcessing Reason','PID_CFGLocaleDisp_35_117')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013878,0,'Language','PID_CFGLocaleDisp_35_118')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013879,0,'Disposition Code','PID_CFGLocaleDisp_35_119')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013880,0,'Reason Code','PID_CFGLocaleDisp_35_120')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013881,0,'Interaction Attributes','PID_CFGLocaleDisp_35_121')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013882,0,'Contact Attributes','PID_CFGLocaleDisp_35_122')

INSERT INTO cfg_locale VALUES(1033,8,70,1313013883,0,'PlaceInQueue Reason','PID_CFGLocaleDisp_35_123')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079396,0,'voice','PID_CFGLocaleDisp_36_100')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079397,0,'voip','PID_CFGLocaleDisp_36_101')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079398,0,'email','PID_CFGLocaleDisp_36_102')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079399,0,'vmail','PID_CFGLocaleDisp_36_103')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079400,0,'smail','PID_CFGLocaleDisp_36_104')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079401,0,'chat','PID_CFGLocaleDisp_36_105')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079402,0,'video','PID_CFGLocaleDisp_36_106')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079403,0,'cobrowsing','PID_CFGLocaleDisp_36_107')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079404,0,'whiteboard','PID_CFGLocaleDisp_36_108')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079405,0,'appsharing','PID_CFGLocaleDisp_36_109')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079406,0,'webform','PID_CFGLocaleDisp_36_110')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079407,0,'workitem','PID_CFGLocaleDisp_36_111')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079408,0,'callback','PID_CFGLocaleDisp_36_112')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079409,0,'fax','PID_CFGLocaleDisp_36_113')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079410,0,'imchat','PID_CFGLocaleDisp_36_114')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079411,0,'busevent','PID_CFGLocaleDisp_36_115')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079412,0,'alert','PID_CFGLocaleDisp_36_116')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079413,0,'sms','PID_CFGLocaleDisp_36_117')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079414,0,'any','PID_CFGLocaleDisp_36_118')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079415,0,'auxwork','PID_CFGLocaleDisp_36_119')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079416,0,'outbound preview','PID_CFGLocaleDisp_36_120')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079417,0,'training item','PID_CFGLocaleDisp_36_121')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079418,0,'smssession','PID_CFGLocaleDisp_36_122')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079419,0,'mms','PID_CFGLocaleDisp_36_123')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079420,0,'mmssession','PID_CFGLocaleDisp_36_124')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079496,0,'default','PID_CFGLocaleDisp_36_200')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079596,0,'default','PID_CFGLocaleDisp_36_300')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079646,0,'unknown','PID_CFGLocaleDisp_36_350')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079649,0,'unknown','PID_CFGLocaleDisp_36_353')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079696,0,'Inbound','PID_CFGLocaleDisp_36_400')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079697,0,'Outbound','PID_CFGLocaleDisp_36_401')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079698,0,'Internal','PID_CFGLocaleDisp_36_402')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079699,0,'Inbound New','PID_CFGLocaleDisp_36_403')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079700,0,'Customer Reply','PID_CFGLocaleDisp_36_404')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079701,0,'Inbound Collaboration Reply','PID_CFGLocaleDisp_36_405')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079702,0,'NDR','PID_CFGLocaleDisp_36_406')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079703,0,'Outbound New','PID_CFGLocaleDisp_36_407')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079704,0,'Reply','PID_CFGLocaleDisp_36_408')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079705,0,'Acknowledgement','PID_CFGLocaleDisp_36_409')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079706,0,'Auto Response','PID_CFGLocaleDisp_36_410')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079707,0,'Redirect','PID_CFGLocaleDisp_36_411')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079708,0,'Outbound Collaboration Invite','PID_CFGLocaleDisp_36_412')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079709,0,'Internal Collaboration Invite','PID_CFGLocaleDisp_36_413')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079710,0,'Internal Collaboration Reply','PID_CFGLocaleDisp_36_414')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079711,0,'Normal','PID_CFGLocaleDisp_36_415')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079712,0,'Auto Responded','PID_CFGLocaleDisp_36_416')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079713,0,'Terminated','PID_CFGLocaleDisp_36_417')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079714,0,'Sent','PID_CFGLocaleDisp_36_418')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079715,0,'Forwarded','PID_CFGLocaleDisp_36_419')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079716,0,'Re-directed','PID_CFGLocaleDisp_36_420')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079717,0,'English','PID_CFGLocaleDisp_36_421')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079718,0,'Priority','PID_CFGLocaleDisp_36_422')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079719,0,'Category','PID_CFGLocaleDisp_36_423')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079720,0,'Service Type','PID_CFGLocaleDisp_36_424')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079721,0,'Media Type','PID_CFGLocaleDisp_36_425')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079722,0,'Interaction Type','PID_CFGLocaleDisp_36_426')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079723,0,'Interaction Subtype','PID_CFGLocaleDisp_36_427')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079724,0,'Language','PID_CFGLocaleDisp_36_428')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079725,0,'StopProcessing Reason','PID_CFGLocaleDisp_36_429')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079726,0,'Disposition Code','PID_CFGLocaleDisp_36_430')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079727,0,'Reason Code','PID_CFGLocaleDisp_36_431')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079728,0,'First Name','PID_CFGLocaleDisp_36_432')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079729,0,'Last Name','PID_CFGLocaleDisp_36_433')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079730,0,'Title','PID_CFGLocaleDisp_36_434')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079731,0,'E-mail Address','PID_CFGLocaleDisp_36_435')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079732,0,'Phone Number','PID_CFGLocaleDisp_36_436')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079733,0,'Account Number','PID_CFGLocaleDisp_36_437')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079734,0,'Contact ID','PID_CFGLocaleDisp_36_438')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079735,0,'Customer Segment','PID_CFGLocaleDisp_36_439')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079736,0,'PIN','PID_CFGLocaleDisp_36_440')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079737,0,'OutboundNotification','PID_CFGLocaleDisp_36_441')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079738,0,'Inbound Report','PID_CFGLocaleDisp_36_442')

INSERT INTO cfg_locale VALUES(1033,8,70,1313079739,0,'Inbound Disposition','PID_CFGLocaleDisp_36_443')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079708,0,'Outbound Collaboration Invite','PID_CFGLocaleDisp_36_412')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079709,0,'Internal Collaboration Invite','PID_CFGLocaleDisp_36_413')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079710,0,'Internal Collaboration Reply','PID_CFGLocaleDisp_36_414')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079711,0,'Normal','PID_CFGLocaleDisp_36_415')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079712,0,'Auto Responded','PID_CFGLocaleDisp_36_416')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079713,0,'Terminated','PID_CFGLocaleDisp_36_417')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079714,0,'Sent','PID_CFGLocaleDisp_36_418')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079715,0,'Forwarded','PID_CFGLocaleDisp_36_419')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079716,0,'Re-directed','PID_CFGLocaleDisp_36_420')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079717,0,'English','PID_CFGLocaleDisp_36_421')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079718,0,'Priority','PID_CFGLocaleDisp_36_422')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079719,0,'Category','PID_CFGLocaleDisp_36_423')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079720,0,'Service Type','PID_CFGLocaleDisp_36_424')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079721,0,'Media Type','PID_CFGLocaleDisp_36_425')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079722,0,'Interaction Type','PID_CFGLocaleDisp_36_426')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079723,0,'Interaction Subtype','PID_CFGLocaleDisp_36_427')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079724,0,'Language','PID_CFGLocaleDisp_36_428')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079725,0,'StopProcessing Reason','PID_CFGLocaleDisp_36_429')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079726,0,'Disposition Code','PID_CFGLocaleDisp_36_430')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079727,0,'Reason Code','PID_CFGLocaleDisp_36_431')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079728,0,'First Name','PID_CFGLocaleDisp_36_432')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079729,0,'Last Name','PID_CFGLocaleDisp_36_433')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079730,0,'Title','PID_CFGLocaleDisp_36_434')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079731,0,'E-mail Address','PID_CFGLocaleDisp_36_435')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079732,0,'Phone Number','PID_CFGLocaleDisp_36_436')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079733,0,'Account Number','PID_CFGLocaleDisp_36_437')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079734,0,'Contact ID','PID_CFGLocaleDisp_36_438')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079735,0,'Customer Segment','PID_CFGLocaleDisp_36_439')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079736,0,'PIN','PID_CFGLocaleDisp_36_440')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079737,0,'OutboundNotification','PID_CFGLocaleDisp_36_441')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079738,0,'Inbound Report','PID_CFGLocaleDisp_36_442')

INSERT INTO cfg_locale VALUES(1033,8,71,1313079739,0,'Inbound Disposition','PID_CFGLocaleDisp_36_443')

INSERT INTO cfg_locale VALUES(1033,8,74,0,0,'Success','BOR_NOERROR')

INSERT INTO cfg_locale VALUES(1033,8,74,1,0,'Internal error','BOR_INTERN_ERROR')

INSERT INTO cfg_locale VALUES(1033,8,74,2,0,'Person not found.','BOR_PERSON_NOT_FOUND')

INSERT INTO cfg_locale VALUES(1033,8,74,3,0,'Object with the same DBID already exists','BOR_UNIQUEDBID')

INSERT INTO cfg_locale VALUES(1033,8,74,4,0,'Uniqueness constraint violated','BOR_UNIQUECONSTR')

INSERT INTO cfg_locale VALUES(1033,8,74,5,0,'Required attribute is missing','BOR_REQUIREDATTR')

INSERT INTO cfg_locale VALUES(1033,8,74,6,0,'The value of the attribute is incorrect','BOR_VALUEATTR')

INSERT INTO cfg_locale VALUES(1033,8,74,7,0,'The attribute could not be changed','BOR_UNCHANGEATTR')

INSERT INTO cfg_locale VALUES(1033,8,74,8,0,'The object cannot be changed','BOR_UNCHANGEOBJECT')

INSERT INTO cfg_locale VALUES(1033,8,74,9,0,'The property is not supported in this object','BOR_WRONGPROP')

INSERT INTO cfg_locale VALUES(1033,8,74,10,0,'No permissions to create an object under this Folder','BOR_WRONGFOLDER')

INSERT INTO cfg_locale VALUES(1033,8,74,11,0,'The object can not be changed because of the dependent objects','BOR_UNCHANGEOBJ')

INSERT INTO cfg_locale VALUES(1033,8,74,12,0,'The object can not be removed because of the dependent objects','BOR_UNREMOVEOBJ')

INSERT INTO cfg_locale VALUES(1033,8,74,13,0,'Insufficient permissions to perform this operation','BOR_NOPERMISSIONS')

INSERT INTO cfg_locale VALUES(1033,8,74,14,0,'List element could not be located for this object','BOR_LISTITEM')

INSERT INTO cfg_locale VALUES(1033,8,74,15,0,'Wrong list element property for this object','BOR_WRONGLISTITEM')

INSERT INTO cfg_locale VALUES(1033,8,74,16,0,'Access object not found for this access list','BOR_WRONGACL')

INSERT INTO cfg_locale VALUES(1033,8,74,17,0,'Account object not found','BOR_WRONGACCOUNT')

INSERT INTO cfg_locale VALUES(1033,8,74,18,0,'Object does not satisfy link condition','BOR_LINKCONDITION')

INSERT INTO cfg_locale VALUES(1033,8,74,19,0,'Link is a singular. Can not accomodate additional object','BOR_LINKSINGULARITY')

INSERT INTO cfg_locale VALUES(1033,8,74,20,0,'Link object not found','BOR_LINKNOTFOUND')

INSERT INTO cfg_locale VALUES(1033,8,74,21,0,'Object not found','BOR_OBJNOTFOUND')

INSERT INTO cfg_locale VALUES(1033,8,74,22,0,'Application can not refer to more than Tenant in a Single-Tenant mode','BOR_APPTENANT')

INSERT INTO cfg_locale VALUES(1033,8,74,23,0,'Can not change options at the Primary Server object','BOR_OPTIONCHANGE')

INSERT INTO cfg_locale VALUES(1033,8,74,24,0,'Can not remove Tenant because of the dependent objects','BOR_DELTENANT')

INSERT INTO cfg_locale VALUES(1033,8,74,25,0,'Direct removing object from the Folder prohibited','BOR_DELOBJECTIDS')

INSERT INTO cfg_locale VALUES(1033,8,74,26,0,'Can not change name at running server','BOR_NAMECHANGE')

INSERT INTO cfg_locale VALUES(1033,8,74,27,0,'Can not create a Tenant in Single-Tenant mode','BOR_SINGLETENANT')

INSERT INTO cfg_locale VALUES(1033,8,74,28,0,'Script expression is not valid','BOR_SCRIPTEXPR')

INSERT INTO cfg_locale VALUES(1033,8,74,29,0,'Explicit agents are prohibited when script expression is set','BOR_AGENTSPROHIBITED')

INSERT INTO cfg_locale VALUES(1033,8,74,30,0,'Password length does not satisfied security configuration','BOR_WRONGPASSWORDLENGTH')

INSERT INTO cfg_locale VALUES(1033,8,74,31,0,'Empty password is prohibited','BOR_EMPTY_PASSWORD_DENIED')

INSERT INTO cfg_locale VALUES(1033,8,74,32,0,'At least one ASCII alphabetic character is required','BOR_ALPHABETIC_ABSENCE')

INSERT INTO cfg_locale VALUES(1033,8,74,33,0,'At least one upper and one lower case ASCII character is required','BOR_MIXCASE_ABSENCE')

INSERT INTO cfg_locale VALUES(1033,8,74,34,0,'At least one numeric character is required','BOR_NUMBERS_ABSENCE')

INSERT INTO cfg_locale VALUES(1033,8,74,35,0,'At least one punctuation character is required','BOR_PUNCTUATION_ABSENCE')

INSERT INTO cfg_locale VALUES(1033,8,74,36,0,'Password has expired. Please change password to continue','BOR_PASSWORD_EXPIRED')

INSERT INTO cfg_locale VALUES(1033,8,74,37,0,'This password has been used not long ago','BOR_PASSWORD_NO_REPEATS')

INSERT INTO cfg_locale VALUES(1033,8,74,38,0,'Authentication failed, user name or password is incorrect','BOR_AUTH_FAILED')

INSERT INTO cfg_locale VALUES(1033,8,74,39,0,'Account has been locked out','BOR_ACCOUNT_LOCKED')

INSERT INTO cfg_locale VALUES(1033,8,74,40,0,'Transaction rejected. The configuration server is currently working in read-only mode','BOR_TRANSACTION_REJECTED')

INSERT INTO cfg_locale VALUES(1033,8,74,41,0,'Only supervisor person can change configuration in emergency mode','BOR_ONLYSUPERCANCHANGEPASSWORD')

INSERT INTO cfg_locale VALUES(1033,8,74,42,0,'User not found','BOR_USERNOTFOUND')

INSERT INTO cfg_locale VALUES(1033,8,74,43,0,'User is not allowed to change the password at this account','BOR_USERNOTALLOWCHANGRPASSWOD')

INSERT INTO cfg_locale VALUES(1033,8,74,44,0,'External authentication is enforced. Password change is prohibited','BOR_EXTAUTHPASSWODRCHANGEPRHIBIT')

INSERT INTO cfg_locale VALUES(1033,8,74,45,0,'Password is rejected: ','BOR_PASSWORDREJECTED_')

INSERT INTO cfg_locale VALUES(1033,8,74,46,0,'Old password is not correct','BOR_OLDPASSWORDNOTCORRECT')

INSERT INTO cfg_locale VALUES(1033,8,74,47,0,'account unlocked by administrator','BOR_ACCOUNT_LOCKED_BY_ADMIN')

INSERT INTO cfg_locale VALUES(1033,8,74,48,0,'lockout timer expiry of ','BOR_LOCKOUT_TIMER_EXPIRY_OF')

INSERT INTO cfg_locale VALUES(1033,8,74,49,0,' day','BOR__DAY')

INSERT INTO cfg_locale VALUES(1033,8,74,50,0,' hour','BOR__HOUR')

INSERT INTO cfg_locale VALUES(1033,8,74,51,0,' minutes','BOR__MINUTS')

INSERT INTO cfg_locale VALUES(1033,8,74,52,0,'Password is inconsistent: ','BOR_PSWD_INCONSIST_')

INSERT INTO cfg_locale VALUES(1033,8,74,53,0,'New password is rejected: ','BOR_NEW_PSWD_REJECTED_')

INSERT INTO cfg_locale VALUES(1033,8,74,54,0,'Account has been expired since ','BOR_ACCOUNT_EXPIRED_SINCE_')

INSERT INTO cfg_locale VALUES(1033,8,74,55,0,'will expire ','BOR_WILL_BE_EXPIRED_')

INSERT INTO cfg_locale VALUES(1033,8,74,56,0,'in ','BOR_IN_')

INSERT INTO cfg_locale VALUES(1033,8,74,57,0,'s','BOR_S_PLURAL')

INSERT INTO cfg_locale VALUES(1033,8,74,58,0,'today','BOR_TODAY')

INSERT INTO cfg_locale VALUES(1033,8,74,59,0,'has expired','BOR_HAS_BEING_EXPAIRED')

INSERT INTO cfg_locale VALUES(1033,8,74,60,0,'User must change password','BOR_USER_MUST_CHANGE_PSWD')

INSERT INTO cfg_locale VALUES(1033,8,74,61,0,'expiration time [ in days ] : ','BOR_EXPIRATION_TIME_')

UPDATE cfg_tenant SET address_line3 = '8.5.000.07' where dbid=1

DELETE FROM cfg_parameters WHERE set_id=0 and section='locale_data_version' and opt='1033'

INSERT INTO cfg_parameters(set_id,section,opt,val) VALUES (0, 'locale_data_version','1033', '8.5.000.12')

DELETE FROM cfg_parameters WHERE set_id=0 and section='version' and opt='locale'

INSERT INTO cfg_parameters(set_id,section,opt,val) select 0,'version','locale', address_line3 from cfg_tenant where dbid=1 and address_line3 is not null

