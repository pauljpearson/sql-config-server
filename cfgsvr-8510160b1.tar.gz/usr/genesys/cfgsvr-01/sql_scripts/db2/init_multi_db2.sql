echo '* Version: 8.5.000.07 *'

echo '***NOTE: LOAD CfgLocale_db2.sql AFTER THE init_multi_db2.sql***'


create table cfg_group( \
    dbid numeric(10,0) not null, \
    group_type int, \
    tenant_dbid numeric(10,0), \    
    name varchar(254), \
    cap_table_dbid numeric(10,0), \
    quota_table_dbid numeric(10,0), \
    state int, \
    dn_group_type int, \        
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    cap_table_csid numeric(10,0), \
    quota_table_csid numeric(10,0), \
    capacity_dbid numeric(10,0), \
    site_dbid numeric(10,0), \
    contract_dbid numeric(10,0), \
    PRIMARY KEY(dbid) \
    )


create table cfg_agent_group ( \
    group_dbid numeric(10,0) not null, \
    agent_dbid numeric(10,0) not null, \
    group_csid numeric(10,0), \
    agent_csid numeric(10,0), \
    PRIMARY KEY(group_dbid,agent_dbid) \
      )


create table cfg_group_manager( \
      group_dbid numeric(10,0) not null, \
    manager_dbid numeric(10,0) not null, \
    group_csid numeric(10,0), \
    manager_csid numeric(10,0), \
    PRIMARY KEY(group_dbid,manager_dbid) \
      )



create table cfg_place_group( \
    group_dbid numeric(10,0) not null, \
    place_dbid numeric(10,0) not null, \
    group_csid numeric(10,0), \
    place_csid numeric(10,0), \
    PRIMARY KEY(group_dbid,place_dbid) \
    )
 

create table cfg_group_route_dn( \
      group_dbid numeric(10,0) not null, \
      route_dn_dbid numeric(10,0) not null, \
    group_csid numeric(10,0), \
    route_dn_csid numeric(10,0), \
    PRIMARY KEY(group_dbid,route_dn_dbid) \
    )


create table cfg_dn_group( \
    group_dbid numeric(10,0) not null, \
    dn_dbid numeric(10,0) not null, \
    trunks int, \
    group_csid numeric(10,0), \
    dn_csid numeric(10,0), \
    PRIMARY KEY(group_dbid,dn_dbid) \
    )


create table cfg_host( \
      dbid numeric(10,0) not null, \
      name varchar(254), \
      hwid varchar(64), \
      ip_address varchar(64), \
      os_type int, \
      os_version varchar(64), \
      type int, \
      address_line1 varchar(64), \
      address_line2 varchar(64), \
      address_line3 varchar(64), \
      address_line4 varchar(64), \
      address_line5 varchar(64), \
      cont_person_dbid numeric(10,0), \
      comment_ varchar(254), \
    state int, \
    csid numeric(10,0), \
    cont_person_csid numeric(10,0), \
    lca_port varchar(254), \
    scs_dbid  numeric(10,0), \
    PRIMARY KEY(dbid) \
    )


create table cfg_application( \
    dbid numeric(10,0) not null, \
      name varchar(254), \
    password varchar(64), \
    type int, \
    version varchar(254), \
    is_server int, \
    state int, \
      app_prototype_dbid numeric(10,0), \
    csid numeric(10,0), \
    app_prototype_csid numeric(10,0), \
    work_directory varchar(254), \
    command_line varchar(254), \
    auto_restart int, \
    startup_timeout int, \
    shutdown_timeout int, \
    redundancy_type int, \
    is_primary int, \
    cmd_line_args varchar(254), \
        component_type int, \
    PRIMARY KEY(dbid) \
    ) 
 

create table cfg_server( \
    app_dbid numeric(10,0) not null, \
    host_dbid numeric(10,0), \
    port varchar(254), \
    back_server_dbid numeric(10,0), \
      timeout int, \
    attempts int, \
    app_csid numeric(10,0), \
    host_csid numeric(10,0), \
    back_server_csid numeric(10,0), \
    account_dbid numeric(10,0), \
    account_csid numeric(10,0), \
    account_type int, \
    PRIMARY KEY(app_dbid) \
    ) 


create table cfg_app_server( \
    app_dbid numeric(10,0) not null, \
    app_server_dbid numeric(10,0) not null, \
    app_csid numeric(10,0), \
    app_server_csid numeric(10,0), \
    conn_protocol varchar(254), \
    timout_local numeric(10,0), \
    timout_remote numeric(10,0), \
    mode_ int, \
    id varchar(64), \
    transport_params varchar(254), \
    app_params varchar(254), \
    proxy_params varchar(254), \
    description varchar(254), \
    char_field_1 varchar(254), \
    char_field_2 varchar(254), \
    char_field_3 varchar(254), \
    char_field_4 varchar(254), \
    long_field_1 numeric(10,0), \
    long_field_2 numeric(10,0), \
    long_field_3 numeric(10,0), \
    long_field_4 numeric(10,0), \
    PRIMARY KEY(app_dbid,app_server_dbid) \
    ) 
 

create table cfg_app_option( \
    object_dbid numeric(10,0) not null, \
      object_type int not null, \
    section varchar(64) not null, \
    opt varchar(64) not null, \
    val varchar(254), \
    object_csid numeric(10,0), \
    part int not null, \
    PRIMARY KEY(object_dbid,object_type,section,opt,part) \
    ) 
 

create table cfg_app_tenant( \
      app_dbid numeric(10,0) not null, \
      tenant_dbid numeric(10,0) not null, \
    app_csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    PRIMARY KEY(app_dbid,tenant_dbid) \
    ) 


create table cfg_port_info( \
    app_dbid numeric(10,0) not null, \
    id varchar(64) not null, \
    port varchar(254), \
    transport_params varchar(254), \
    conn_protocol varchar(254), \
    app_params varchar(254), \
    description  varchar(254), \
    char_field_1 varchar(254), \
    char_field_2 varchar(254), \
    char_field_3 varchar(254), \
    char_field_4 varchar(254), \
    long_field_1 numeric(10,0), \
    long_field_2 numeric(10,0), \
    long_field_3 numeric(10,0), \
    long_field_4 numeric(10,0), \
    PRIMARY KEY(app_dbid,id) \
    )


create table cfg_app_prototype( \
    dbid numeric(10,0) not null, \
    name varchar(254), \
    type int, \
    version varchar(254), \
    state int, \
    csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_person ( \
    dbid numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    last_name varchar(64), \
    first_name varchar(64), \
    address_line1 varchar(64), \
      address_line2 varchar(64), \
      address_line3 varchar(64), \
      address_line4 varchar(64), \
      address_line5 varchar(255), \
    office varchar(64), \
      home varchar(64), \
      mobile varchar(64), \
      pager varchar(64), \
      fax varchar(64), \
      modem varchar(64), \
      phones_comment varchar(64), \
      birthdate varchar(64), \
    comment_ varchar(254), \
    employee_id varchar(255), \
    user_name varchar(254), \
    password varchar(64), \
    is_agent int, \
    is_admin int, \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    place_dbid numeric(10,0), \
    place_csid numeric(10,0), \
    capacity_dbid numeric(10,0), \  
    site_dbid numeric(10,0), \  
    contract_dbid numeric(10,0), \      
    salted_string varchar(255), \
    ch_pass_on_login int, \
    pass_updating int, \
    pass_hash_alg int, \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_password_history( \
    person_dbid numeric(10,0) not null, \
    password varchar(64) not null, \
    salted_string varchar(255), \
    hash_type int not null, \
    update_date int not null, \
    PRIMARY KEY(person_dbid, password) \
    )


create table cfg_app_rank( \
    person_dbid numeric(10,0) not null, \
    app_type int not null, \
    app_rank int, \
    person_csid numeric(10,0), \
    PRIMARY KEY(person_dbid,app_type) \
    ) 


create table cfg_login_info( \
    person_dbid numeric(10,0) not null, \
    agent_login_dbid numeric(10,0) not null, \
    wrapup_time int, \
    person_csid numeric(10,0), \
    agent_login_csid numeric(10,0), \
    PRIMARY KEY(person_dbid,agent_login_dbid) \
    ) 


create table cfg_skill_level( \
      person_dbid numeric(10,0) not null, \
      skill_dbid numeric(10,0) not null, \
      level_ int, \
    person_csid numeric(10,0), \
    skill_csid numeric(10,0), \
    PRIMARY KEY(person_dbid,skill_dbid) \
    ) 


create table cfg_skill( \
      dbid numeric(10,0) not null, \
      name varchar(254), \
      tenant_dbid numeric(10,0), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_place( \
      dbid numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    name varchar(254), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    capacity_dbid numeric(10,0), \
    site_dbid numeric(10,0), \
    contract_dbid numeric(10,0), \  
    PRIMARY KEY(dbid) \
    ) 


create table cfg_service( \
    dbid numeric(10,0) not null, \
    name varchar(254), \
    abbr varchar(64), \
    type int, \
    state int, \
    csid numeric(10,0), \
    solution_type int, \
    scs_dbid numeric(10,0), \
    tenant_dbid numeric(10,0), \
    version varchar(254), \
    scs_csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_app_service( \
    service_dbid numeric(10,0) not null, \
    app_type int not null, \
    permission_mask int, \
    service_csid numeric(10,0), \
    PRIMARY KEY(service_dbid,app_type) \
    ) 


create table cfg_phys_switch( \
    dbid numeric(10,0) not null, \
    name varchar(254), \
    type int, \
    address_line1 varchar(64), \
      address_line2 varchar(64), \
      address_line3 varchar(64), \
      address_line4 varchar(64), \
      address_line5 varchar(64), \
    cont_person_dbid numeric(10,0), \
    state int, \
    csid numeric(10,0), \
    cont_person_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_switch( \
      dbid numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    phys_switch_dbid numeric(10,0), \
    type int, \
    name varchar(254), \
    tserver_dbid numeric(10,0), \
    link_type int, \
    dn_range varchar(254), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    phys_switch_csid numeric(10,0), \
    tserver_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 
 

create table cfg_switch_access( \
      from_switch_dbid numeric(10,0) not null, \
      to_switch_dbid numeric(10,0) not null, \
      access_code varchar(128) not null, \
    target_type int not null, \
    route_type int, \
    dn_source varchar(254), \
    dest_source varchar(254), \
    location_source varchar(254), \
    dnis_source varchar(254), \
    reason_source varchar(254), \
    extension_source varchar(254), \
    from_switch_csid numeric(10,0), \
    to_switch_csid numeric(10,0), \
    PRIMARY KEY(from_switch_dbid,to_switch_dbid,access_code,target_type) \
    ) 


create table cfg_agent_login( \
      dbid numeric(10,0) not null, \
      switch_dbid numeric(10,0), \
    tenant_dbid numeric(10,0), \
      login_code varchar(254), \
    state int, \
    override varchar(254), \
    use_override int, \
    sw_specific_type int, \
    csid numeric(10,0), \
    switch_csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    password varchar(64), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_dn( \
      dbid numeric(10,0) not null, \
    switch_dbid numeric(10,0), \
      tenant_dbid numeric(10,0), \
    type int, \
    number_ varchar(254), \
    association varchar(254), \
    login_flag int, \
    dn_login_id varchar(254), \
    register_all int, \
    group_dbid numeric(10,0), \
    trunks int, \
    route_type int, \
    override varchar(254), \
    state int, \
      name varchar(254), \
    use_override int, \
    sw_specific_type int, \
    csid numeric(10,0), \
    switch_csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    group_csid numeric(10,0), \
    place_dbid numeric(10,0), \
    place_csid numeric(10,0), \
    site_dbid numeric(10,0), \
    contract_dbid numeric(10,0), \  
    PRIMARY KEY(dbid) \
    ) 


create table cfg_dest_dn( \
      dn_dbid numeric(10,0) not null, \
      dest_dn_dbid numeric(10,0) not null, \
    dn_csid numeric(10,0), \
    dest_dn_csid numeric(10,0), \
    PRIMARY KEY(dn_dbid,dest_dn_dbid) \
    ) 


create table cfg_tenant( \
    dbid numeric(10,0) not null, \
      is_serv_provider int, \
    name varchar(254), \
    password varchar(64), \
    address_line1 varchar(64), \
      address_line2 varchar(64), \
      address_line3 varchar(254), \
      address_line4 varchar(64), \
      address_line5 varchar(64), \
      chargeable_number varchar(64), \
      tenant_person_dbid numeric(10,0), \
      parent_tenant_dbid numeric(10,0), \
    provid_person_dbid numeric(10,0), \
    is_super_tenant int, \
    state int, \
    csid numeric(10,0), \
    tenant_person_csid numeric(10,0), \
    provid_person_csid numeric(10,0), \
    capacity_dbid numeric(10,0), \
    contract_dbid numeric(10,0), \  
    PRIMARY KEY(dbid) \
    ) 
 

create table cfg_service_info( \
    tenant_dbid numeric(10,0) not null, \
    service_dbid numeric(10,0) not null, \
    is_chargeable int, \
    tenant_csid numeric(10,0), \
    service_csid numeric(10,0), \
    PRIMARY KEY(tenant_dbid,service_dbid) \
    ) 


create table cfg_action_code( \
    dbid numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
      name varchar(254), \
    type int, \
    code varchar(254), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_subcode( \
      action_code_dbid numeric(10,0) not null, \
    name varchar(128) not null, \
    code varchar(254), \
    action_code_csid numeric(10,0), \
    PRIMARY KEY(action_code_dbid,name) \
    ) 


create table cfg_script( \
    dbid numeric(10,0) not null, \
    name varchar(254), \
    tenant_dbid numeric(10,0), \
    index_ int, \
    type int, \
    cont_person_dbid numeric(10,0), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    cont_person_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    )


create table cfg_transaction( \
    dbid numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    name varchar(254), \
    type int, \
    record_period int, \
    alias varchar(254), \
    description varchar(254), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_stat_table( \
    dbid numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    name varchar(254), \
    type int, \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    wait_threshold int, \
    use_flat_rate int, \    
    flat_rate int, \
    agent_rate int, \   
    PRIMARY KEY(dbid) \
    ) 


create table cfg_stat_day( \
    dbid numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    name varchar(254), \
    is_day_of_week int, \
    day int, \
    start_time int, \
    end_time int, \
    min_value int, \
    max_value int, \
    target_value int, \
    interval_length int, \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    date_ int, \
    type int, \
    use_flat_rate int, \
    flat_rate int, \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_stat_interval( \
    stat_day_dbid numeric(10,0) not null, \
    interval_count int not null, \
    stat_value1 int, \
    stat_value2 int, \
    stat_value3 int, \
    stat_value4 int, \
    stat_day_csid numeric(10,0), \
    PRIMARY KEY(stat_day_dbid,interval_count) \
    ) 


create table cfg_table_day( \
    stat_table_dbid numeric(10,0) not null, \
    stat_day_dbid numeric(10,0) not null, \
    stat_table_csid numeric(10,0), \
    stat_day_csid numeric(10,0), \
    PRIMARY KEY(stat_table_dbid,stat_day_dbid) \
    ) 


create table cfg_access_group( \
    group_dbid numeric(10,0) not null, \
    member_dbid numeric(10,0) not null, \
    member_type int not null, \
    group_csid numeric(10,0), \
    member_csid numeric(10,0), \
    PRIMARY KEY(group_dbid,member_dbid,member_type) \
    ) 


create table cfg_ace( \
    user_dbid numeric(10,0) not null, \
    user_type int not null, \
    object_dbid numeric(10,0) not null, \
    object_type int not null, \
    access_mask int, \
    user_csid numeric(10,0), \
    object_csid numeric(10,0), \
    PRIMARY KEY(object_type,object_dbid,user_dbid,user_type) \
    ) 

CREATE INDEX cfg_ace_objDBID ON cfg_ace (object_dbid)


create table cfg_folder( \
    dbid numeric(10,0) not null, \
    name varchar(254), \
    type int, \
    owner_dbid numeric(10,0), \
    owner_type int, \
    state int, \
    csid numeric(10,0), \
    owner_csid numeric(10,0), \
    description varchar(254), \
    folder_class int, \
    custom_type int, \  
    PRIMARY KEY(dbid) \
    ) 


create table cfg_notify( \
    dbid numeric(10,0) not null, \
    stamped_time numeric(10,0), \
    user_name varchar(254), \
    event_type int, \
    object_type int, \
    tenant_dbid numeric(10,0), \
    object_dbid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_refresh( \
    refresh int not null, \
    notify_id int not null \
    ) 


create table cfg_max_dbid( \
    object_type int not null, \
    max_dbid numeric(10,0) not null, \
    PRIMARY KEY(object_type,max_dbid) \
    ) 


create table cfg_access_number( \
    dn_dbid numeric(10,0) not null, \
    from_switch_dbid numeric(10,0) not null, \
    number_ varchar(128) not null, \
    dn_csid numeric(10,0), \
    from_switch_csid numeric(10,0), \
    PRIMARY KEY(dn_dbid,from_switch_dbid,number_) \
    ) 


create table cfg_field( \
    dbid numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    name varchar(254), \
    type int, \
    description varchar(254), \
    length int, \
    field_type int, \
    default_value varchar(254), \
    is_primary_key int, \
    is_unique int, \
    is_nullable int, \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_format( \
    dbid numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \    
    name varchar(254), \
    description varchar(254), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_format_field( \
    format_dbid numeric(10,0) not null, \ 
    field_dbid numeric(10,0) not null, \
    format_csid numeric(10,0), \
    field_csid numeric(10,0), \
    PRIMARY KEY(format_dbid,field_dbid) \
    ) 


create table cfg_table_access( \
    dbid numeric(10,0) not null, \ 
    tenant_dbid numeric(10,0), \ 
    name varchar(254), \ 
    type int, \
    description varchar(254), \
    db_access_dbid numeric(10,0), \
    format_dbid numeric(10,0), \
    db_table_name varchar(254), \
    is_cachable int, \
    update_timeout int, \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    db_access_csid numeric(10,0), \
    format_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 
 

create table cfg_calling_list( \
        dbid numeric(10,0) not null, \ 
    tenant_dbid numeric(10,0), \ 
    name varchar(254), \
    description varchar(254), \
    tabl_acc_dbid numeric(10,0), \ 
    filter_dbid numeric(10,0), \
    log_tabl_acc_dbid int, \
    time_from int, \
    time_until int, \
    max_attempts int, \
    script_dbid numeric(10,0), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    tabl_acc_csid numeric(10,0), \
    filter_csid numeric(10,0), \
    log_tabl_acc_csid numeric(10,0), \
    script_csid numeric(10,0), \  
    PRIMARY KEY(dbid) \
    ) 


create table cfg_call_list_trtm( \
    calling_list_dbid numeric(10,0) not null, \
    treatment_dbid numeric(10,0) not null, \
    calling_list_csid numeric(10,0), \
    treatment_csid numeric(10,0), \
    PRIMARY KEY(calling_list_dbid,treatment_dbid) \
    ) 


create table cfg_call_list_info( \
    campaign_dbid numeric(10,0) not null, \
    calling_list_dbid numeric(10,0) not null, \
    share_ int, \
    is_active int, \
    campaign_csid numeric(10,0), \
    calling_list_csid numeric(10,0), \
    PRIMARY KEY(campaign_dbid,calling_list_dbid) \
    ) 


create table cfg_campaign( \ 
    dbid numeric(10,0) not null, \ 
    tenant_dbid numeric(10,0), \ 
    name varchar(254), \ 
    description varchar(254), \
    script_dbid numeric(10,0), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    script_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 
 

create table cfg_treatment( \
        dbid numeric(10,0) not null, \ 
        tenant_dbid numeric(10,0), \ 
    name varchar(254), \ 
    description varchar(254), \
    call_result int, \
    rec_action_code int, \
    attempts int, \
    date_time int, \
    cycle_attempt int, \
    interval_ int, \
    increment_ int, \ 
    call_action_code int, \
    dest_dn_dbid numeric(10,0), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    dest_dn_csid numeric(10,0), \
    range int, \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_filter( \
    dbid numeric(10,0) not null, \ 
    tenant_dbid numeric(10,0), \ 
    name varchar(254), \ 
    description varchar(254), \ 
    format_dbid numeric(10,0), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    format_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_time_zone( \
        dbid numeric(10,0) not null, \ 
        tenant_dbid numeric(10,0), \
    name varchar(254), \ 
        description varchar(254), \ 
        offset int, \ 
        is_dst_observed int, \ 
        dst_start_date int, \
        dst_stop_date int, \
    name_netscape varchar(254), \
    name_msexplorer varchar(254), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    dst_offset int, \
    PRIMARY KEY(dbid) \
    ) 
 

create table cfg_voice_prompt( \
    dbid numeric(10,0) not null, \
    switch_dbid numeric(10,0), \
    tenant_dbid numeric(10,0), \
    name varchar(254), \
    description varchar(254), \
    script_dbid numeric(10,0), \
    state int, \
    csid numeric(10,0), \
    switch_csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    script_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_flex_prop( \
    dbid numeric(10,0) not null, \
    object_dbid numeric(10,0), \
    object_type int, \
    parent_dbid numeric(10,0), \
    prop_name varchar(254), \
    prop_value varchar(254), \
    prop_type int, \
    part int not null, \
    csid numeric(10,0), \
    object_csid numeric(10,0), \
    parent_csid numeric(10,0), \
    PRIMARY KEY(dbid,part) \
    ) 

CREATE INDEX cfg_flex_p_objDBID ON cfg_flex_prop (object_dbid)


create table cfg_ivr_port( \
    dbid numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    port_number varchar(254), \
    description varchar(254), \
    ivr_dbid numeric(10,0), \
    dn_dbid numeric(10,0), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    ivr_csid numeric(10,0), \
    dn_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_ivr( \
    dbid numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    name varchar(254), \
    description varchar(254), \
    ivr_type int, \
    version varchar(254), \
    ivr_server_dbid numeric(10,0), \
    state int, \
    csid numeric(10,0), \
    tenant_csid numeric(10,0), \
    ivr_server_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_solution_comp( \
    solution_dbid numeric(10,0) not null, \
    app_dbid numeric(10,0) not null, \
    startup_priority int, \
    is_optional int, \
    solution_csid numeric(10,0), \
    app_csid numeric(10,0), \
    PRIMARY KEY(solution_dbid,app_dbid) \
    ) 


create table cfg_sol_comp_def( \
    solution_dbid numeric(10,0) not null, \
    app_type int not null, \
    app_version varchar(64) not null, \
    startup_priority int, \
    is_optional int, \
    solution_csid numeric(10,0), \
    PRIMARY KEY(solution_dbid,app_type,app_version) \
    ) 


create table cfg_alarm_condtn( \
    dbid numeric(10,0) not null, \
    name varchar(254), \
    description varchar(254), \
    category int, \
    script_dbid numeric(10,0), \
    clearance_timeout int, \
    is_masked int, \
    state int, \
    csid numeric(10,0), \
    script_csid numeric(10,0), \
    PRIMARY KEY(dbid) \
    ) 


create table cfg_alarm_script( \
    alarm_dbid numeric(10,0) not null, \
    script_dbid numeric(10,0) not null, \
    alarm_csid numeric(10,0), \
    script_csid numeric(10,0), \
    PRIMARY KEY(alarm_dbid,script_dbid) \
    ) 


create table cfg_log_event( \
    alarm_dbid numeric(10,0) not null, \
    log_event_id numeric(10,0), \
    event_type int not null, \
    selection_mode int, \
    app_type int, \
    app_dbid numeric(10,0), \
    alarm_csid numeric(10,0), \
    app_csid numeric(10,0), \
    PRIMARY KEY(alarm_dbid,event_type) \
    ) 


create table cfg_obj_folder( \
    folder_dbid numeric(10,0) not null, \
    folder_type int not null, \
    object_dbid numeric(10,0) not null, \
    object_type int not null, \
    folder_csid numeric(10,0), \
    object_csid numeric(10,0), \
    PRIMARY KEY(folder_dbid,folder_type,object_dbid,object_type) \
    ) 
 

create table cfg_locale( \
    lcid numeric(10,0) not null, \
    lc_class int not null, \
      lc_type int not null, \
      lc_subtype int not null, \
      lc_instance_id numeric(10,0) not null, \
      lc_value varchar(254), \
    lc_description varchar(254), \
    PRIMARY KEY(lcid,lc_class,lc_type,lc_subtype,lc_instance_id) \
    ) 

INSERT INTO cfg_tenant VALUES(1,2,'Environment','',NULL,NULL,NULL,NULL,'8.5.000.07',NULL,0,0,0,1,1,0,0,0,0,0)

INSERT INTO cfg_application VALUES(100,'default','55506262552D4A0B',19,'8.5',1,1,100,0,0,'./','default',2,90,90,1,2,NULL,0)

INSERT INTO cfg_application VALUES(99,'confserv','55506262552D4A0B',21,'8.5',2,1,99,0,0,'./','confserv',2,90,90,1,2,NULL,0)

INSERT INTO cfg_application VALUES(101,'ITCUtility','55506262552D4A0B',53,'8.5',1,1,0,0,0,'./','ITCUtility',2,10,10,1,2,NULL,0)

INSERT INTO cfg_application VALUES(102,'Genesys Administrator',NULL,165,'8.5',1,1,101,0,0,NULL,NULL,1,90,90,1,0,NULL,0)

INSERT INTO cfg_application VALUES(103,'Genesys Administrator Server',NULL,184,'8.5',2,1,102,0,0,'./','./',1,90,90,1,0,NULL,0)

INSERT INTO cfg_app_prototype VALUES(100,'Configuration_Manager_8',19,'8.5',1,0)

INSERT INTO cfg_app_prototype VALUES(99,'Configuration_Server_8',21,'8.5',1,0)

INSERT INTO cfg_app_prototype VALUES(101,'Genesys_Administrator_8',165,'8.5',1,0)

INSERT INTO cfg_app_prototype VALUES(102,'Genesys_Administrator_Server_8',184,'8.5',1,0)

INSERT INTO cfg_server VALUES(99,0,'2020',0,0,1,0,0,0,100,0,3)

INSERT INTO cfg_server VALUES(103,0,'3030',0,10,1,0,0,0,100,0,3)

INSERT INTO cfg_port_info VALUES(99,'default','2020',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0)
 
INSERT INTO cfg_person VALUES(100,1,'default','default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','default','5F4DCC3B5AA765D61D8327DEB882CF99',1,1,1,0,0,0,0,0,0,0,NULL,1,NULL,0)

INSERT INTO cfg_refresh VALUES(0,0) 

INSERT INTO cfg_max_dbid VALUES(0,100) 

INSERT INTO cfg_max_dbid VALUES(1,100) 

INSERT INTO cfg_max_dbid VALUES(2,100) 

INSERT INTO cfg_max_dbid VALUES(3,100) 

INSERT INTO cfg_max_dbid VALUES(4,100) 

INSERT INTO cfg_max_dbid VALUES(5,103) 

INSERT INTO cfg_max_dbid VALUES(7,100) 

INSERT INTO cfg_max_dbid VALUES(8,100) 

INSERT INTO cfg_max_dbid VALUES(9,103) 

INSERT INTO cfg_max_dbid VALUES(10,100) 

INSERT INTO cfg_max_dbid VALUES(11,100) 

INSERT INTO cfg_max_dbid VALUES(12,100) 

INSERT INTO cfg_max_dbid VALUES(13,100) 

INSERT INTO cfg_max_dbid VALUES(14,100) 

INSERT INTO cfg_max_dbid VALUES(15,100) 

INSERT INTO cfg_max_dbid VALUES(16,100) 

INSERT INTO cfg_max_dbid VALUES(18,100) 

INSERT INTO cfg_max_dbid VALUES(19,100) 

INSERT INTO cfg_max_dbid VALUES(20,102) 

INSERT INTO cfg_max_dbid VALUES(22,131) 

INSERT INTO cfg_max_dbid VALUES(23,120) 

INSERT INTO cfg_max_dbid VALUES(24,102) 

INSERT INTO cfg_max_dbid VALUES(25,100) 

INSERT INTO cfg_max_dbid VALUES(26,100) 

INSERT INTO cfg_max_dbid VALUES(27,100) 

INSERT INTO cfg_max_dbid VALUES(28,100) 

INSERT INTO cfg_max_dbid VALUES(29,100) 

INSERT INTO cfg_max_dbid VALUES(30,133) 

INSERT INTO cfg_max_dbid VALUES(31,100)  

INSERT INTO cfg_max_dbid VALUES(32,100) 

INSERT INTO cfg_max_dbid VALUES(33,100) 

INSERT INTO cfg_max_dbid VALUES(34,105) 


echo '***creating security groups***'

INSERT INTO cfg_group VALUES(101,4,1,'Super Administrators',0,0,1,4,0,0,0,0,0,0,0)

INSERT INTO cfg_group VALUES(102,4,1,'Administrators',0,0,1,3,0,0,0,0,0,0,0)

INSERT INTO cfg_group VALUES(103,4,1,'Users',0,0,1,2,0,0,0,0,0,0,0)


echo '***creating folders***'

INSERT INTO cfg_folder VALUES(101,'Application Templates',20,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(102,'Applications',9,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(103,'Hosts',10,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(104,'Switching Offices',11,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(105,'Persons',3,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(106,'Place Groups',6,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(107,'Solutions',8,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(108,'Switches',1,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(109,'Access Groups',21,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(110,'Places',4,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(111,'Agent Groups',5,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(112,'DN Groups',17,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(113,'Skills',13,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(114,'Scripts',12,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(115,'Action Codes',14,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(116,'Transactions',16,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(117,'Statistical Days',18,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(118,'Statistical Tables',19,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(119,'Configuration',7,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(120,'Fields',23,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(121,'Formats',24,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(122,'Table Access',25,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(123,'Calling Lists',26,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(124,'Campaigns',27,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(125,'Treatments',28,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(126,'Filters',29,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(127,'Time Zones',30,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(128,'Voice Prompts',31,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(129,'IVRs',33,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(130,'Alarm Conditions',34,1,7,1,0,0,NULL,1,0)

echo '***SuperAdministrators group for default appl/templ and all security group***'

INSERT INTO cfg_ace VALUES(101,21,100,9,127,0,0) 

INSERT INTO cfg_ace VALUES(101,21,100,20,127,0,0) 

INSERT INTO cfg_ace VALUES(101,21,102,21,127,0,0) 

INSERT INTO cfg_ace VALUES(101,21,103,21,127,0,0) 

INSERT INTO cfg_ace VALUES(101,21,101,21,127,0,0) 

INSERT INTO cfg_ace VALUES(101,21,101,9,127,0,0) 

INSERT INTO cfg_ace VALUES(101,21,99,9,127,0,0) 

INSERT INTO cfg_ace VALUES(101,21,99,20,127,0,0) 


echo '***Administrators group for default appl/templ and security groups***'

INSERT INTO cfg_ace VALUES(102,21,100,9,127,0,0) 

INSERT INTO cfg_ace VALUES(102,21,100,20,127,0,0) 

INSERT INTO cfg_ace VALUES(102,21,102,21,5,0,0) 

INSERT INTO cfg_ace VALUES(102,21,103,21,5,0,0) 


echo '***SYSTEM for default applications***'

INSERT INTO cfg_ace VALUES(98,21,100,9,9,0,0) 

INSERT INTO cfg_ace VALUES(98,21,100,20,9,0,0) 

INSERT INTO cfg_ace VALUES(98,21,99,9,1,0,0) 

INSERT INTO cfg_ace VALUES(98,21,99,20,1,0,0) 



echo '***SYSTEM for all folders***'

INSERT INTO cfg_ace \
SELECT 98,21,dbid,22,9,0,0 \
FROM cfg_folder \
WHERE dbid <> 109 


echo '***SuperAdmin group for folders***'

INSERT INTO cfg_ace \
SELECT 101,21,dbid,22,127,0,0 \
FROM cfg_folder 


echo '***Administrators for folders***'

INSERT INTO cfg_ace \
SELECT 102,21,dbid,22,127,0,0 \
FROM cfg_folder \
WHERE dbid <> 119 


echo '***Users for folders***'

INSERT INTO cfg_ace \
SELECT 103,21,dbid,22,9,0,0 \
FROM cfg_folder \
WHERE dbid <> 109 \ 
AND dbid <> 119 


echo '***SuperAdministrators group for ServiceProvider***'

INSERT INTO cfg_ace VALUES(101,21,1,7,127,0,0) 


echo '***SYSTEM for ServiceProvider***'

INSERT INTO cfg_ace VALUES(98,21,1,7,9,0,0) 


echo '***Administrators for ServiceProvider***'

INSERT INTO cfg_ace VALUES(102,21,1,7,127,0,0) 


echo '***Users for ServiceProvider/default app/templ***'

INSERT INTO cfg_ace VALUES(103,21,1,7,9,0,0) 

INSERT INTO cfg_ace VALUES(103,21,100,9,9,0,0) 

INSERT INTO cfg_ace VALUES(103,21,100,20,9,0,0) 



echo '* Default Fields *'

INSERT INTO cfg_field VALUES(101,1,'record_id',         1,'Unique record identifier',                                                               0,  1,NULL,     1,2,1,  1,0,0)

INSERT INTO cfg_field VALUES(102,1,'phone',             4,'Phone number to dial',                                                                   64, 2,NULL,     2,1,1,  1,0,0)

INSERT INTO cfg_field VALUES(103,1,'phone_type',        1,'Phone type',                                                                             0,  24,'1',     2,1,1,  1,0,0)

INSERT INTO cfg_field VALUES(104,1,'record_type',       1,'Record type',                                                                            0,  3,'2',      1,1,1,  1,0,0)

INSERT INTO cfg_field VALUES(105,1,'record_status',     1,'Record status',                                                                          0,  4,'1',      1,1,1,  1,0,0)

INSERT INTO cfg_field VALUES(106,1,'call_result',       1,'Dial result',                                                                            0,  5,'28',     1,1,2,  1,0,0)

INSERT INTO cfg_field VALUES(107,1,'attempt',           1,'Number of attempts has been made,excluding re-dials in case of errors',                  0,  6,'0',      1,1,1,  1,0,0)

INSERT INTO cfg_field VALUES(108,1,'dial_sched_time',   1,'Time when scheduled call must be done,seconds since midnight of 01/01/1970',             0,  7,NULL,     1,1,2,  1,0,0)

INSERT INTO cfg_field VALUES(109,1,'call_time',         1,'Time when last call or dial attempt has been done,seconds since midnight of 01/01/1970', 0,  8,NULL,     1,1,2,  1,0,0)

INSERT INTO cfg_field VALUES(110,1,'daily_from',        1,'Earliest time to perform the call.Seconds from midnight',                                0,  9,'28800',  1,1,1,  1,0,0)

INSERT INTO cfg_field VALUES(111,1,'daily_till',        1,'Latest time to perform the call.Seconds from midnight',                                  0,  10,'64800', 1,1,1,  1,0,0)

INSERT INTO cfg_field VALUES(112,1,'tz_dbid',           1,'Time zone DBID from Configuration Database',                                             0,  11,'122',   1,1,1,  1,0,0)

INSERT INTO cfg_field VALUES(113,1,'campaign_id',       1,'DBID of the campaign with respect to the last dial attempt has been made',               0,  12,NULL,    1,1,2,  1,0,0)

INSERT INTO cfg_field VALUES(114,1,'agent_id',          4,'Agent login identifier',                                                                 32, 13,NULL,    1,1,2,  1,0,0)

INSERT INTO cfg_field VALUES(115,1,'chain_id',          1,'Unique identifier of chain',                                                             0,  14,NULL,    2,1,1,  1,0,0)

INSERT INTO cfg_field VALUES(116,1,'chain_n',           1,'Unique identifier of record within chain',                                               0,  15,NULL,    2,1,1,  1,0,0)

INSERT INTO cfg_field VALUES(117,1,'group_id',          1,'AgentGroup or PlaceGroup unique identifier (DBID)',                                      0,  25,NULL,    1,1,2,  1,0,0)

INSERT INTO cfg_field VALUES(118,1,'app_id',            1,'Application unique identifier(DBID)',                                                    0,  26,NULL,    1,1,2,  1,0,0)

INSERT INTO cfg_field VALUES(119,1,'treatments',        4,'Treatments History',                                                                     255,27,NULL,    1,1,2,  1,0,0)

INSERT INTO cfg_field VALUES(120,1,'media_ref',         1,'Reference to media body to be sent in case of treatment',                                0,  28,NULL,    1,1,2,  1,0,0)

INSERT INTO cfg_field VALUES(121,1,'contact_info',      4,'Contact Info',                                                                           128,2,NULL,     1,1,1,  1,0,0)

INSERT INTO cfg_field VALUES(122,1,'contact_info_type', 1,'Contact Info Type',                                                                      0,  24,'1',     1,1,1,  1,0,0)

INSERT INTO cfg_field VALUES(123,1,'email_subject',     4,'Email Subject',                                                                          255,29,NULL,     1,1,2,  1,0,0)

INSERT INTO cfg_field VALUES(124,1,'email_template_id', 1,'Email Template ID',                                                                      0,  30,NULL,     1,1,2,  1,0,0)

INSERT INTO cfg_field VALUES(125,1,'switch_id',         1,'Switch ID',                                                                              0,  31,NULL,     1,1,2,  1,0,0)

echo '* Formats *'

INSERT INTO cfg_format VALUES(101,1,'Default_Outbound_6','Default format for Outbound Suite 6.x',1,0,0)

INSERT INTO cfg_format values(102, 1,'Default_DoNotContact_List','Default format for Do Not Contact List',1,0,0)

INSERT INTO cfg_format VALUES(103,1,'Default_Outbound_70','Default format for Outbound Suite 7.0',1,0,0)


echo '* Format compositions *'

INSERT INTO cfg_format_field SELECT 101,dbid,0,0 FROM cfg_field where dbid <= (select dbid from cfg_field where name = 'chain_n')

INSERT INTO cfg_format_field values (102, 121, 0, 0)

INSERT INTO cfg_format_field SELECT 103,dbid,0,0 FROM cfg_field where name <> 'phone' and name <> 'phone_type'




echo '* SYSTEM for Fields *'

INSERT INTO cfg_ace SELECT 98,21,dbid,23,9,0,0 FROM cfg_field

echo '* SuperAdmin group for Fields *'

INSERT INTO cfg_ace SELECT 101,21,dbid,23,9,0,0 FROM cfg_field

echo '* Administrators for Fields *'

INSERT INTO cfg_ace SELECT 102,21,dbid,23,9,0,0 FROM cfg_field

echo '* Users for Fields *'

INSERT INTO cfg_ace SELECT 103,21,dbid,23,9,0,0 FROM cfg_field

echo '* Permissions for Format *'

INSERT INTO cfg_ace VALUES(98,21,101,24,9,0,0)

INSERT INTO cfg_ace VALUES(101,21,101,24,9,0,0)

INSERT INTO cfg_ace VALUES(102,21,101,24,9,0,0)

INSERT INTO cfg_ace VALUES(103,21,101,24,9,0,0)

INSERT INTO cfg_ace VALUES(98,21,102,24,9,0,0) 

INSERT INTO cfg_ace VALUES(101,21,102,24,127,0,0) 

INSERT INTO cfg_ace VALUES(102,21,102,24,127,0,0) 

INSERT INTO cfg_ace VALUES(103,21,102,24,9,0,0) 

INSERT INTO cfg_ace VALUES(98,21,103,24,9,0,0)

INSERT INTO cfg_ace VALUES(101,21,103,24,9,0,0)

INSERT INTO cfg_ace VALUES(102,21,103,24,9,0,0)

INSERT INTO cfg_ace VALUES(103,21,103,24,9,0,0)



echo '*** Default Time Zones***'

INSERT INTO cfg_time_zone VALUES(101,1,'GMT','Greenwich Mean Time',0,2,-2147450637,-2147434246,'GMT','GMT',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(102,1,'ECT','European Central Time',2,2,-2147450637,-2147434246,'European Central Time','ECT',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(103,1,'EET','Eastern European Time',4,2,-2147434253,-2147417862,'Eastern European Time','EET',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(104,1,'ART','(Arabic) Egypt Standard Time',4,2,-2147482764,-2147482759,'(Arabic) Egypt Standard Time','ART',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(105,1,'EAT','Eastern African Time',6,1,0,0,'Eastern African Time','EAT',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(106,1,'MET','Middle East Time',7,2,-2147481085,-2147480823,'Middle East Time','MET',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(107,1,'NET','Near East Time',8,1,0,0,'Near East Time','NET',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(108,1,'PLT','Pakistan Lahore Time',10,1,0,0,'Pakistan Lahore Time','PLT',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(109,1,'IST','India Standard Time',11,1,0,0,'India Standard Time','IST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(110,1,'BST','Bangladesh Standard Time',12,2,-2147483405,-2147483398,'Bangladesh Standard Time','BST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(111,1,'VST','Vietnam Standard Time',14,1,0,0,'Vietnam Standard Time','VST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(112,1,'CTT','China Taiwan Time',16,1,0,0,'China Taiwan Time','CTT',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(113,1,'JST','Japan Standard Time',18,1,0,0,'Japan Standard Time','JST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(114,1,'KST','Korea Standard Time',18,1,0,0,'Korea Standard Time','KST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(115,1,'ACT','Australia Central Time',19,1,0,0,'Australia Central Time','ACT',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(116,1,'AET','Australia Eastern Time',20,2,-2147449864,-2147450637,'Australia Eastern Time','AET',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(117,1,'SST','Solomon Standard Time',22,1,0,0,'Solomon Standard Time','SST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(118,1,'NST','New Zealand Standard Time',24,2,-2147450726,-2147450701,'New Zealand Standard Time','NST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(119,1,'MIT','Midway Islands Time',-22,1,0,0,'Midway Islands Time','MIT',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(120,1,'HST','Hawaii Standard Time',-20,1,0,0,'Hawaiian Standard Time','HST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(121,1,'AST','Alaska Standard Time',-18,2,-2113896285,-2147450725,'Alaskan Standard Time','AST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(122,1,'PST','Pacific Standard Time',-16,2,-2113896285,-2147450725,'Pacific Standard Time','PST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(123,1,'PNT','Phoenix Standard Time',-14,1,0,0,'Mountain Standard Time','PNT',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(124,1,'MST','Mountain Standard Time',-14,2,-2113896285,-2147450725,'US Mountain Standard Time','MST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(125,1,'CST','Central Standard Time',-12,2,-2113896285,-2147450725,'Central Standard Time','CST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(126,1,'EST','Eastern Standard Time',-10,2,-2113896285,-2147450725,'Eastern Standard Time','EST',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(127,1,'IET','Indiana Eastern Standard',-10,1,0,0,'Indiana Eastern Standard','IET',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(128,1,'PRT','Puerto Rico and US Virgin Islands Time',-8,1,0,0,'Puerto Rico and US Virgin Islands Time','PRT',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(129,1,'CNT','Canada Newfoundland Time',-7,2,-2113896285,-2147450725,'Canada Newfoundland Time','CNT',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(130,1,'AGT','Argentina Standard Time',-6,1,0,0,'Argentina Standard Time','AGT',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(131,1,'BET','Brazil Eastern Time',-6,2,-2147483478,-2147483406,'Brazil Eastern Time','BET',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(132,1,'CAT','Central African Time',-2,1,0,0,'Central African Time','CAT',1,0,0,60)

INSERT INTO cfg_time_zone VALUES(133,1,'AtlST','Atlantic Standard Time', -8, 2,-2113896285,-2147450725, 'Atlantic Standard Time','AtlST',1,0,0,60)

echo '* Permissions for TimeZones *'

INSERT INTO cfg_ace \
SELECT 101,21,dbid,30,127,0,0 \
FROM cfg_time_zone 

INSERT INTO cfg_ace \
SELECT 102,21,dbid,30,127,0,0 \
FROM cfg_time_zone 

INSERT INTO cfg_ace \
SELECT 103,21,dbid,30,9,0,0 \
FROM cfg_time_zone 

INSERT INTO cfg_ace SELECT 98,21,dbid,30,9,0,0 FROM cfg_time_zone


echo '***Default Alarm Conditions***'

INSERT INTO cfg_alarm_condtn VALUES(101,'Connection Failure','The connection between any two Genesys components has been lost.',2,NULL,172800,1,1,NULL,NULL)

INSERT INTO cfg_alarm_condtn VALUES(102,'Application Failure','Failure of any daemon Genesys component monitored by the Management Layer.',2,NULL,172800,1,1,NULL,NULL)

INSERT INTO cfg_alarm_condtn VALUES(103,'CTI Link Failure','Failure of connection between any T-Server and switch.',2,NULL,172800,1,1,NULL,NULL)

INSERT INTO cfg_alarm_condtn VALUES(104,'Licensing Error','Any licensing error identified by any Genesys component.',1,NULL,172800,1,1,NULL,NULL)

INSERT INTO cfg_alarm_condtn VALUES(105,'Host Inaccessible','The Management Layer cannot contact the Local Control Agent on the host where Genesys daemon applications are running. Local Control Agent is not started, or it is listening on the port different from the one specified in configuration.',2,NULL,172800,1,1,NULL,NULL)

INSERT INTO cfg_alarm_condtn VALUES(106,'Service Unavailable','Daemon Genesys component is unable to provide service for some internal reasons.',2,NULL,172800,1,1,NULL,NULL)

INSERT INTO cfg_alarm_condtn VALUES(107,'Host Unavailable','A host where Genesys daemon applications are running is unavailable (turned off).',2,NULL,172800,1,1,NULL,NULL)

INSERT INTO cfg_alarm_condtn VALUES(108,'Host Unreachable','The Management Layer cannot reach the host where Genesys daemon applications are running (no route to the host).',2,NULL,172800,1,1,NULL,NULL)

INSERT INTO cfg_alarm_condtn VALUES(109,'Unplanned Solution Status Change','Solution status has changed from Started to Pending without any requests to stop the Solution. This may indicate a failure of one of the Solution components.',2,NULL,172800,1,1,NULL,NULL)

INSERT INTO cfg_alarm_condtn VALUES(110,'Message Server Loss of Database Connection','Message Server has lost connection to the Centralized Log Database.',2,NULL,172800,1,1,NULL,NULL)

echo '***Permissions for the default Alarm Conditions***'

INSERT INTO cfg_ace SELECT 101,21,dbid,34,127,0,0 FROM cfg_alarm_condtn 

INSERT INTO cfg_ace SELECT 102,21,dbid,34,127,0,0 FROM cfg_alarm_condtn 

INSERT INTO cfg_ace SELECT 103,21,dbid,34,9,0,0 FROM cfg_alarm_condtn 

INSERT INTO cfg_ace SELECT 98,21,dbid,34,127,0,0 FROM cfg_alarm_condtn 

echo '*** Default cfg_log_event***'

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(101,4504,0,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(101,4503,1,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(102,5064,0,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(102,5090,1,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(103,20002,0,2,1,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(103,20001,1,2,1,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(104,7100,0,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(104,0,1,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(105,8000,0,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(105,8001,1,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(106,5094,0,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(106,5093,1,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(107,8002,0,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(107,8001,1,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(108,8003,0,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(108,8001,1,3,0,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(109,10385,0,2,43,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(109,10370,1,2,43,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(110,11051,0,2,42,0,0,0)

INSERT INTO cfg_log_event(alarm_dbid,log_event_id,event_type,selection_mode,app_type,app_dbid,alarm_csid,app_csid) VALUES(110,11050,1,2,42,0,0,0)

echo '7.0 changes'


create table cfg_parameters( \
    set_id numeric(10,0) not null, \
    section varchar(64) not null, \
    opt varchar(64) not null, \
    val varchar(255) not null, \
    PRIMARY KEY(set_id,section,opt) \
    )


INSERT INTO cfg_parameters(set_id,section,opt,val) VALUES(0,'database','tenancy_model','multi')

INSERT INTO cfg_parameters(set_id,section,opt,val) VALUES(0,'database','version','8.5.000.07')

INSERT INTO cfg_parameters(set_id,section,opt,val) VALUES(0,'database','crypt_passwords','true')


create table cfg_hca_object( \
    object_type numeric(10,0) not null, \
    object_dbid numeric(10,0) not null, \
    end_time    numeric(10,0) not null, \
    start_time  numeric(10,0), \
    seq_number  numeric(10,0), \
    name        varchar(255), \
    folder_dbid numeric(10,0), \
    char_field_1    varchar(255), \
    char_field_2    varchar(255), \
    char_field_3    varchar(255), \
    char_field_4    varchar(255), \
    char_field_5    varchar(255), \
    int_field_1 int, \
    int_field_2 int, \
    int_field_3 int, \
    int_field_4 int, \
    int_field_5 int, \
    PRIMARY KEY(object_type,object_dbid,end_time) \
    )




create table cfg_hca_link( \
    link_id     numeric(10,0) not null, \
    base_type   numeric(10,0) not null, \
    base_dbid   numeric(10,0) not null, \
    link_key    varchar(64) not null, \
    end_time    numeric(10,0) not null, \
    start_time  numeric(10,0), \
    seq_number  numeric(10,0), \
    link_type   numeric(10,0) not null, \
    link_dbid   numeric(10,0) not null, \
    name    varchar(255), \
    char_field_1    varchar(255), \
    char_field_2    varchar(255), \
    char_field_3    varchar(255), \
    char_field_4    varchar(255), \
    char_field_5    varchar(255), \
    int_field_1 int, \
    int_field_2 int, \
    int_field_3 int, \
    int_field_4 int, \
    int_field_5 int, \
    PRIMARY KEY(link_id,base_type,base_dbid,link_key,end_time,link_type,link_dbid) \
)


create table cfg_clr_script ( \
    alarm_dbid  numeric(10,0) not null, \
    script_dbid numeric(10,0) not null, \
    PRIMARY KEY(alarm_dbid,script_dbid) \
)


create table cfg_enumerator ( \
    dbid    numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    name    varchar(255), \
    description varchar(255), \
    state   int, \
    type int, \
    display_name varchar(255), \
    PRIMARY KEY(dbid) \
)

insert into cfg_enumerator values (101,1,'MediaType', 'Media type identifier', 1,1,'Media Type')

insert into cfg_enumerator values (102,1,'ServiceType', 'Customer defined', 1,1,'Service Type')

insert into cfg_enumerator values (103,1,'CustomerSegment', 'Customer defined', 1,1,'Customer Segment')

insert into cfg_enumerator values (104,1,'IVR Text To Speech Used', 'Defines IVR Text To Speech Used',1,1,'IVR Text To Speech Used')

insert into cfg_enumerator values (105,1,'IVR Speech Recognition Used', 'Defines IVR Speech Recognition Used', 1,1,'IVR Speech Recognition Used')

insert into cfg_enumerator values (106,1,'IVR Application Name','Defines IVR Application Name', 1,1,'IVR Application Name')

insert into cfg_enumerator values (107,1,'IVR Technical Result','Defines IVR Technical Result', 1,1,'IVR Technical Result')

insert into cfg_enumerator values (108,1,'IVR Technical Result Reason','Defines IVR Technical Result Reason', 1,1,'IVR Technical Result Reason')

insert into cfg_enumerator values (109,1,'Case ID','Defines Case ID', 1,1,'Case ID')

insert into cfg_enumerator values (110,1,'Business Result','Defines Business Result', 1,1,'Business Result')

insert into cfg_enumerator values (111,1,'Root Interaction ID','Defines Root Interaction ID', 1,1,'Root Interaction ID')

echo '7.0.1 Enumerators'

insert into cfg_enumerator values (112, 1, 'InteractionType', 'Predefined list of interaction types supported by contact center', 1, 1, 'Interaction Type')

insert into cfg_enumerator values (113, 1, 'InteractionSubtype', 'Predefined list of interaction subtypes supported by contact center', 1, 1, 'Interaction Subtype')

insert into cfg_enumerator values (114, 1, 'CategoryStructure', 'Customer defined', 1, 4, 'Category Structure')

insert into cfg_enumerator values (115, 1, 'ScreeningRules', 'Customer defined', 1, 4, 'Screening Rules')

insert into cfg_enumerator values (116, 1, 'EmailAccounts', 'Customer defined', 1, 4, 'E-mail Accounts')

insert into cfg_enumerator values (117, 1, 'StopProcessingReason', 'Predefined, extended by customer', 1, 1, 'StopProcessing Reason')

insert into cfg_enumerator values (118, 1, 'Language', 'Extended by customer', 1, 1, 'Language')

insert into cfg_enumerator values (119, 1, 'DispositionCode', 'Customer defined', 1, 1, 'Disposition Code')

insert into cfg_enumerator values (120, 1, 'ReasonCode', 'Customer defined', 1, 1, 'Reason Code')

insert into cfg_enumerator values (121, 1, 'InteractionAttributes', 'List of predefined interaction attributes', 1, 1, 'Interaction Attributes')

insert into cfg_enumerator values (122, 1, 'ContactAttributes', 'List of predefined contact attributes', 1, 1, 'Contact Attributes')

insert into cfg_enumerator values (123, 1, 'PlaceInQueueReason', 'Customer defined', 1, 1, 'PlaceInQueue Reason')


INSERT INTO cfg_ace SELECT 98,21,dbid,35,9,0,0 FROM cfg_enumerator

INSERT INTO cfg_ace SELECT 101,21,dbid,35,127,0,0 FROM cfg_enumerator

INSERT INTO cfg_ace SELECT 102,21,dbid,35,127,0,0 FROM cfg_enumerator

INSERT INTO cfg_ace SELECT 103,21,dbid,35,9,0,0 FROM cfg_enumerator

INSERT INTO cfg_folder VALUES(131,'Business Attributes',35,1,7,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(133,'Attribute Values',36,101,35,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(134,'Attribute Values',36,102,35,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(135,'Attribute Values',36,103,35,1,0,0,NULL,1,0)
 
INSERT INTO cfg_folder VALUES(136,'Attribute Values',36,104,35,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(137,'Attribute Values',36,105,35,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(138,'Attribute Values',36,106,35,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(139,'Attribute Values',36,107,35,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(140,'Attribute Values',36,108,35,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(141,'Attribute Values',36,109,35,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(142,'Attribute Values',36,110,35,1,0,0,NULL,1,0)

INSERT INTO cfg_folder VALUES(143,'Attribute Values',36,111,35,1,0,0,NULL,1,0)

update cfg_max_dbid set max_dbid=(select max(dbid) from cfg_folder) where object_type=22

insert into cfg_folder (dbid,name,type,owner_dbid,owner_type,state,csid,owner_csid,folder_class,custom_type) select max(max_dbid) + 1, 'Attribute Values',36,112,35,1,0,0,1,0 from cfg_max_dbid where object_type=22

insert into cfg_folder (dbid,name,type,owner_dbid,owner_type,state,csid,owner_csid,folder_class,custom_type) select max(max_dbid) + 2, 'Attribute Values',36,113,35,1,0,0,1,0 from cfg_max_dbid where object_type=22

insert into cfg_folder (dbid,name,type,owner_dbid,owner_type,state,csid,owner_csid,folder_class,custom_type) select max(max_dbid) + 3, 'Attribute Values',36,114,35,1,0,0,1,0 from cfg_max_dbid where object_type=22

insert into cfg_folder (dbid,name,type,owner_dbid,owner_type,state,csid,owner_csid,folder_class,custom_type) select max(max_dbid) + 4, 'Attribute Values',36,115,35,1,0,0,1,0 from cfg_max_dbid where object_type=22

insert into cfg_folder (dbid,name,type,owner_dbid,owner_type,state,csid,owner_csid,folder_class,custom_type) select max(max_dbid) + 5, 'Attribute Values',36,116,35,1,0,0,1,0 from cfg_max_dbid where object_type=22

insert into cfg_folder (dbid,name,type,owner_dbid,owner_type,state,csid,owner_csid,folder_class,custom_type) select max(max_dbid) + 6, 'Attribute Values',36,117,35,1,0,0,1,0 from cfg_max_dbid where object_type=22

insert into cfg_folder (dbid,name,type,owner_dbid,owner_type,state,csid,owner_csid,folder_class,custom_type) select max(max_dbid) + 7, 'Attribute Values',36,118,35,1,0,0,1,0 from cfg_max_dbid where object_type=22

insert into cfg_folder (dbid,name,type,owner_dbid,owner_type,state,csid,owner_csid,folder_class,custom_type) select max(max_dbid) + 8, 'Attribute Values',36,119,35,1,0,0,1,0 from cfg_max_dbid where object_type=22

insert into cfg_folder (dbid,name,type,owner_dbid,owner_type,state,csid,owner_csid,folder_class,custom_type) select max(max_dbid) + 9, 'Attribute Values',36,120,35,1,0,0,1,0 from cfg_max_dbid where object_type=22

insert into cfg_folder (dbid,name,type,owner_dbid,owner_type,state,csid,owner_csid,folder_class,custom_type) select max(max_dbid) + 10, 'Attribute Values',36,121,35,1,0,0,1,0 from cfg_max_dbid where object_type=22

insert into cfg_folder (dbid,name,type,owner_dbid,owner_type,state,csid,owner_csid,folder_class,custom_type) select max(max_dbid) + 11, 'Attribute Values',36,122,35,1,0,0,1,0 from cfg_max_dbid where object_type=22

insert into cfg_folder (dbid,name,type,owner_dbid,owner_type,state,csid,owner_csid,folder_class,custom_type) select max(max_dbid) + 12, 'Attribute Values',36,123,35,1,0,0,1,0 from cfg_max_dbid where object_type=22

update cfg_max_dbid set max_dbid=(select max(dbid) from cfg_folder) where object_type=22


echo '* SYSTEM for Enumerators *'

INSERT INTO cfg_ace SELECT 98,21,dbid,22,9,0,0 from cfg_folder where name='Business Attributes' 

echo '* SuperAdmin for Enumerators *'

INSERT INTO cfg_ace SELECT 101,21,dbid,22,127,0,0 from cfg_folder where name='Business Attributes' 

echo '* Administrators for Enumerators *'

INSERT INTO cfg_ace SELECT 102,21,dbid,22,127,0,0 from cfg_folder where name='Business Attributes' 

echo '* Users for Enumerators *'

INSERT INTO cfg_ace SELECT 103,21,dbid,22,9,0,0 from cfg_folder where name='Business Attributes' 


echo '* Enum values table *'


create table cfg_enum_value ( \
    dbid    numeric(10,0) not null, \
    enum_dbid numeric(10,0), \
    tenant_dbid numeric(10,0), \    
    name    varchar(255), \
    is_default int, \
    description varchar(255), \
    state int, \
    display_name varchar(255), \
    PRIMARY KEY(dbid) \
)

insert into cfg_enum_value values (100,101,1,'voice',1,'Media Voice',1,'voice')

insert into cfg_enum_value values (101,101,1,'voip',1,'Media Voice over IP',1,'voip')

insert into cfg_enum_value values (102,101,1,'email',1,'Media EMail',1,'email')

insert into cfg_enum_value values (103,101,1,'vmail',1,'Media Voice Mail',1,'vmail')

insert into cfg_enum_value values (104,101,1,'smail',1,'Media Scanned Mail',1,'smail')

insert into cfg_enum_value values (105,101,1,'chat',1,'Media Chat',1,'chat')

insert into cfg_enum_value values (106,101,1,'video',1,'Media Video',1,'video')

insert into cfg_enum_value values (107,101,1,'cobrowsing',1,'Media Cobrowsing',1,'cobrowsing')

insert into cfg_enum_value values (108,101,1,'whiteboard',1,'Media Whiteboard',1,'whiteboard')

insert into cfg_enum_value values (109,101,1,'appsharing',1,'Media Application Sharing',1,'appsharing')

insert into cfg_enum_value values (110,101,1,'webform',1,'Media Web Form',1,'webform')

insert into cfg_enum_value values (111,101,1,'workitem',1,'Media Workitem',1,'workitem')

insert into cfg_enum_value values (112,101,1,'callback',1,'Media Callback',1,'callback')

insert into cfg_enum_value values (113,101,1,'fax',1,'Media Fax',1,'fax')

insert into cfg_enum_value values (114,101,1,'imchat',1,'Media IMChat',1,'imchat')

insert into cfg_enum_value values (115,101,1,'busevent',1,'Media Business Event',1,'busevent')

insert into cfg_enum_value values (116,101,1,'alert',1,'Media Alert',1,'alert')

insert into cfg_enum_value values (117,101,1,'sms',1,'Media SMS',1,'sms')

insert into cfg_enum_value values (118,101,1,'any',2,'Media Any',1,'any')

insert into cfg_enum_value values (122,101,1,'smssession',1,'Media SMS Session',1,'smssession')

insert into cfg_enum_value values (123,101,1,'mms',1,'Media MMS',1,'mms')

insert into cfg_enum_value values (124,101,1,'mmssession',1,'Media MMS Session',1,'mmssession')

insert into cfg_enum_value values (200,102,1,'default',2,'Service Type Default',1,'default')

insert into cfg_enum_value values (300,103,1,'default',2,'Customer Segment Default',1,'default')

insert into cfg_enum_value values (350,104,1,'unknown',2,'IVR Text To Speech Used Default',1,'unknown')

insert into cfg_enum_value values (353,105,1,'unknown',2,'IVR Speech Recognition Used Default',1,'unknown')

echo '* new for 7.0.1 *'

insert into cfg_enum_value values (400, 112, 1, 'Inbound',1, 'Interactions received by contact center from outside clients', 1, 'Inbound')

insert into cfg_enum_value values (401, 112, 1, 'Outbound',1, 'Interactions sent from contact center to external clients', 1, 'Outbound')

insert into cfg_enum_value values (402, 112, 1, 'Internal',1, 'Internal interactions between contact center correspondents', 1, 'Internal')

insert into cfg_enum_value values (403, 113, 1, 'InboundNew',1, 'New incoming email. Starts a new thread.', 1, 'Inbound New')

insert into cfg_enum_value values (404, 113, 1, 'InboundCustomerReply',1, 'Reply from a customer.', 1, 'Customer Reply')

insert into cfg_enum_value values (405, 113, 1, 'InboundCollaborationReply',1, 'Reply from an external resource.', 1, 'Inbound Collaboration Reply')

insert into cfg_enum_value values (406, 113, 1, 'InboundNDR',1, 'Error message sent back to the system by SMTP server chain.', 1, 'NDR')

insert into cfg_enum_value values (407, 113, 1, 'OutboundNew',1, 'New message from Contact Center to a customer.', 1, 'Outbound New')

insert into cfg_enum_value values (408, 113, 1, 'OutboundReply',1, 'Reply from Contact Center to a customer.', 1, 'Reply')

insert into cfg_enum_value values (409, 113, 1, 'OutboundAcknowledgement',1, 'Ack message sent to customer by Contact Center.', 1, 'Acknowledgement')

insert into cfg_enum_value values (410, 113, 1, 'OutboundAutoResponse',1, 'Automated reply from Contact Center to a customer.', 1, 'Auto Response')

insert into cfg_enum_value values (411, 113, 1, 'OutboundRedirect',1, 'Message redirect to an external resource. No reply expected.', 1, 'Redirect')

insert into cfg_enum_value values (412, 113, 1, 'OutboundCollaborationInvite',1, 'New message to an external resource.', 1, 'Outbound Collaboration Invite')

insert into cfg_enum_value values (413, 113, 1, 'InternalCollaborationInvite',1, 'New message to an internal resource.', 1, 'Internal Collaboration Invite')

insert into cfg_enum_value values (414, 113, 1, 'InternalCollaborationReply',1, 'Reply from an internal resource.', 1, 'Internal Collaboration Reply')

insert into cfg_enum_value values (415, 117, 1, 'Normal',1, 'StopProcessing Reason Normal', 1, 'Normal')

insert into cfg_enum_value values (416, 117, 1, 'AutoResponded',1, 'StopProcessing Reason Auto Responded', 1, 'Auto Responded')

insert into cfg_enum_value values (417, 117, 1, 'Terminated',1, 'StopProcessing Reason Terminated', 1, 'Terminated')

insert into cfg_enum_value values (418, 117, 1, 'Sent',1, 'StopProcessing Reason Sent', 1, 'Sent')

insert into cfg_enum_value values (419, 117, 1, 'Forwarded',1, 'StopProcessing Reason Forwarded', 1, 'Forwarded')

insert into cfg_enum_value values (420, 117, 1, 'Re-directed',1, 'StopProcessing Reason Re-directed', 1, 'Re-directed')

insert into cfg_enum_value values (421, 118, 1, 'English',1, 'Language English', 1, 'English')

insert into cfg_enum_value values (422, 121, 1, 'Priority',1, 'Interaction Attributes Priority', 1, 'Priority')

insert into cfg_enum_value values (423, 121, 1, 'Category',1, 'Interaction Attributes Category', 1, 'Category')

insert into cfg_enum_value values (424, 121, 1, 'ServiceType',1, 'Interaction Attributes Service Type', 1, 'Service Type')

insert into cfg_enum_value values (425, 121, 1, 'MediaType',1, 'Interaction Attributes Media Type', 1, 'Media Type')

insert into cfg_enum_value values (426, 121, 1, 'InteractionType',1, 'Interaction Attributes Interaction Type', 1, 'Interaction Type')

insert into cfg_enum_value values (427, 121, 1, 'InteractionSubtype',1, 'Interaction Attributes Interaction Subtype', 1, 'Interaction Subtype')

insert into cfg_enum_value values (428, 121, 1, 'Language',1, 'Interaction Attributes Language', 1, 'Language')

insert into cfg_enum_value values (429, 121, 1, 'StopProcessingReason',1, 'Interaction Attributes StopProcessing Reason', 1, 'StopProcessing Reason')

insert into cfg_enum_value values (430, 121, 1, 'DispositionCode',1, 'Interaction Attributes Disposition Code', 1, 'Disposition Code')

insert into cfg_enum_value values (431, 121, 1, 'ReasonCode',1, 'Interaction Attributes Reason Code', 1, 'Reason Code')

insert into cfg_enum_value values (432, 122, 1, 'FirstName',1, 'Contact Attributes First Name', 1, 'First Name')

insert into cfg_enum_value values (433, 122, 1, 'LastName',1, 'Contact Attributes Last Name', 1, 'Last Name')

insert into cfg_enum_value values (434, 122, 1, 'Title',1, 'Contact Attributes Title', 1, 'Title')

insert into cfg_enum_value values (435, 122, 1, 'EmailAddress',1, 'Contact Attributes E-mail Address', 1, 'E-mail Address')

insert into cfg_enum_value values (436, 122, 1, 'PhoneNumber',1, 'Contact Attributes Phone Number', 1, 'Phone Number')

insert into cfg_enum_value values (437, 122, 1, 'AccountNumber',1, 'Contact Attributes Account Number', 1, 'Account Number')

insert into cfg_enum_value values (438, 122, 1, 'ContactId',1, 'Contact Attributes Contact ID', 1, 'Contact ID')

insert into cfg_enum_value values (439, 122, 1, 'CustomerSegment',1, 'Contact Attributes Customer Segment', 1, 'Customer Segment')

insert into cfg_enum_value values (440, 122, 1, 'PIN',1, 'Contact Attributes PIN', 1, 'PIN')

echo '* new 7-1-000-01 *'

insert into cfg_enum_value values (119, 101, 1, 'auxwork',1,'Media AuxWork',1,'auxwork')

echo '* new 7-2-000-03 *'

insert into cfg_enum_value values (441, 113, 1, 'OutboundNotification',1,'Notification from Contact center to the customer about reply stored in contact history',1,'OutboundNotification')

echo '* Cfg objective table *'


create table cfg_obj_table ( \
    dbid    numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    name    varchar(255), \
    description varchar(255), \
    state int, \
    prepaid_cost int, \
    timezone_dbid numeric(10,0), \
    time_start int, \
    time_end int, \
    type int, \
    PRIMARY KEY(dbid) \
)


INSERT INTO cfg_folder VALUES(132,'Objective Tables',37,1,7,1,0,0,NULL,1,0)

echo '* SYSTEM for OT *'

INSERT INTO cfg_ace values (98,21,132,22,9,0,0)

echo '*SuperAdmin for OT *'

INSERT INTO cfg_ace values (101,21,132,22,127,0,0)

echo '*Administrators for OT *'

INSERT INTO cfg_ace values (102,21,132,22,127,0,0)

echo '*Users for OT *'

INSERT INTO cfg_ace values (103,21,132,22,9,0,0)

echo '* Cfg objective records table *'


create table cfg_obj_record ( \
    obj_table_dbid numeric(10,0) not null, \
    media_type_dbid numeric(10,0) not null, \
    svc_type_dbid numeric(10,0) not null, \
    cust_segm_dbid numeric(10,0) not null, \
    obj_threshold int, \
    obj_delta int, \
    contract_dbid numeric(10,0), \
    PRIMARY KEY(obj_table_dbid,media_type_dbid,svc_type_dbid,cust_segm_dbid) \
)

echo '* 7-1-000-01 *'


create table cfg_locale2( \
    lcid            numeric (10,0)  not null, \
    lc_class        int             not null, \
    lc_type         int             not null, \
    lc_subtype      int             not null, \
    lc_instance_id  numeric (10,0)  not null, \
    lc_value        varchar (255), \
    lc_description  varchar (255), \
    PRIMARY KEY(lcid,lc_class,lc_type,lc_subtype,lc_instance_id) \
    )



create table cfg_gen_object( \
    object_type     int             not null, \
    object_dbid     numeric(10,0)   not null, \
    owner_dbid      numeric(10,0), \
    tenant_dbid     numeric(10,0), \
    name            varchar(255), \
    state           int, \
    char_field_1    varchar(255), \
    char_field_2    varchar(255), \
    char_field_3    varchar(255), \
    int_field_1     int, \
    int_field_2     int, \
    int_field_3     int, \
    long_field_1    numeric(10,0), \
    long_field_2    numeric(10,0), \
    long_field_3    numeric(10,0), \
    PRIMARY KEY     (object_type,object_dbid) \
    )



create table cfg_gen_property( \
    object_type     int             not null, \
    object_dbid     numeric(10,0)   not null, \
    list_id         int             not null, \
    list_key        varchar(64)     not null, \
    prop_id         int             not null, \
    prop_type       int, \
    prop_value      varchar(255), \
    PRIMARY KEY     (object_type,object_dbid,list_id,list_key,prop_id) \
    )

echo '* 7.2.0 *'


create table cfg_route_table( \
    database_guid   varchar(64) not null, \
    server_guid     varchar(64) not null, \
    site        varchar(255), \
    dbserver        varchar(255), \
    dbname      varchar(255), \
    local_id            numeric(10,0), \
    remote_id           numeric(10,0), \
    char_field_1    varchar(255), \
    char_field_2    varchar(255), \
    char_field_3    varchar(255), \
    int_field_1         int, \
    int_field_2         int, \
    int_field_3         int, \
    PRIMARY KEY     (database_guid,server_guid) \
    )


echo '*7.5.0 additions*'


create table cfg_obj_resource( \
    object_dbid numeric(10,0) not null, \
    object_type int not null, \
    resource_dbid numeric(10,0) not null, \
    resource_type int not null, \
    type int, \
    description  varchar(254), \
    char_field_1 varchar(254), \
    char_field_2 varchar(254), \
    char_field_3 varchar(254), \
    char_field_4 varchar(254), \
    long_field_1 numeric(10,0), \
    long_field_2 numeric(10,0), \
    long_field_3 numeric(10,0), \
    long_field_4 numeric(10,0), \
    PRIMARY KEY(object_type,object_dbid,resource_type,resource_dbid) \
    )


create table cfg_campaign_group( \
    dbid    numeric(10,0) not null, \
    campaign_dbid numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    name    varchar(254), \
    group_dbid numeric(10,0), \
    group_type int, \
    description varchar(254), \
    ivrprofile_dbid numeric(10,0), \
    dial_mode int, \
    orig_dn_dbid numeric(10,0), \
    num_of_channels int, \
    operation_mode int, \
    min_rec_buff_size int, \
    opt_rec_buff_size int, \
    max_queue_size int, \
    opt_method int, \
    opt_method_value int, \
    iqueue_dbid numeric(10,0), \
    script_dbid numeric(10,0), \
    state int, \
    trunk_group_dn_dbid numeric(10,0), \
    PRIMARY KEY(dbid) \
    )


create table cfg_cam_group_server( \
    camgroup_dbid   numeric(10,0) not null, \
    app_dbid    numeric(10,0) not null, \
    PRIMARY KEY(camgroup_dbid,app_dbid) \
)


create table cfg_gvp_reseller ( \
    dbid    numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    name    varchar(254), \
    display_name varchar(254), \
    start_date  int, \
    is_parent_nsp int, \
    timezone_dbid   numeric(10,0), \
    notes   varchar(254), \
    state   int, \
    PRIMARY KEY(dbid) \
)


create table cfg_gvp_customer ( \
    dbid    numeric(10,0) not null, \
    reseller_dbid   numeric(10,0), \
    tenant_dbid numeric(10,0), \
    name    varchar(254), \
    display_name varchar(254), \
    channel varchar(254), \
    notes   varchar(254), \
    is_provisioned int, \
    is_admin_customer int, \
    timezone_dbid   numeric(10,0), \
    state   int, \
    PRIMARY KEY(dbid) \
)


create table cfg_gvp_ivrprofile ( \
    dbid    numeric(10,0) not null, \
    customer_dbid   numeric(10,0), \
    reseller_dbid   numeric(10,0), \
    tenant_dbid numeric(10,0), \
    name    varchar(254), \
    display_name varchar(254), \
    type int, \
    notes   varchar(254), \
    description  varchar(254), \
    start_svc_date  int, \
    end_svc_date    int, \
    is_provisioned int, \
    tfn varchar(254), \
    status  varchar(254), \
    state   int, \
    PRIMARY KEY(dbid) \
)

INSERT INTO cfg_folder VALUES(156,'Voice Platform Profiles',41,1,7,1,0,0,NULL,1,0)


create table cfg_gvp_profile_did ( \
    ivrprofile_dbid numeric(10,0) not null, \
    dn_dbid numeric(10,0) not null, \
    PRIMARY KEY(ivrprofile_dbid,dn_dbid) \
)


create table cfg_scheduled_task ( \
    dbid    numeric(10,0) not null, \
    name    varchar(254), \
    description varchar(254), \
    type int, \
    start_time int, \
    state   int, \
    PRIMARY KEY(dbid) \
)

INSERT INTO cfg_max_dbid VALUES(38,100)

INSERT INTO cfg_max_dbid VALUES(39,100)

INSERT INTO cfg_max_dbid VALUES(40,100)

INSERT INTO cfg_max_dbid VALUES(41,100)

INSERT INTO cfg_max_dbid VALUES(42,100)


insert into cfg_enum_value values (120,101,1,'outboundpreview',1,'Media Outbound Preview',1,'outboundpreview')

insert into cfg_enum_value values (121,101,1,'trainingitem',1,'Training Item',1,'training item')

insert into cfg_enum_value values (442,113,1,'InboundReport',1,'Interaction delivery progress notification',1,'Inbound Report')

insert into cfg_enum_value values (443,113,1,'InboundDisposition',1,'Interaction Subtype Disposition',1,'Inbound Disposition')


echo '* max dbid updates *'

INSERT INTO cfg_max_dbid VALUES(35,1000) 

INSERT INTO cfg_max_dbid VALUES(36,1000) 

INSERT INTO cfg_max_dbid VALUES(37,1000)

INSERT INTO cfg_max_dbid VALUES(1000,100)

update cfg_max_dbid set max_dbid=(select max(dbid) from cfg_folder) where object_type=22

update cfg_max_dbid set max_dbid=(select max(dbid) from cfg_alarm_condtn) where object_type=34

update cfg_max_dbid set max_dbid=(select max(dbid) from cfg_format) where object_type=24

update cfg_max_dbid set max_dbid=(select max(dbid) from cfg_field) where object_type=23

echo 'param table update'

INSERT INTO cfg_parameters(set_id,section,opt,val) VALUES(0,'action','what','initialization by sql script')

INSERT INTO cfg_parameters(set_id,section,opt,val) select 0,'action','when', current timestamp from cfg_tenant where dbid=1

INSERT INTO cfg_parameters(set_id,section,opt,val) VALUES(0,'action','status','succeeded')

INSERT INTO cfg_parameters(set_id,section,opt,val) select 0,'action','trace', cast('$Name: init_multi_db2.sql /main/sfo-7.1.0/20 18-Nov-2005.14:58:45 Pacific dmitryn $ $Id: init_multi_db2.sql /main/sfo-7.1.0/20 18-Nov-2005.14:58:45 Pacific dmitryn $' as varchar(255)) from cfg_tenant where dbid=1

echo '* 8.0.1 additions *'


create table cfg_role ( \
    dbid    numeric(10,0) not null, \
    tenant_dbid numeric(10,0), \
    name    varchar(255), \
    state   int, \
    description varchar(255), \
    PRIMARY KEY(dbid) \
)


create table cfg_role_member ( \
    role_dbid   numeric(10,0) not null, \
    object_dbid numeric(10,0) not null, \
    object_type int not null, \
    PRIMARY KEY(role_dbid,object_dbid,object_type) \
)

INSERT INTO cfg_max_dbid VALUES(43,100)

INSERT INTO cfg_folder VALUES(157,'Roles',43,1,7,1,0,0,NULL,1,0)

update cfg_max_dbid set max_dbid=(select max(dbid) from cfg_folder) where object_type=22


create table cfg_hdb_object( \
    id                  numeric(10,0) not null, \
    oper_type           int not null, \
    oper_time           int not null, \
    object_type         varchar(255), \
    object_type_id      int, \
    object_dbid         numeric(10,0), \
    user_name           varchar(255), \
    user_dbid           numeric(10,0), \
    object_data         blob, \
    object_data_text    clob, \
    object              varchar(255), \
    application         varchar(255), \
    application_dbid    numeric(10,0), \
    tenant              varchar(255), \
    tenant_dbid         numeric(10,0), \
    user_tenant         varchar(255), \
    user_tenant_dbid    numeric(10,0), \
    host                varchar(255), \
    PRIMARY KEY(id) \
)


create table cfg_hdb_last_login( \
    person_dbid         numeric(10,0) not null, \
    login_time          int, \
    app_dbid            numeric(10,0), \
    hostname            varchar(255), \
    PRIMARY KEY(person_dbid) \
)

insert into cfg_hdb_last_login(person_dbid,login_time,app_dbid,hostname) select dbid,0,0,'' from cfg_person


CREATE PROCEDURE execute_block (IN flag DECIMAL(16,0), IN blob_data CLOB) \
BEGIN \
  DECLARE blob_length INTEGER; \
  DECLARE blob_offset INTEGER; \
  DECLARE stmt VARCHAR(8050); \
 \
  IF (flag < 1) THEN \
    SET blob_offset = 1; \
    SET blob_length = LENGTH(blob_data); \
 \
    WHILE (blob_offset < blob_length) DO \
      SET stmt = 'BEGIN ATOMIC ' || RTRIM(VARCHAR(SUBSTR(blob_data, blob_offset, 8000))) || ' END'; \
      SET blob_offset = blob_offset + 8000; \
      EXECUTE IMMEDIATE stmt; \
    END WHILE; \
  ELSE \
    UPDATE cfg_hdb_object SET object_data_text = blob_data WHERE id = flag; \
  END IF; \
END


CREATE PROCEDURE execute_script (script_data CLOB, DBID_0 DECIMAL(16,0), blob_data_0 CLOB, DBID_1 DECIMAL(16,0), blob_data_1 CLOB, DBID_2 DECIMAL(16,0), blob_data_2 CLOB, DBID_3 DECIMAL(16,0), blob_data_3 CLOB, DBID_4 DECIMAL(16,0), blob_data_4 CLOB, DBID_5 DECIMAL(16,0), blob_data_5 CLOB, DBID_6 DECIMAL(16,0), blob_data_6 CLOB, DBID_7 DECIMAL(16,0), blob_data_7 CLOB, DBID_8 DECIMAL(16,0), blob_data_8 CLOB, DBID_9 DECIMAL(16,0), blob_data_9 CLOB) \
BEGIN ATOMIC \
  DECLARE script_length INTEGER; \
  DECLARE script_offset INTEGER; \
  DECLARE stmt VARCHAR(8050); \
 \
  SET script_offset = 1; \
  SET script_length = LENGTH(script_data); \
 \
  WHILE (script_offset < script_length) DO \
    SET stmt = 'BEGIN ATOMIC ' || RTRIM(VARCHAR(SUBSTR(script_data, script_offset, 8000))) || ' END'; \
    SET script_offset = script_offset + 8000; \
    EXECUTE IMMEDIATE stmt; \
  END WHILE; \
 \
  IF (DBID_0 < 1) THEN \
    RETURN; \
  END IF; \
 \
  UPDATE cfg_hdb_object SET object_data_text = blob_data_0 WHERE id = DBID_0; \
 \
  IF (DBID_1 < 1) THEN \
    RETURN; \
  END IF; \
 \
  UPDATE cfg_hdb_object SET object_data_text = blob_data_1 WHERE id = DBID_1; \
 \
  IF (DBID_2 < 1) THEN \
    RETURN; \
  END IF; \
 \
  UPDATE cfg_hdb_object SET object_data_text = blob_data_2 WHERE id = DBID_2; \
 \
  IF (DBID_3 < 1) THEN \
    RETURN; \
  END IF; \
 \
  UPDATE cfg_hdb_object SET object_data_text = blob_data_3 WHERE id = DBID_3; \
 \
  IF (DBID_4 < 1) THEN \
    RETURN; \
  END IF; \
 \
  UPDATE cfg_hdb_object SET object_data_text = blob_data_4 WHERE id = DBID_4; \
 \
  IF (DBID_5 < 1) THEN \
    RETURN; \
  END IF; \
 \
  UPDATE cfg_hdb_object SET object_data_text = blob_data_5 WHERE id = DBID_5; \
 \
  IF (DBID_6 < 1) THEN \
    RETURN; \
  END IF; \
 \
  UPDATE cfg_hdb_object SET object_data_text = blob_data_6 WHERE id = DBID_6; \
 \
  IF (DBID_7 < 1) THEN \
    RETURN; \
  END IF; \
 \
  UPDATE cfg_hdb_object SET object_data_text = blob_data_7 WHERE id = DBID_7; \
 \
  IF (DBID_8 < 1) THEN \
    RETURN; \
  END IF; \
 \
  UPDATE cfg_hdb_object SET object_data_text = blob_data_8 WHERE id = DBID_8; \
 \
  IF (DBID_9 < 1) THEN \
    RETURN; \
  END IF; \
 \
  UPDATE cfg_hdb_object SET object_data_text = blob_data_9 WHERE id = DBID_9; \
END


create table cfg_schema(set_ID varchar(255) not null, \
    xml_cfglibschema blob, \
    xsd_cfgschema blob, \
    xml_cfgservermetadata blob, \
    wsdl_configuration blob, \ 
    xml_dbschema blob, \
    wsdl_notification blob, \
    PRIMARY KEY(set_ID) \
)



create table cfg_license (licid numeric(10,0) not null, \
                          loaded int not null, \
                          valid int not null, \
                          lic blob, \
                          PRIMARY KEY(licid))

echo '***NOTE: LOAD CfgLocale_db2.sql AFTER THE init_multi_db2.sql***'
