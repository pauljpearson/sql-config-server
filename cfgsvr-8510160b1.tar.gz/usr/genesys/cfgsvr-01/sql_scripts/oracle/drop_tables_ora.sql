drop table cfg_agent_group
/
drop table cfg_group
/
drop table cfg_group_manager
/ 
drop table cfg_group_route_dn
/
drop table cfg_dn_group
/ 
drop table cfg_host
/ 
drop table cfg_application
/ 
drop table cfg_server
/ 
drop table cfg_app_server
/ 
drop table cfg_app_option
/ 
drop table cfg_app_tenant
/ 
drop table cfg_port_info
/
drop table cfg_app_prototype
/ 
drop table cfg_person
/ 
drop table cfg_password_history
/
drop table cfg_app_rank
/ 
drop table cfg_login_info
/ 
drop table cfg_skill_level
/ 
drop table cfg_skill
/ 
drop table cfg_place
/
drop table cfg_place_group
/ 
drop table cfg_service
/ 
drop table cfg_app_service
/ 
drop table cfg_phys_switch
/ 
drop table cfg_switch
/
drop table cfg_switch_access
/ 
drop table cfg_agent_login
/ 
drop table cfg_dn
/ 
drop table cfg_dest_dn
/ 
drop table cfg_tenant
/ 
drop table cfg_service_info
/ 
drop table cfg_action_code
/ 
drop table cfg_subcode
/ 
drop table cfg_script
/ 
drop table cfg_transaction
/ 
drop table cfg_stat_table
/ 
drop table cfg_stat_day
/ 
drop table cfg_stat_interval
/ 
drop table cfg_table_day
/ 
drop table cfg_access_group
/ 
drop table cfg_ace
/ 
drop table cfg_folder
/ 
drop table cfg_notify
/ 
drop table cfg_refresh
/ 
drop table cfg_max_dbid
/ 
drop table cfg_access_number
/ 
drop table cfg_field
/
drop table cfg_format
/
drop table cfg_format_field
/ 
drop table cfg_table_access
/ 
drop table cfg_calling_list
/ 
drop table cfg_call_list_trtm
/ 
drop table cfg_call_list_info
/ 
drop table cfg_treatment
/ 
drop table cfg_filter
/ 
drop table cfg_time_zone
/ 
drop table cfg_voice_prompt
/ 
drop table cfg_flex_prop
/ 
drop table cfg_ivr_port
/ 
drop table cfg_ivr
/ 
drop table cfg_solution_comp
/ 
drop table cfg_sol_comp_def
/ 
drop table cfg_alarm_condtn
/ 
drop table cfg_alarm_script
/ 
drop table cfg_log_event
/ 
drop table cfg_obj_folder
/ 
drop table cfg_locale
/ 
drop table cfg_parameters
/
drop table cfg_hca_object
/
drop table cfg_hca_link
/
drop table cfg_clr_script
/ 
drop table cfg_enumerator
/ 
drop table cfg_enum_value
/ 
drop table cfg_obj_table
/
drop table cfg_obj_record
/ 
drop table cfg_locale2
/
drop table cfg_gen_object
/
drop table cfg_gen_property
/
drop table cfg_route_table
/
drop table cfg_obj_resource
/
drop table cfg_campaign
/
drop table cfg_campaign_group
/
drop table cfg_cam_group_server
/
drop table cfg_gvp_reseller
/
drop table cfg_gvp_customer
/
drop table cfg_gvp_ivrprofile
/
drop table cfg_gvp_profile_did
/
drop table cfg_scheduled_task
/
drop table cfg_role
/
drop table cfg_role_member
/
drop table cfg_hdb_object
/
drop table cfg_hdb_last_login
/
DROP PROCEDURE execute_block
/
DROP PROCEDURE execute_script
/
drop table cfg_schema
/
drop table cfg_license
/
commit
/
