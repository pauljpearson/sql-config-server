drop table cfg_agent_group
go
drop table cfg_group 
go
drop table cfg_group_manager 
go
drop table cfg_group_route_dn 
go
drop table cfg_dn_group 
go
drop table cfg_host 
go
drop table cfg_application 
go
drop table cfg_server 
go
drop table cfg_app_server 
go
drop table cfg_app_option 
go
drop table cfg_app_tenant 
go
drop table cfg_port_info
go
drop table cfg_app_prototype
go
drop table cfg_person
go
drop table cfg_password_history
go
drop table cfg_app_rank 
go
drop table cfg_login_info 
go
drop table cfg_skill_level 
go
drop table cfg_skill 
go
drop table cfg_place 
go
drop table cfg_place_group 
go
drop table cfg_service 
go
drop table cfg_app_service 
go
drop table cfg_phys_switch 
go
drop table cfg_switch 
go
drop table cfg_switch_access 
go
drop table cfg_agent_login 
go
drop table cfg_dn 
go
drop table cfg_dest_dn 
go
drop table cfg_tenant 
go
drop table cfg_service_info 
go
drop table cfg_action_code 
go
drop table cfg_subcode 
go
drop table cfg_script 
go
drop table cfg_transaction 
go
drop table cfg_stat_table 
go
drop table cfg_stat_day 
go
drop table cfg_stat_interval 
go
drop table cfg_table_day 
go
drop table cfg_access_group 
go
drop table cfg_ace 
go
drop table cfg_folder 
go
drop table cfg_notify 
go
drop table cfg_refresh 
go
drop table cfg_max_dbid 
go
drop table cfg_access_number 
go
drop table cfg_field 
go
drop table cfg_format
go
drop table cfg_format_field 
go
drop table cfg_table_access 
go
drop table cfg_calling_list 
go
drop table cfg_call_list_trtm 
go
drop table cfg_call_list_info 
go
drop table cfg_treatment 
go
drop table cfg_filter 
go
drop table cfg_time_zone 
go
drop table cfg_voice_prompt 
go
drop table cfg_flex_prop 
go
drop table cfg_ivr_port 
go
drop table cfg_ivr 
go
drop table cfg_solution_comp 
go
drop table cfg_sol_comp_def 
go
drop table cfg_alarm_condtn 
go
drop table cfg_alarm_script 
go
drop table cfg_log_event 
go
drop table cfg_obj_folder 
go
drop table cfg_locale 
go
drop table cfg_parameters
go
drop table cfg_hca_object
go
drop table cfg_hca_link
go
drop table cfg_clr_script 
go
drop table cfg_enumerator 
go
drop table cfg_enum_value 
go
drop table cfg_obj_table 
go
drop table cfg_obj_record 
go
drop table cfg_locale2
go
drop table cfg_gen_object
go
drop table cfg_gen_property
go
drop table cfg_route_table
go
drop table cfg_obj_resource
go
drop table cfg_campaign
go
drop table cfg_campaign_group
go
drop table cfg_cam_group_server
go
drop table cfg_gvp_reseller
go
drop table cfg_gvp_customer
go
drop table cfg_gvp_ivrprofile
go
drop table cfg_gvp_profile_did
go
drop table cfg_scheduled_task
go
drop table cfg_role
go
drop table cfg_role_member
go
drop table cfg_hdb_object
go
drop table cfg_hdb_last_login
go
DROP PROCEDURE execute_block
go
DROP PROCEDURE execute_script
go
drop table cfg_schema
go
drop table cfg_license
go
