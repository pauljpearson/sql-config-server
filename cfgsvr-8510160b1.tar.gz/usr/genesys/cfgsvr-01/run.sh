./confserv -s cfgsvr-01
